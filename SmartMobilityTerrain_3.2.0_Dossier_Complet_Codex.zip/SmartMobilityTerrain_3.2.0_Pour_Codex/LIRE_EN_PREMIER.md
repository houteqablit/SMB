# Dossier de transmission à Codex — SmartMobility Terrain 3.2.0

**Commencer par lire** `02_Cahiers_des_charges/Cahier_consolide_3.2.0.md`, puis les deux documents historiques originaux.

**Inventaire** : APK compilé original 3.1.1, guide utilisateur historique, documentation technique historique, cahier historique reconstitué, cahier 3.2.0 consolidé, modèle XLSX 3 feuilles compatible avec les 18 colonnes historiques, CSV correspondants, ancien modèle simplifié pour comparaison et trois captures fonctionnelles.

**Limite essentielle** : le code source Java original, `build.sh`, la configuration Gradle et la clé de signature historique n'ont pas été retrouvés. L'APK fourni est un binaire compilé ; examiner sa structure ne restaure pas fidèlement le projet source. Codex doit vérifier les outils Android disponibles et soit retrouver un projet source fourni séparément, soit reconstruire proprement une application native avec tests.

**Instruction à Codex** : analyser les deux documents historiques et l'APK ; produire un projet Android Java compilable avec un applicationId distinct pour 3.2.0, implémenter le cahier consolidé, créer et tester l'APK, fournir les artefacts réels. Ne pas déclarer de compilation ou de tests réussis sans les avoir exécutés.

**Formats** : pour le XLSX, trois feuilles exactement `Releve`, `Anomalie`, `type_local`. Le modèle de 18 colonnes reprend les en-têtes du guide 3.1.1. Les catalogues Anomalie/type_local ont un schéma **proposé** qui doit être mappé aux structures existantes, et les codes DEMO_ sont fictifs. Le modèle simplifié précédent est conservé pour référence, mais n'est pas compatible tel quel avec les 10 colonnes obligatoires historiques.
