# SmartMobility Terrain — version 3.1.1

Application Android native pour relever les compteurs d’eau (EA) et d’électricité (BT). La collecte fonctionne hors connexion. Cette version télécharge les fichiers XLSX/CSV depuis un lien Google Drive et permet de conserver une sauvegarde complète des anciennes tournées. Aucun serveur à installer.

L’application utilise un fond bleu ciel, des champs très clairs bordés en bleu et des textes foncés. Les boutons restent verts ; les compteurs EA restent bleus et BT rouges.

## 1. Installation et première connexion

- Android 8.0 ou supérieur. L’APK ne s’installe pas sur iPhone.
- Ouvrir `SmartMobilityTerrain-3.1.1.apk`, autoriser son installation depuis votre gestionnaire de fichiers si Android le demande, puis installer.
- La signature est la même que celle des versions 1.0 et 2.0 : installer en mise à jour sans désinstaller pour conserver les données locales.
- Au premier lancement, créer un compte administrateur : identifiant de 3 à 40 caractères (`A-Z`, `a-z`, chiffres, point, tiret, underscore) et mot de passe d’au moins 8 caractères. Aucun mot de passe par défaut.
- Les anciens relevés de la version 1 sont conservés dans `LEGACY_V1`. Ils peuvent être exportés. Les anciennes données sans réseau ni ancienne date nécessitent une nouvelle liste complète pour les prochaines campagnes ; l’application ne les invente pas.
- Le bouton **Administrateur 🔒** demande l’identifiant et le mot de passe d’un compte administrateur. Après cinq échecs, une pause de 30 secondes s’applique. L’ouverture passe dans le profil administrateur ; se déconnecter puis se reconnecter au profil releveur pour reprendre sa tournée personnelle.

## 2. Administration

Le bouton Administrateur contient :

- Importer les compteurs et télécharger le modèle.
- Créer les comptes releveurs ou administrateurs.
- **Nommer les releveurs** : modifier leur nom complet.
- Affecter une tournée : campagne, réseau, UR, tournée et compte releveur. Seuls les contrats sans visite sont réaffectés, pour conserver les relèves déjà effectuées.
- Exporter/importer le catalogue d’anomalies : réseaux, cas de consommation, photo, deuxième passage.
- Régler les plages de jours des KPI de régularité : par défaut EA 20–30 jours, BT 28–32 jours.
- Définir la campagne courante (ex. `2026-10`). Les campagnes restent conservées ; il n’y a pas d’effacement automatique.
- Configurer un lien Google Drive personnel par compte releveur, dans Configurer les échanges. Aucun jeton ni URL de serveur nécessaire.
- Exporter l’historique des imports, affectations, relevés, accès administrateur, exports et synchronisations.

Les comptes, noms, profils, anomalies et affectations sont locaux au téléphone. Un releveur voit uniquement les contrats affectés à son identifiant. Le tableau de bord est local au téléphone. La distribution centralisée des comptes et des catalogues n’est pas intégrée.

## 3. Préparer une tournée

Compléter `Modele_compteurs_v2.xlsx` avec les colonnes suivantes :

| Champ | Règle |
|---|---|
| Reseau | `EA` ou `BT` |
| Contrat | Identifiant obligatoire |
| Nom | Nom du client |
| Adresse | Adresse du compteur |
| UR | Unité de relève obligatoire |
| Tournee | Tournée obligatoire |
| Numero compteur | Numéro de série obligatoire |
| Produit | Libellé eau/électricité ou valeur de votre produit |
| Ancien index | Nombre positif ou nul |
| Date ancienne releve | `jj/mm/aaaa` ou `aaaa-mm-jj` ; dates Excel numériques acceptées |
| Telephone | Valeur d’origine, conservée |
| Type local | Valeur d’origine, conservée |
| Statut photo | `OUI` = photo obligatoire ; vide = `NON` |
| Moyenne journaliere | Consommation moyenne de référence par jour |
| Taux variation | Pourcentage, ex. `30` pour ±30 % |
| Identifiant | IG, TOS ou autre identifiant terrain |
| Ordre de releve | Entier positif ou nul |
| Identifiant releveur | Nom du compte affecté, identique au compte de connexion |

Les dix premières colonnes doivent être présentes. Moyenne et taux doivent être renseignés ensemble ou laissés tous deux vides ; dans ce dernier cas, le contrôle de variation est désactivé pour le compteur. Les noms `Statut`, `Moyenne`, `N° compteur`, `Numero de serie`, `Ordre` et `Releveur` sont aussi reconnus.

Le modèle utilise des cellules texte pour conserver les zéros des contrats, compteurs et téléphones. XLSX : première feuille uniquement, sans formules. CSV : UTF-8, virgule ou point-virgule. Maximum 50 000 lignes ; CSV 20 Mo, XLSX 100 Mo décompressés.

L’import manuel depuis Administration conserve les lignes déjà présentes pour le même couple campagne/réseau/contrat/compteur/produit. Il ne remplace pas leurs anciens index ou leurs saisies. Corriger la source avant l’import initial. Pour le mois suivant, définir une nouvelle campagne puis importer les nouvelles données.

## 4. Télécharger la tournée depuis Google Drive

1. Remplir le modèle et déposer un véritable fichier XLSX ou CSV dans Drive, par exemple `ahmed_Eau.xlsx`.
2. Copier **le lien du fichier**, pas celui du dossier, puis l’envoyer au releveur.
3. Le releveur ouvre **Ma tournée / Synchroniser**, colle le lien dans **URL du fichier Google Drive**, puis clique **Synchroniser ma tournée**. Le lien est mémorisé pour son compte. L’administrateur peut également le renseigner dans Configurer les échanges, en choisissant le compte.
4. Après téléchargement et contrôle du fichier, l’application demande **Supprimer les anciennes données ?** :
   - **Oui, remplacer** : supprime l’ancienne liste du compte connecté, puis charge la nouvelle.
   - **Non, sauvegarder** : sauvegarde l’ancienne liste, ses saisies, ses photos et son fichier source s’il est disponible, puis charge la nouvelle.
   - **Annuler** : conserve la liste actuelle.

Le nouveau fichier est intégralement validé avant cette demande. En cas de téléchargement, de validation, de sauvegarde ou d’insertion impossible, l’ancienne liste n’est pas remplacée. Les données des autres comptes, les utilisateurs, les paramètres et le catalogue d’anomalies sont conservés. Les imports remplacés reçoivent une campagne datée automatiquement.

Les liens `drive.google.com/file/d/...` et `docs.google.com/spreadsheets/d/...` sont acceptés. Pour un lien de tableur, l’application tente le fichier Office original ou un export XLSX. Le paramètre `rtpof=true` donne la priorité au téléchargement du fichier original. Le contrôle de taille et des colonnes intervient avant tout remplacement.

Un lien accessible sans connexion peut être téléchargé directement. **Pour un fichier privé**, ou si Google demande une connexion/confirmation, utiliser **Importer le fichier depuis votre téléphone** : dans le sélecteur Android, sélectionner le fichier XLSX/CSV dans Téléchargements ou dans un dossier du téléphone. Pour un fichier privé sur Drive, sélectionner Drive puis le compte Google autorisé et le fichier. Drive doit être installé et proposer ce fichier au sélecteur. L’URL seule ne donne pas les droits d’accès à un fichier privé. Ne modifier les permissions de partage que conformément à vos règles de protection des données clients.

La colonne Identifiant releveur doit être vide ou identique au compte connecté. Une valeur différente provoque le refus du fichier complet. Le nom de fichier est indicatif : c’est le lien individuel et cette colonne qui déterminent l’affectation ; l’application ne recherche pas tous les fichiers d’un dossier. Elle ne vérifie pas l’identité Google pour un lien accessible sans connexion.

### Mes sauvegardes

Le bouton **Mes sauvegardes** affiche les archives du compte connecté. Chaque sauvegarde propose : **Exporter la sauvegarde**, **Envoyer cette sauvegarde vers Drive**, et **Restaurer cette tournée**. La restauration sauvegarde d’abord la tournée actuelle, puis remet les anciens champs et relevés avec leurs photos. Une archive d’un autre compte est refusée. Les sauvegardes locales sont conservées après les changements de tournée.

Une sauvegarde ZIP contient `releves.xlsx`, `releves.csv`, les photos, le manifeste de restauration et, si disponible, le fichier source téléchargé. L’import XLSX/CSV ordinaire recharge uniquement les données initiales ; utiliser Restaurer pour récupérer les saisies. La restauration depuis cet écran utilise les archives présentes sur le téléphone. La réimportation d’une archive exportée sur un autre téléphone n’est pas proposée par cette version.

Le téléchargement est limité à 20 Mo. La restauration d’une sauvegarde utilise au maximum 300 Mo décompressés au total et 100 Mo par entrée. Conserver les exports sur Drive avant de désinstaller ou de perdre le téléphone.

## 5. Navigation et saisie

Choisir la campagne et la tournée. **Affichage des données** propose `Tous` ou `Par UR` ; dans le second cas, sélectionner l’UR. **Liste des contrats** propose `Tous`, `Relevés` (index renseigné) et `Non relevés` (aucun index, même si une visite avec anomalie a été enregistrée). Les compteurs sont regroupés par campagne/UR/tournée, puis triés numériquement par **Ordre de relève**. Les lignes sans ordre sont placées après celles qui en ont un.

- Après une validation réussie, le compteur suivant de la sélection s’ouvre automatiquement.
- **Précédent / Suivant** permettent de revenir voir une relève ou d’avancer sans la valider.
- Glissement horizontal vers la gauche : suivant ; vers la droite : précédent.
- Le défilement vertical et les gestes dans le champ de saisie restent dédiés à la saisie. Un déplacement horizontal net d’au moins 90 dp est nécessaire.
- Une saisie non enregistrée déclenche un avertissement avant de changer de compteur.
- La sélection est conservée pendant la navigation : revenir au précédent reste possible même après avoir validé son index.

La zone du numéro de compteur est **bleue pour EA** et **rouge pour BT**. Recherche : contrat, compteur, UR, identifiant, nom ou adresse. Maximum 150 résultats visibles ; la navigation utilise toute la sélection, y compris au-delà des 150 lignes affichées.

Saisir le nouvel index, choisir l’anomalie si nécessaire, puis saisir le commentaire. Les listes d’anomalies dépendent du réseau et du cas : `NEGATIF`, `ZERO`, `POSITIF`, `SANS_INDEX`. Un compteur hors liste utilise `SANS_REFERENCE` s’il a un index sans ancien index.

Une visite sans index nécessite une anomalie compatible. Un index inférieur nécessite une anomalie, un commentaire, une deuxième saisie identique et une photo. Les codes `DEMO_` fournis sont des exemples à remplacer par les codes officiels du SI.

## 6. Contrôles, photo et GPS

- Consommation = nouvel index − ancien index.
- Nombre de jours = date système du jour − date de l’ancienne relève.
- CMJ = consommation / nombre de jours.
- Une CMJ strictement hors `moyenne × (1 ± taux/100)` déclenche une alerte. Aux bornes exactes, elle reste dans le seuil. Si la moyenne est zéro, une consommation positive est anormale.
- Une date système antérieure à l’ancienne date est refusée. Une relève chiffrée avec la même date que l’ancienne est refusée.
- Pour un index anormal : **ressaisir d’abord l’index, puis prendre la photo**. Modifier l’index ensuite oblige à refaire la confirmation et la photo.
- Photo obligatoire si le statut importé vaut OUI, si l’anomalie l’impose, si la consommation est anormale, si l’index est inférieur, ou pour un compteur hors liste.

La photo est prise avec l’application caméra du téléphone et conservée en JPEG dans l’application. Nom : contrat (ou compteur hors liste) + date/heure + suffixe unique. Les images sont réduites à environ 1 600 pixels pour faciliter l’envoi. Les photos font partie des archives ZIP ; un XLSX/CSV seul contient leurs noms, pas les images.

La date et l’heure sont celles du téléphone à chaque validation ; vérifier le réglage automatique et le fuseau. Le GPS est recherché automatiquement pendant 20 secondes : **X = longitude**, **Y = latitude**, degrés décimaux, précision enregistrée. Si la position est indisponible, réessayer ou confirmer une relève sans coordonnées ; aucune ancienne position n’est recopiée.

## 7. Téléphone et type local

Les valeurs importées sont affichées et **restent conservées** dans `Telephone` et `Type local`. Le releveur modifie les champs **Nouveau téléphone** et **Nouveau type local**.

L’export contient `Nouveau telephone` et `Nouveau type local`. Si la valeur saisie est identique à la valeur d’origine, la colonne nouvelle reste vide. Une valeur vide ne constitue pas une instruction de suppression dans le système central.

L’export distingue :

- `Identifiant releveur` : compte affecté à la ligne.
- `Identifiant releveur effectif` : compte ayant validé la relève.
- `Nom du releveur` : nom complet de ce compte au moment de la validation.

Renommer un releveur n’altère pas le nom conservé dans ses anciennes relèves. Une nouvelle validation enregistre son nom actuel et la nouvelle date.

## 8. Deuxième passage et compteur hors liste

Une anomalie paramétrée avec deuxième passage ou la case **Prévoir un deuxième passage** place la ligne dans `A_REPASSER`. Utiliser le bouton **Contrats pour deuxième passage** pour reprendre ces visites. Décocher cette case lors de la reprise résolue. La prochaine validation conserve l’historique et incrémente le numéro de passage.

**Nouveau compteur hors liste** ouvre un formulaire : réseau, UR, numéro de compteur, index éventuel, anomalie, commentaire, photo et coordonnées. Photo et anomalie obligatoires. La date est automatique ; un UUID permet de conserver ce cas sans inventer de contrat ou d’ancien index. Ces cas sont exclus des KPI des contrats importés.

## 9. Export et envoi vers Drive

**Exporter Excel / CSV / photos** propose XLSX, CSV ou ZIP contenant les deux tableaux et les JPEG associés. L’export porte sur toutes les lignes autorisées au compte, sans appliquer les filtres visuels. L’administrateur peut exporter l’ensemble du téléphone. Pour enregistrer dans Drive, choisir Drive dans le sélecteur de destination Android.

**Envoyer les relevés vers Drive** prépare une archive personnelle contenant les tableaux et les photos, puis ouvre le partage Android : choisir Drive, le compte et le dossier, puis confirmer l’enregistrement dans Drive. Le nom contient l’identifiant du releveur, la date et un suffixe unique. Pour obtenir un fichier `nomreleveur_produit.xlsx`, utiliser l’export XLSX.

Le téléchargement par lien ne permet pas d’écrire automatiquement dans le Drive du propriétaire. Le dépôt des résultats nécessite l’action de l’utilisateur dans le sélecteur ou dans Drive. Le partage ne constitue pas un accusé de réception de la facturation ; l’application ne marque pas les lignes comme reçues par un système central. La synchronisation automatique au retour d’Internet et le tableau de bord central ne sont pas inclus dans cette version sans serveur.

Les relevés sont enregistrés localement avec le statut `LOCAL`, les données initiales avec `NON_ENVOYE`. Les anciens statuts des versions précédentes restent conservés. Aucune ancienne configuration de serveur ne provoque un envoi automatique dans cette version.

## 10. KPI et conservation

Le tableau de bord présente par campagne/releveur/UR/tournée/réseau : relève, non relevés, anomalies, deuxième passage, régularité. Objectifs affichés : relève et régularité ≥99 %, anomalies ≤1 %. Les dénominateurs et formules sont affichés dans l’application.

Les visites sans index ne comptent pas comme une relève chiffrée. La régularité utilise uniquement les relevés chiffrés avec un intervalle calculable. Le tableau local ne regroupe pas les autres téléphones.

Exporter régulièrement les tableaux et les photos. Désinstaller, effacer les données ou perdre le téléphone peut faire perdre les données locales. Les fichiers et la base sont dans l’espace privé Android ; la sauvegarde automatique Android et les captures d’écran de l’application sont désactivées. La base locale n’est pas chiffrée par l’application. Les exports doivent être protégés conformément aux règles de votre organisation.

## 11. Vérifications et limites

La compilation et la signature APK sont vérifiées. 77 vérifications JVM ont réussi : règles d’index et de consommation, XLSX/CSV, catalogue, valeurs initiales/nouvelles, liens Drive et refus des pages HTML, sauvegarde/restauration exacte des 42 champs, photos et fichier source, refus d’un autre propriétaire et d’une photo manquante.

Aucun appareil Android n’a été disponible. Le format du lien fourni a permis de corriger le refus, mais le téléchargement réel de ce fichier n’a pas pu être vérifié depuis cet environnement. L’installation, le rendu des couleurs, les gestes, la caméra, le GPS, le fournisseur de fichiers Drive et le remplacement SQLite restent à vérifier sur téléphone avant déploiement. Installer en mise à jour, puis essayer un petit fichier et les trois choix Oui/Non/Annuler, avec les cas fichier privé, sans réseau et fichier invalide.

Les codes officiels d’anomalies et le raccordement au système de facturation restent à définir. Les codes DEMO_ sont des exemples. Les données sont sauvegardées localement sans serveur ; ce logiciel ne constitue pas une intégration certifiée avec votre système de facturation.

## Mise à jour 3.1.1

Le bouton d’import s’appelle désormais **Importer le fichier depuis votre téléphone**. Il ouvre le sélecteur Android de fichiers, pour sélectionner un XLSX/CSV local ou un fichier accessible via Drive. Le téléchargement par URL et les contrôles restent identiques.
