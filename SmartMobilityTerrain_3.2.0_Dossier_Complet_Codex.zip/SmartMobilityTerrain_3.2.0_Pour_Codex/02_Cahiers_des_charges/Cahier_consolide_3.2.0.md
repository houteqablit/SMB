# Cahier des charges consolidé — SmartMobility Terrain 3.2.0

## 0. Livrables et priorité
1. APK Android 3.2.0 **installable en parallèle** de 3.1.1 ; utiliser un **applicationId différent**, par exemple `ma.releve.terrain.v320`, pour éviter tout écrasement de l'installation précédente.
2. Modèle XLSX 3 feuilles (`Releve`, `Anomalie`, `type_local`) et CSV séparés.
3. Projet source Android reproductible et documentation de compilation si possible. La clé privée 3.1.1 n'est pas disponible et n'est pas nécessaire à l'installation parallèle.
4. Exécuter tests d'import, base SQLite, UI, caméra, GPS, sauvegarde, export et installation ; signaler les tests non réalisés.

## 1. Socle 3.1.1 à préserver
Reprendre les fonctionnalités du guide historique joint : comptes locaux, administrateur, affectation tournée/UR, relevés EA/BT, navigation, recherche, index, anomalies, deuxième passage, hors-liste, contrôle CMJ, photos, GPS, KPI, sauvegardes ZIP, restauration, export XLSX/CSV/ZIP, partage Drive via Android et import depuis téléphone. Ne pas retirer silencieusement une fonctionnalité existante.

## 2. Import unique XLSX et CSV
- Le classeur `.xlsx` doit contenir **exactement les feuilles nommées** `Releve`, `Anomalie`, `type_local` (les autres feuilles éventuelles : définir explicitement refus ou ignorance).
- `Releve` : conserver au minimum les 18 champs documentés dans le guide 3.1.1. Ne pas utiliser sans adaptation le modèle simplifié de 14 champs antérieurement proposé. Préserver zéros initiaux dans contrats, compteurs, téléphones, identifiants et codes.
- `Anomalie` : charger codes/libellés et paramètres métier du catalogue, et **remplacer** l'ancien catalogue après validation. Vérifier la correspondance avec les cas historiques NEGATIF, ZERO, POSITIF, SANS_INDEX, SANS_REFERENCE et les indicateurs photo/deuxième passage. Le modèle fourni propose des colonnes ; mapper aux structures réelles après analyse.
- `type_local` : charger codes/libellés et **remplacer** la liste précédente après validation. Afficher les valeurs existantes même si elles ne figurent plus dans le nouveau catalogue, sans les modifier silencieusement.
- CSV : trois fichiers séparés `Releve.csv`, `Anomalie.csv`, `type_local.csv`, UTF-8 avec BOM facultatif et séparateur `;`. Import groupé des trois CSV ou ZIP contenant ces trois CSV : **à implémenter et documenter** ; un CSV unique ne peut contenir trois feuilles.
- Synchronisation **atomique** : vérifier trois sources avant toute mutation ; si une est invalide, ne rien remplacer. Les anciennes données des autres releveurs restent intactes. Préserver les règles de compte connecté/affectation.

## 3. Confirmation, sauvegarde et envoi
- Avant tout remplacement de la liste `Releve`, afficher une fenêtre avec : **Sauvegarder / Exporter**, **Envoyer les relèves**, **Confirmer le remplacement**, **Annuler**.
- Sauvegarder/exporter et envoyer ne déclenchent **jamais** automatiquement le remplacement ; revenir à la confirmation.
- Le remplacement ne commence qu'après action explicite `Confirmer le remplacement`.
- Annuler ne change ni compteurs, ni anomalies, ni types de local.
- Proposer une sauvegarde ZIP incluant saisies, photos, source et catalogues quand nécessaire. En cas d'échec d'import/sauvegarde, ne pas supprimer les anciennes données.
- Le partage Android vers Drive ne prouve pas que le fichier est effectivement reçu ; ne pas afficher `envoyé` sans preuve.

## 4. Ecran principal
- Après authentification, afficher la liste des compteurs s'il y a des données ; sinon afficher exactement **« Pas de compteurs chargés »**.
- Trois points en haut à gauche ouvrent le menu principal, avec les fonctionnalités de la version 3.1.1 : tableau de bord, administrateur, ma tournée/synchroniser, sauvegardes, nouveau compteur hors liste, exporter, envoyer vers Drive, retour, déconnexion.
- Un clic sur un compteur ouvre le formulaire de relève.

## 5. Formulaire de relève
- `Type local` : afficher la valeur d'origine et proposer une liste déroulante issue de `type_local`, modifiable par releveur.
- `Telephone` : afficher la valeur d'origine, icône stylo à droite ; permettre ajout ou modification.
- Au déchargement, conserver `Telephone` et `Type local` originaux et ajouter **deux champs distincts** `Nouveau telephone`, `Nouveau type local`. Si pas de changement ou même valeur, nouveaux champs vides. Ne pas écraser les originaux.
- Index anormal : après première saisie, **effacer le champ de saisie visible**, afficher une demande de ressaisie dans **ce même champ**, conserver la première valeur seulement en mémoire pour comparaison ; bloquer la validation si différent. Ne pas créer un deuxième champ d'index. Si index changé ensuite, réinitialiser confirmation et photo obligatoire.
- GPS : supprimer le bouton manuel X/Y ; déclencher acquisition automatiquement lors de validation, sans bloquer indéfiniment. X=longitude, Y=latitude, précision/date si disponibles ; demander une décision explicite si GPS indisponible selon politique 3.1.1. Ne jamais réutiliser des coordonnées anciennes.
- Photo : icône appareil photo à droite de `Nouvel index`, avec possibilité de consulter la photo via icône ; privilégier les pictogrammes aux libellés `Prendre photo`/`Voir photo`. Conserver les photos obligatoires selon anomalies/CMJ/statut/hors liste.

## 6. Design
Ne pas copier les couleurs des trois captures : elles ne sont que des références fonctionnelles. Préférer l'identité de 3.1.1 modernisée : fond très clair, textes foncés, bleu pétrole #176B87, vert #218567 pour validation, orange #E6A23C pour avertissements, rouge #D9534F pour erreurs ; garder la distinction EA bleu / BT rouge. Ergonomie tactile lisible en extérieur.

## 7. Compatibilité, confidentialité et robustesse
- Installation indépendante de 3.1.1 ; les données ne sont pas partagées automatiquement entre les deux applications.
- Ne pas inclure de vrais clients, identifiants, mots de passe ou clés de signature dans le dépôt public.
- Préserver les sauvegardes, les règles d'authentification et les fichiers privés ; protéger les exports.
- Gérer fichiers XLSX tronqués, erreurs ZIP/ZLIB, champs vides, dates Excel, nombres, encodage, doublons, catalogue vide et import partiel ; messages d'erreur précis.
- Documenter explicitement le format réel de la feuille `Anomalie` en fonction de l'ancien schéma et la gestion des listes de valeurs absentes.

## 8. Critères d'acceptation
- Les trois feuilles valides chargent simultanément compteurs, anomalies et types de local ; les deux catalogues précédents sont remplacés.
- Un fichier invalide conserve intégralement les données anciennes.
- `Annuler` conserve toutes les données ; sauvegarde/envoi n'effacent rien ; confirmation remplace uniquement les données du compte concerné.
- La liste vide affiche le message exact ; menu accessible ; formulaire ouvert au toucher.
- `Nouveau telephone` et `Nouveau type local` figurent dans l'export et les champs initiaux sont inchangés.
- Index anormal redemandé dans le même champ ; GPS automatique ; icônes photo fonctionnelles.
- L'APK 3.2.0 s'installe à côté de la 3.1.1 et démarre sur Android 8+.
