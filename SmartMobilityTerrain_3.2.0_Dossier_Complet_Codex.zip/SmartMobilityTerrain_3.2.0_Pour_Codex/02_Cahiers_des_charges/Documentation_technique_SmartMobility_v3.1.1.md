# SmartMobility Terrain 3.1.1 — documentation technique

Android natif Java, package `ma.releve.terrain`, Android 8+ (minSdk 26), compile/target 35. Interface bleu ciel, champs remplis #F7FCFF et bordure #5A9DBD ; boutons #007C70 conservés. EA #1C69B4, BT #BA303B.

## Compilation

Installer Java 17, SDK Android Platform 35, Build Tools 35.0.0. Définir ANDROID_SDK_ROOT puis exécuter `bash build.sh`. Le script compile les ressources et le Java, produit le DEX, aligne et signe `build/SmartMobilityTerrain-3.1.1.apk`. Gradle utilise aussi la configuration de signature du projet.

L’archive projet contient la clé privée et son mot de passe pour reproduire les mises à jour signées. Conserver le projet confidentiel ; distribuer uniquement l’APK. Ne pas changer la clé ou le package pour mettre à jour une installation existante.

## Composants

- Model : 42 colonnes internes, contrôles d’index, date et moyenne journalière.
- TableFile : import/export XLSX et CSV, validation des colonnes, limites de taille, contrôle des doublons, neutralisation des formules exportées.
- Store : SQLite local, comptes PBKDF2 salés, rôles, catalogue, historique, transactions.
- MainActivity : formulaires, navigation ordonnée et gestes, GPS, caméra, administration, sélecteur Android de documents, partage vers Drive.
- DirectDrive : normalisation des liens HTTPS de fichiers Google Drive, resourcekey conservée, redirections HTTPS Google limitées, temporisations, maximum 20 Mo, refus HTML/connexion. Aucun cookie ou jeton OAuth n’est transmis. Un lien privé nécessite le sélecteur Android et le compte Google du téléphone.
- LocalTransfer : validation avant confirmation, capture de révision, sauvegarde durable avant remplacement, source originale conservée, remplacement atomique du compte connecté.
- BackupPack : ZIP autonome, XLSX/CSV, photos et source binaire, manifeste `backup.dat` versionné (UTF-8 à longueurs explicites), restauration exacte des 42 valeurs ; propriétaire, champs, UUID, doublons et photos contrôlés.
- PhotoProvider / ExportProvider : fichiers privés, URI de contenu à autorisation temporaire, accès limité aux noms valides, lecture seule des exports partagés.

## Import sans serveur

Le lien accepté vise un fichier, par exemple `https://drive.google.com/file/d/IDENTIFIANT/view`, `open?id=...`, `uc?id=...` ou `drive.usercontent.google.com/download?id=...`. Les liens de dossiers sont refusés. Les liens HTTPS `docs.google.com/spreadsheets/d/ID/edit` sont également acceptés : `/export?format=xlsx` pour un tableur Google et `drive.google.com/uc?export=download&id=ID` pour le mode Office (`rtpof=true`), avec une tentative alternative en cas de refus. Les paramètres ouid/usp/sd ne sont pas transmis au téléchargement. resourcekey est conservée. Cette prise en charge ne change pas les permissions Google. Le téléchargement dépend des autorisations de Google ; une page de connexion n’est jamais importée comme une tournée.

Le fichier est associé au compte connecté : colonne releveur vide = affectation au compte ; autre identifiant = refus complet. Il n’y a pas de découverte ni de filtrage serveur d’un dossier Drive. Les comptes locaux ne confèrent pas des droits Google.

Le retour des relevés vers Drive utilise ACTION_CREATE_DOCUMENT ou ACTION_SEND avec validation par l’utilisateur. Aucun chargement authentifié automatique dans le Drive du propriétaire n’est implanté. Aucun serveur de facturation, tâche de synchronisation en arrière-plan ou tableau de bord central n’est livré dans ce projet.

## Remplacement et sauvegardes

SQLite version 3 ajoute `sauvegardes(owner,filename,created,count)` et `chargements(owner,source)` aux tables existantes. La migration de version 2 conserve compteurs, comptes, catalogue et audit. La migration de version 1 conserve les lignes dans LEGACY_V1.

Avant mutation : télécharger/lire le fichier, valider intégralement, montrer Oui/Non/Annuler. Non écrit et synchronise une archive locale puis la renomme ; une erreur interrompt le remplacement. Le fichier source nouveau est également écrit durablement. Une transaction vérifie la révision, supprime uniquement `releveur=compte`, insère toutes les lignes sans ignorer les collisions, met à jour la source, enregistre la sauvegarde et l’audit, puis incrémente la révision. Une collision avec une ligne d’un autre compte provoque un rollback.

Après succès, le nettoyage des anciennes photos retire seulement celles qui ne sont plus référencées par aucun compte. Les archives ZIP conservent leurs copies. Le nettoyage est effectué au mieux ; une interruption peut laisser des fichiers inutilisés sans altérer les nouvelles lignes. Les sources/archives créées avant une interruption peuvent également rester orphelines. L’audit antérieur est conservé.

La restauration lit une archive connue du compte et valide ses champs, identités et photos. Elle sauvegarde la tournée courante avant remplacement. Les JPEG sont récupérés sans écraser un contenu différent portant le même nom. Limites : 100 Mo par entrée, 300 Mo décompressés au total, 100 000 relevés ; mémoire disponible du téléphone peut imposer une limite pratique plus faible. L’écran de restauration liste les archives locales, sans import d’une archive externe.

## Vérification

Compiler les sources et tests avec le jar Android, puis exécuter CoreTests avec un chemin de sortie XLSX, DriveTests et BackupTests. Les 77 contrôles host JVM ont réussi (31 + 20 + 10 + 16). SheetsLinkTests couvre Office/Sheets, export XLSX, fallback, refus des faux domaines, HTML, caractères invisibles et parsing XLSX. Ils couvrent les règles et les fichiers, pas les API Android/SQLite en fonctionnement.

APK compilée, alignée et signature v2/v3 vérifiée, versionCode 5. Aucun téléphone/émulateur Android n’a été utilisé. Un lien réel a été fourni pour le diagnostic, mais son téléchargement n’a pas été accessible depuis cet environnement. Recette obligatoire : mise à jour V2, affichage, comptes, Oui/Non/Annuler, sauvegarde/restauration, fichier invalide, autorisations privées, panne réseau, photo/GPS et partage Drive. Le rendu visuel n’a pas été contrôlé sur un écran Android.

## Protection

Fichiers et base privés Android, sauvegarde Android automatique désactivée, FLAG_SECURE actif. La base applicative n’est pas chiffrée. Le partage n’accorde qu’une lecture temporaire du fichier choisi. Appliquer les règles de protection des données clients à Drive et aux exports. Aucun mot de passe d’administration par défaut.

Sources de fonctionnement Drive : [partager des fichiers](https://support.google.com/drive/answer/2494822?hl=fr), [sélecteur de documents Android](https://developer.android.com/training/data-storage/shared/documents-files).

## Mise à jour 3.1.1

Libellé d’import remplacé par « Importer le fichier depuis votre téléphone » ; messages d’aide et bouton de secours cohérents. ACTION_OPEN_DOCUMENT conservé pour les fichiers locaux et les fournisseurs Android. Aucun changement de validation ou de stockage.
