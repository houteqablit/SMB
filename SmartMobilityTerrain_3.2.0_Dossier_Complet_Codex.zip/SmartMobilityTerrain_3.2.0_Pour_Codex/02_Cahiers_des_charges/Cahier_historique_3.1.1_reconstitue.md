# Cahier des charges historique — SmartMobility Terrain 3.1.1 (08/10/2026)

Ce document reconstitue les exigences à partir du **Guide_SmartMobility_v3.1.1.md** et de la **Documentation_technique_SmartMobility_v3.1.1.md**, tous deux retrouvés. Les deux originaux complets sont joints et font autorité sur la version 3.1.1. Le code source original, le script build.sh et la clé de signature ne figurent pas dans les fichiers retrouvés : ne pas prétendre les avoir.

## Objectif et architecture
Android natif Java, package historique `ma.releve.terrain`, Android 8+ (minSdk 26), cible 35. Relevé EA/BT hors connexion, comptes locaux administrateur/releveur, SQLite, import XLSX/CSV, photos, GPS, sauvegardes ZIP, Drive via partage/sélecteur Android. UI historique bleu ciel, boutons verts, EA bleu et BT rouge.

## Administration
Création des comptes et noms complets, affectations par campagne/réseau/UR/tournée, import des compteurs, catalogue des anomalies, plages de régularité EA 20–30 jours / BT 28–32 jours, historique des opérations, lien Drive individuel. Authentification avec PBKDF2 salé ; aucun mot de passe admin par défaut.

## Import 3.1.1
18 colonnes documentées dans le guide original ; les dix premières obligatoires. Contrôles sur index/date/moyenne et taux, propriétaire releveur, doublons, taille et formules. XLSX première feuille seulement ; CSV UTF-8 virgule ou point-virgule. Import local depuis téléphone (libellé exact 3.1.1) ou téléchargement via URL de fichier Drive autorisé. Pas d'exploration automatique de sous-dossiers Drive. Avant remplacement, valider la source et permettre Oui remplacer / Non sauvegarder / Annuler. Sauvegarde et restauration des 42 champs, photos et source si disponible.

## Relève
Liste par campagne, UR, tournée, réseau ; filtres Tous/Relevés/Non relevés ; tri par ordre numérique ; recherche ; précédent/suivant et gestes ; auto-navigation après validation ; confirmation avant abandon de saisie. Index, anomalies conditionnées par réseau/cas, commentaires, deuxième passage, hors-liste. Index inférieur ou variation anormale : confirmation identique et photo selon règles. GPS à validation (X longitude, Y latitude), horodatage, conservation du nom des photos.

## Export
XLSX/CSV/ZIP photos ; originaux Telephone et Type local conservés ; nouveaux champs Nouveau telephone / Nouveau type local ; identifiants releveur affecté/effectif et nom effectif. Partage Drive par sélecteur Android, sans transfert authentifié automatique. KPI locaux par campagne/releveur/UR/tournée/réseau.

## Limites historiques
Aucun serveur central, aucune synchronisation automatique des fichiers d'un dossier Drive, aucune certification de raccordement SI. L'ancienne APK a été compilée/signée et des tests JVM ont été annoncés, mais aucune recette sur téléphone n'est documentée. Le code source n'est pas inclus ici.
