package ma.releve.terrain.v320;
import android.app.*;
import android.content.*;
import android.os.*;
import android.widget.*;
import java.io.*;
import java.util.*;

public class DeviceTests extends Instrumentation {
    int checks;
    void check(boolean b,String name){checks++;if(!b)throw new AssertionError(name);}
    void awaitUi(java.util.function.BooleanSupplier condition)throws Exception {
        final boolean[] done={false};long deadline=SystemClock.elapsedRealtime()+15000;
        do {runOnMainSync(()->done[0]=condition.getAsBoolean());if(done[0])return;Thread.sleep(100);}while(SystemClock.elapsedRealtime()<deadline);
        throw new AssertionError("asynchronous UI did not finish");
    }
    interface Checked{void run()throws Exception;}
    void rejects(Checked f,String name)throws Exception{try{f.run();}catch(Exception e){checks++;return;}throw new AssertionError(name);}
    @Override public void onCreate(Bundle b){super.onCreate(b);start();}
    @Override public void onStart(){
        Bundle result=new Bundle();
        try {
            Context ctx=new ContextWrapper(getTargetContext()) {
                String testName(String name){return "instrumentation_"+name;}
                public android.database.sqlite.SQLiteDatabase openOrCreateDatabase(String name,int mode,android.database.sqlite.SQLiteDatabase.CursorFactory factory){return getBaseContext().openOrCreateDatabase(testName(name),mode,factory);}
                public android.database.sqlite.SQLiteDatabase openOrCreateDatabase(String name,int mode,android.database.sqlite.SQLiteDatabase.CursorFactory factory,android.database.DatabaseErrorHandler error){return getBaseContext().openOrCreateDatabase(testName(name),mode,factory,error);}
                public File getDatabasePath(String name){return getBaseContext().getDatabasePath(testName(name));}
                public android.content.SharedPreferences getSharedPreferences(String name,int mode){return getBaseContext().getSharedPreferences("instrumentation_"+name,mode);}
                public boolean deleteDatabase(String name){return getBaseContext().deleteDatabase(testName(name));}
                public File getFilesDir(){File dir=new File(getBaseContext().getFilesDir(),"instrumentation-test-files");dir.mkdirs();return dir;}
            };
            ctx.deleteDatabase("releve.db");
            Store db=new Store(ctx);
            check(!db.hasUsers(),"no default credentials");
            db.user("releveur01","Testing123!","RELEVEUR","Nom Test","setup");
            db.user("other","Testing456!","RELEVEUR","Autre","setup");
            check(db.login("releveur01","Testing123!").equals("RELEVEUR"),"PBKDF2 login");
            check(db.login("releveur01","wrong")==null,"wrong password");
            rejects(()->db.changePassword("releveur01","wrong","Updated123!","Updated123!"),"password change rejects wrong current password");
            rejects(()->db.changePassword("releveur01","Testing123!","short","short"),"password change minimum length");
            rejects(()->db.changePassword("releveur01","Testing123!","Updated123!","Mismatch123!"),"password confirmation required");
            check("RELEVEUR".equals(db.login("releveur01","Testing123!")),"rejected change preserves old password");
            db.changePassword("releveur01","Testing123!","Updated123!","Updated123!");
            check(db.login("releveur01","Testing123!")==null,"old password revoked");
            check("RELEVEUR".equals(db.login("releveur01","Updated123!")),"new password works and role preserved");
            check("RELEVEUR".equals(db.login("other","Testing456!")),"other account password unchanged");
            db.user("administrator","AdminTest123!","ADMIN","Admin Test","setup");
            db.changePassword("administrator","AdminTest123!","AdminUpdated123!","AdminUpdated123!");
            check(db.login("administrator","AdminTest123!")==null&&"ADMIN".equals(db.login("administrator","AdminUpdated123!")),"administrator password change");
            byte[] bytes;
            try(InputStream in=getTargetContext().getAssets().open("Modele_SmartMobilityTerrain_5.1.4.xlsx")){bytes=TableFile.limited(in,20971520);}
            BundleImport bundle=BundleImport.read(bytes,"releveur01");
            for(String[] row:bundle.meters)row[Model.CAMPAIGN]="test";
            bundle.meters.get(0)[Model.ORDER]="2";bundle.meters.get(1)[Model.ORDER]="10";
            Collections.reverse(bundle.meters);
            db.replaceBundle("releveur01",bundle.meters,db.revision(),"","",0,bundle);
            check(db.list("releveur01",false,"",null,null,null,0).get(0).a[Model.ORDER].equals("2"),"numeric reading order independent of Excel rows");
            check(db.ownRows("releveur01").size()==2,"SQLite three-source import");
            check(db.anomalies(null,null).size()==3,"anomaly replacement");check(db.typeRows().size()==4,"type replacement");
            check(db.list("releveur01",false,"",null,null,"_NON_RELEVES",0).size()==2,"not read filter");
            check(db.list("releveur01",false,"",null,null,null,1).size()==1,"limit");
            check(db.list("other",false,"",null,null,null,0).isEmpty(),"account isolation");
            String[] other=bundle.meters.get(0).clone();other[Model.C]="other-contract";other[Model.READER]="other";other[Model.UUID_]=UUID.randomUUID().toString();
            db.add(Collections.singletonList(other),"test","setup");
            long rev=db.revision();
            String[] collision=other.clone();collision[Model.READER]="releveur01";
            rejects(()->db.replaceBundle("releveur01",Collections.singletonList(collision),rev,"","",0,bundle),"collision rollback");
            check(db.ownRows("releveur01").size()==2,"rollback keeps existing meters");check(db.ownRows("other").size()==1,"other owner preserved");check(db.revision()==rev,"rollback keeps revision");
            List<String[]> brokenTypes=new ArrayList<>(bundle.types);brokenTypes.add(bundle.types.get(0));
            BundleImport broken=new BundleImport(bundle.meters,bundle.anomalies,brokenTypes);
            rejects(()->db.replaceBundle("releveur01",bundle.meters,rev,"","",0,broken),"catalog failure rolls back entire transaction");
            check(db.typeRows().size()==4&&db.ownRows("releveur01").size()==2,"catalog+meter atomicity");check(db.revision()==rev,"catalog failure revision rollback");
            rejects(()->db.replaceBundle("releveur01",bundle.meters,rev-1,"","",0,bundle),"stale revision");
            Store.Record r=db.list("releveur01",false,"",null,null,null,0).get(0);
            r.a[8]=bundle.anomalies.get(0)[0];r.a[Model.NEW]="1400";r.a[Model.DATE]="11/10/2026 12:00:00";r.a[Model.NEWTEL]="0700000000";r.a[Model.NEWLOCAL]="COMMERCE";r.a[Model.ACTOR]="releveur01";r.a[Model.ACTORNAME]="Nom Test";r.a[Model.STATE]="A_REPASSER";
            db.save(r,"releveur01");
            check(db.get(r.id).a[Model.TEL].equals("0612345678"),"original phone immutable");
            check(db.get(r.id).a[Model.NEWTEL].equals("0700000000"),"new phone independent");
            check(db.list("releveur01",false,"",null,null,"_RELEVES",0).size()==1,"read filter");
            check(db.list("releveur01",false,"",null,null,"A_REPASSER",0).size()==1,"second passage");
            check(db.export("releveur01",false).size()==3,"all authorized export");
            check(db.exportVisited("releveur01").size()==2&&db.exportVisited("releveur01").get(1)[Model.DATE].equals(r.a[Model.DATE]),"Drive exports only visited dates");
            check(db.exportVisited("other").size()==1,"unvisited other reader excluded");
            List<String[]> exported=db.export("releveur01",false);
            String[] exportedReading=null;for(String[] row:exported)if(row[Model.SER].equals(r.a[Model.SER]))exportedReading=row;
            check(exportedReading!=null&&exportedReading[8].equals(r.a[8])&&exportedReading[Model.LABELS.length].equals(bundle.anomalies.get(0)[1]),"export retains anomaly code and label");
            ByteArrayOutputStream excel=new ByteArrayOutputStream();TableFile.writeXlsx(excel,exported);
            List<String[]> excelRows=TableFile.read(new ByteArrayInputStream(excel.toByteArray()));
            check(excelRows.get(0)[8].equals("Code anomalie")&&excelRows.get(0)[Model.LABELS.length].equals("Libelle anomalie")&&excelRows.stream().anyMatch(row->row.length>Model.LABELS.length&&row[8].equals(r.a[8])&&row[Model.LABELS.length].equals(bundle.anomalies.get(0)[1])),"real Excel includes anomaly code and label");
            ByteArrayOutputStream csv=new ByteArrayOutputStream();TableFile.writeCsv(csv,exported);
            check(new String(csv.toByteArray(),java.nio.charset.StandardCharsets.UTF_8).contains(bundle.anomalies.get(0)[1]),"CSV includes anomaly label");
            ByteArrayOutputStream again=new ByteArrayOutputStream();TableFile.writeXlsx(again,exported);
            check(Arrays.equals(excel.toByteArray(),again.toByteArray()),"stable Excel bytes enable idempotent retry");
            DriveUpload.configure(ctx,"https://script.google.com/macros/s/TEST_DEPLOYMENT/exec","releveur01","ONLY_TEST_KEY_012345678901234567890123456789");
            check(DriveUpload.secret(ctx,"releveur01").equals("ONLY_TEST_KEY_012345678901234567890123456789"),"Keystore encrypted transfer key round trip");
            check(!DriveUpload.prefs(ctx).getString("key_releveur01","").contains("ONLY_TEST_KEY"),"transfer key not stored as plaintext");
            rejects(()->DriveUpload.secret(ctx,"not_configured"),"unconfigured reader blocked");
            DriveUpload.prefs(ctx).edit().clear().commit();

            check(db.audit().size()>1,"audit logs");
            int[] added=db.addBundle(BundleImport.read(bytes,null),"test","admin");
            check(added[0]==0&&added[1]==2,"admin import preserves existing campaign rows");
            check(db.get(r.id).a[Model.NEW].equals("1400"),"admin import preserves entered reading");
            File backup=LocalTransfer.backup(ctx,"releveur01",db.ownRows("releveur01"),null);
            try(java.util.zip.ZipFile archive=new java.util.zip.ZipFile(backup)){
                List<String[]> backupExcel=TableFile.read(archive.getInputStream(archive.getEntry("releves.xlsx")));
                check(backupExcel.get(0).length==Model.LABELS.length+1&&backupExcel.stream().anyMatch(row->row.length>Model.LABELS.length&&row[8].equals(r.a[8])&&row[Model.LABELS.length].equals(bundle.anomalies.get(0)[1])),"backup Excel includes anomaly code and label");
            }
            try(FileOutputStream example=new FileOutputStream(new File(ctx.getFilesDir(),"Export_anomalies_demo_5.1.4.xlsx"))){example.write(excel.toByteArray());}
            BackupPack.Snapshot snapshot;
            try(InputStream in=new FileInputStream(backup)){snapshot=BackupPack.read(in,"releveur01");}
            check(snapshot.rows.size()==2&&snapshot.anomalies.size()==3&&snapshot.types.size()==3,"backup catalogs and data");
            db.registerBackup("releveur01",backup.getName(),2);check(db.backups("releveur01").size()==1,"backup indexed");
            long before=db.revision();LocalTransfer.replace(ctx,db,"releveur01",bundle.meters,bytes,false,before,false);
            check(db.ownRows("other").size()==1,"replacement keeps other account");
            LocalTransfer.replace(ctx,db,"releveur01",snapshot.rows,snapshot.source,true,db.revision(),true,new BundleImport(snapshot.rows,snapshot.anomalies,snapshot.types));
            check(db.ownRows("releveur01").stream().anyMatch(a->a[Model.NEW].equals("1400")),"restore reading");
            check(db.typeRows().size()==4,"restore catalogs");
            db.close();
            Intent launch=new Intent(getTargetContext(),MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            MainActivity activity=(MainActivity)startActivitySync(launch);
            check(activity!=null,"activity launch");
            final Throwable[] uiError={null};
            runOnMainSync(()->{activity.terrainPolicy().edit().clear().commit();activity.user="releveur01";activity.admin=false;activity.home();});
            awaitUi(()->activity.stats.getText().toString().contains("0 compteurs")&&findText(activity.body,"Pas de compteurs chargés"));
            runOnMainSync(()->{try {
                check(activity.stats.getText().toString().contains("0 compteurs"),"empty startup");
                check(findText(activity.body,"Pas de compteurs chargés"),"exact empty message");
                activity.db.close();activity.db=new Store(ctx);activity.getPreferences(0).edit().putString("campaign_releveur01","test").commit();activity.home();
            }catch(Throwable failure){uiError[0]=failure;}});
            if(uiError[0]!=null)throw uiError[0];
            awaitUi(()->activity.cards!=null&&activity.cards.getChildCount()==2&&!findText(activity.cards,"Pas de compteurs chargés"));
            runOnMainSync(()->{try {
                check(activity.cards.getChildCount()==2&&!findText(activity.cards,"Pas de compteurs chargés"),"two meter cards visible");
                long dialogRevision=activity.db.revision();
                AlertDialog importDialog=activity.confirmationDialog("releveur01",bundle.meters,bytes,dialogRevision);
                check(importDialog.getButton(AlertDialog.BUTTON_POSITIVE).isShown()&&importDialog.getButton(AlertDialog.BUTTON_POSITIVE).getText().toString().equals("Remplacer"),"visible replace button alongside message");
                check(findText(importDialog.getWindow().getDecorView(),"Sauvegarder / Exporter")&&findText(importDialog.getWindow().getDecorView(),"Envoyer les relèves"),"backup and send actions visible alongside message");
                importDialog.getButton(AlertDialog.BUTTON_NEGATIVE).performClick();
                check(activity.db.revision()==dialogRevision,"cancel import leaves database unchanged");
                activity.changePasswordScreen();
                check(findText(activity.body,"Mot de passe actuel")&&findText(activity.body,"Confirmer le nouveau mot de passe")&&findText(activity.body,"Enregistrer le mot de passe"),"releveur password screen");
                activity.admin=true;activity.user="administrator";activity.administration();
                check(findText(activity.body,"Modifier mon mot de passe"),"administrator password menu");
                check(findText(activity.body,"Purger la base de données")&&findText(activity.body,"Configurer l’envoi Drive"),"administrator purge and Drive configuration actions");
                activity.changePasswordScreen();
                check(findText(activity.body,"Enregistrer le mot de passe"),"administrator password screen");
                activity.user="releveur01";activity.admin=false;
                activity.newMeter();
                check(activity.netSelector!=null&&activity.netSelector.getSelectedItem().equals("BT")&&activity.active.a[Model.NET].equals("BT"),"new outside meter defaults to BT dropdown");
                check(activity.netEdit.getParent()==null,"no free text network entry");
                check(activity.meterNetworkIcon.getContentDescription().equals("Compteur électrique"),"default BT electricity icon");
                check(activity.choices.size()==1&&activity.choices.get(0).code.equals("DEMO_03"),"all BT catalog anomalies shown regardless of consumption case");
                activity.urEdit.setText("ur03");activity.serEdit.setText("000444");
                check(activity.urEdit.getText().toString().equals("UR03")&&activity.active.a[Model.UR].equals("UR03"),"UR uppercase filter and record value");
                activity.netSelector.setSelection(1);
                activity.netSelector.getOnItemSelectedListener().onItemSelected(activity.netSelector,null,1,0);
                check(activity.active.a[Model.NET].equals("EA")&&activity.meterNetworkIcon.getContentDescription().equals("Compteur d’eau"),"EA selection updates record and icon");
                check(activity.choices.size()==2,"full EA catalog available for outside meter");
                activity.newIndex.setText("111");activity.chooseCode("DEMO_01");
                check(activity.choices.size()==2&&activity.validate().equals("Photo du compteur obligatoire."),"outside meter accepts network anomaly without reference consumption");
                activity.active.a[Model.NEW]="111";activity.active.a[8]="DEMO_01";
                activity.db.save(activity.active,"releveur01");long outsideId=activity.active.id;
                activity.form(activity.db.get(outsideId));
                check(activity.choices.size()==2&&activity.selected()!=null&&activity.selected().code.equals("DEMO_01"),"saved outside meter retains full network catalog and selected anomaly");
                check(activity.active.a[Model.UR].equals("UR03"),"uppercase UR persisted in SQLite");
                activity.db.getWritableDatabase().delete("compteurs","_id=?",new String[]{Long.toString(outsideId)});
                activity.newMeter();activity.netSelector.setSelection(1);activity.netSelector.getOnItemSelectedListener().onItemSelected(activity.netSelector,null,1,0);activity.chooseCode("DEMO_01");
                activity.netSelector.setSelection(0);
                activity.netSelector.getOnItemSelectedListener().onItemSelected(activity.netSelector,null,0,0);
                check(activity.active.a[Model.NET].equals("BT")&&activity.selected()==null,"switching network removes incompatible anomaly");
                activity.form(activity.db.list("releveur01",false,"",null,null,null,0).get(0));
                check(activity.choices.size()==1,"main form keeps consumption-compatible anomalies");
                check(activity.typeSelector!=null,"catalog spinner");
                activity.chooseCode("");check(activity.validate().startsWith("Sélectionnez une anomalie"),"anomaly mandatory even for positive reading");
                activity.terrainPolicy().edit().putBoolean("force_photo",true).putBoolean("backups",false).putBoolean("exports",false).commit();
                check(activity.requiredPhoto(new Model.Result()),"global photo obligation independent of case");
                check(!activity.optionAllowed("backups")&&!activity.optionAllowed("exports"),"reader manual options disabled");
                activity.admin=true;check(activity.optionAllowed("backups")&&activity.optionAllowed("exports"),"administrator retains manual options");activity.admin=false;
                activity.terrainPolicy().edit().clear().commit();
                check(!activity.requiredPhoto(new Model.Result()),"disabled global photo restores normal rules");

                for(String policy:new String[]{"dashboard","import_local","import_csv","load_backup","load_send","show_old_index","edit_visited"}) {
                    activity.terrainPolicy().edit().putBoolean(policy,false).commit();
                    check(!activity.optionAllowed(policy),"reader policy disabled: "+policy);
                    activity.admin=true;check(activity.optionAllowed(policy),"administrator access: "+policy);activity.admin=false;
                }
                activity.terrainPolicy().edit().clear().commit();
                Store.Record savedVisited=activity.db.list("releveur01",false,"",null,null,"_RELEVES",1).get(0);
                Store.Record priorActive=activity.active;
                activity.terrainPolicy().edit().putBoolean("edit_visited",false).putBoolean("show_old_index",false).commit();
                activity.form(savedVisited);
                check(!activity.editableRecord()&&!activity.newIndex.isEnabled(),"visited record consult only");
                check(!findContains(activity.root,"Ancien index : "+savedVisited.a[Model.OLD]),"old index value hidden");
                check(activity.identityLabel().equals("Releveur Nom Test"),"reader identity role and name");
                activity.onTrimMemory(android.content.ComponentCallbacks2.TRIM_MEMORY_RUNNING_CRITICAL);
                activity.onLowMemory();
                check(activity.db.get(savedVisited.id)!=null&&activity.db.hasUsers(),"memory pressure preserves saved records and users");
                activity.admin=true;check(activity.editableRecord(),"administrator can edit visited record");activity.admin=false;
                activity.terrainPolicy().edit().clear().commit();activity.form(priorActive);

                String originalPhone=activity.phone.getText().toString();
                activity.phone.setText("0700000001");check(!activity.phoneReady()&&!activity.ensurePhoneConfirmed(),"changed phone requires second entry");
                check(!activity.ensurePhoneConfirmed()&&!activity.phoneReady(),"repeated validation is not a second phone entry");
                activity.phoneRepeat.setText("0700000002");activity.phonePrompt.getButton(AlertDialog.BUTTON_POSITIVE).performClick();
                check(activity.phonePrompt.isShowing()&&!activity.phoneReady()&&activity.phone.getText().toString().equals("0700000002"),"mismatched phone becomes next candidate and cannot save");
                activity.phonePrompt.getButton(AlertDialog.BUTTON_NEGATIVE).performClick();activity.phone.setText(originalPhone);
                check(activity.phoneReady(),"unchanged original phone does not need confirmation");
                activity.purgeScreen();
                check(activity.purgeDialog.isShowing()&&activity.purgeDialog.getButton(AlertDialog.BUTTON_NEGATIVE)!=null,"purge confirmation shown");
                check(!activity.purgeAuthorized("wrong","PURGER")&&!activity.purgeAuthorized("Updated123!",""),"purge requires password and explicit word");
                activity.purgeDialog.getButton(AlertDialog.BUTTON_POSITIVE).performClick();
                check(activity.purgeDialog.isShowing()&&activity.db.hasUsers(),"invalid purge leaves data intact");
                activity.purgeDialog.getButton(AlertDialog.BUTTON_NEGATIVE).performClick();
                check(activity.purgeAuthorized("Updated123!","PURGER")&&activity.db.hasUsers(),"valid purge authorization can be checked without erasing emulator");

                Store.Record beforeSearch=activity.active;
                activity.renderMeterSearch("NO_MATCH_987654321",activity.searchMeterMatches("NO_MATCH_987654321"));
                check(activity.searchResultsDialog.getButton(AlertDialog.BUTTON_NEGATIVE)!=null&&activity.searchResultsDialog.getButton(AlertDialog.BUTTON_POSITIVE)!=null,"empty search offers cancel and outside meter");
                activity.searchResultsDialog.getButton(AlertDialog.BUTTON_NEGATIVE).performClick();
                check(activity.active==beforeSearch,"cancel search retains current meter");
                activity.renderMeterSearch(beforeSearch.a[4],activity.searchMeterMatches(beforeSearch.a[4]));
                check(activity.searchResultsDialog.getListView()!=null&&activity.searchResultsDialog.getListView().getCount()>0,"matching search shows selectable list");
                activity.searchResultsDialog.dismiss();

                check(activity.newIndex.getTextSize()==activity.getResources().getDisplayMetrics().scaledDensity*28&&activity.newIndex.getTypeface().isBold(),"bold size 28 index field");
                check(activity.formIdentifierText!=null&&activity.formIdentifierText.getText().toString().startsWith(activity.active.a[21])&&activity.formIdentifierText.getTypeface().isBold()&&activity.formIdentifierText.getTextSize()==activity.getResources().getDisplayMetrics().scaledDensity*28,"identifier bold 28 between address and meter");
                check(((LinearLayout)activity.body.getChildAt(0)).getChildAt(1)==activity.formIdentifierText,"identifier position");
                check(MainActivity.dayCountColor(29)==0xFF228B22&&MainActivity.dayCountColor(30)==0xFF228B22&&MainActivity.dayCountColor(31)==0xFF228B22&&MainActivity.dayCountColor(28)==0xFFEF8C00&&MainActivity.dayCountColor(32)==0xFFEF8C00&&MainActivity.dayCountColor(27)==0xFFD32F2F&&MainActivity.dayCountColor(33)==0xFFD32F2F,"day count colors at boundaries");
                TextView meter=activity.formMeterText;
                android.text.Spanned styled=(android.text.Spanned)meter.getText();
                android.text.style.AbsoluteSizeSpan[] spans=styled.getSpans(0,styled.length(),android.text.style.AbsoluteSizeSpan.class);
                check(spans.length==1&&spans[0].getSize()==32,"meter number size 32");
                check(activity.confirm.getParent()==null,"no second index field");
                check(activity.calculation.getParent()==null&&activity.photoText.getParent()==null&&activity.gpsText.getParent()==null&&activity.repeat.getParent()==null,"requested extra text and checkbox hidden");
                check(!(activity.body.getParent() instanceof ScrollView),"form has no scroll container");
                check(findContains(activity.root,"Nom Test • 1 / 2 relevés"),"filtered reading progress and reader name");
                activity.chosenUr="absent";check(activity.filteredProgress().equals("Releveur Nom Test • 0 / 0 relevés"),"progress follows UR filter");activity.chosenUr=null;
                activity.status="_RELEVES";check(activity.filteredProgress().equals("Releveur Nom Test • 1 / 1 relevés"),"progress follows status filter");activity.status=null;
                activity.newIndex.setText("1");
                check(!activity.ensureIndexConfirmed()&&activity.newIndex.getText().length()==0,"abnormal first entry cleared");
                check(activity.indexPrompt!=null&&activity.indexPrompt.isShowing(),"mandatory reentry dialog displayed");
                TextView warning=findWarning(activity.indexPrompt.getWindow().getDecorView());
                check(warning!=null&&warning.getCurrentTextColor()==0xFFD32F2F,"reentry warning red");
                activity.indexPrompt.getButton(AlertDialog.BUTTON_POSITIVE).performClick();
                activity.newIndex.setText("2");check(!activity.ensureIndexConfirmed(),"wrong repeated index refused");activity.indexPrompt.getButton(AlertDialog.BUTTON_POSITIVE).performClick();
                activity.newIndex.setText("1");check(!activity.ensureIndexConfirmed(),"nonconsecutive repeat rejected");activity.indexPrompt.getButton(AlertDialog.BUTTON_POSITIVE).performClick();
                activity.newIndex.setText("1");check(activity.ensureIndexConfirmed(),"consecutive repeated index accepted");
                activity.newIndex.setText("3");check(!activity.indexConfirmation.confirmed,"change resets confirmation");
                activity.saveAfterGps=false;activity.startGps();
                check(activity.listener!=null,"GPS listener registered");
                android.location.Location oldFix=new android.location.Location("gps");oldFix.setElapsedRealtimeNanos(activity.gpsStarted-1);oldFix.setLatitude(33.5);oldFix.setLongitude(-7.5);
                activity.listener.onLocationChanged(oldFix);check(activity.fix==null,"cached GPS fix rejected");
                android.location.Location fresh=new android.location.Location("gps");fresh.setElapsedRealtimeNanos(android.os.SystemClock.elapsedRealtimeNanos());fresh.setLatitude(33.5);fresh.setLongitude(-7.5);fresh.setAccuracy(5);
                activity.listener.onLocationChanged(fresh);check(activity.fix!=null&&activity.gpsText.getText().toString().contains("X -7.5000000 / Y 33.5000000"),"fresh GPS longitude/latitude mapping");
                activity.stopGps();
                try {
                    File jpeg=Exchange.photo(activity,"test_camera.jpg");jpeg.getParentFile().mkdirs();
                    android.graphics.Bitmap image=android.graphics.Bitmap.createBitmap(1800,900,android.graphics.Bitmap.Config.ARGB_8888);
                    try(FileOutputStream out=new FileOutputStream(jpeg)){image.compress(android.graphics.Bitmap.CompressFormat.JPEG,90,out);}image.recycle();
                    activity.m57lambda$processPhoto$40$mareleveterrainMainActivity("test_camera.jpg");
                    android.graphics.Bitmap decoded=android.graphics.BitmapFactory.decodeFile(jpeg.toString());
                    check(decoded!=null&&Math.max(decoded.getWidth(),decoded.getHeight())<=1600,"JPEG photo resized");decoded.recycle();jpeg.delete();
                    ExportProvider provider=new ExportProvider();provider.attachInfo(activity,new android.content.pm.ProviderInfo());
                    rejects(()->provider.openFile(android.net.Uri.parse("content://ma.releve.terrain.v320.exports/demo.zip"),"w"),"exports are read-only");
                } catch(Exception error){throw new RuntimeException(error);}
                activity.form(activity.db.list("releveur01",false,"",null,null,null,0).get(0));
                activity.newIndex.setText("1255");activity.newIndex.requestFocus();
                ((android.view.inputmethod.InputMethodManager)activity.getSystemService(Context.INPUT_METHOD_SERVICE)).showSoftInput(activity.newIndex,android.view.inputmethod.InputMethodManager.SHOW_IMPLICIT);
            } catch(Throwable failure) {uiError[0]=failure;} });
            if(uiError[0]!=null)throw uiError[0];
            waitForIdleSync();
            final boolean[] keyboardOpen={false};
            long keyboardDeadline=android.os.SystemClock.elapsedRealtime()+30000;
            while(!keyboardOpen[0]&&android.os.SystemClock.elapsedRealtime()<keyboardDeadline){
                runOnMainSync(()->{
                    activity.newIndex.requestFocus();
                    ((android.view.inputmethod.InputMethodManager)activity.getSystemService(Context.INPUT_METHOD_SERVICE)).showSoftInput(activity.newIndex,android.view.inputmethod.InputMethodManager.SHOW_IMPLICIT);
                    android.graphics.Rect visible=new android.graphics.Rect();activity.root.getWindowVisibleDisplayFrame(visible);
                    android.graphics.Point full=new android.graphics.Point();activity.getWindowManager().getDefaultDisplay().getRealSize(full);
                    keyboardOpen[0]=visible.bottom<full.y-100;
                });
                if(!keyboardOpen[0])android.os.SystemClock.sleep(300);
            }
            check(keyboardOpen[0],"keyboard really open");
            runOnMainSync(()->{try{
                check(activity.newIndex.hasFocus()&&(activity.newIndex.getInputType()&android.text.InputType.TYPE_MASK_CLASS)==android.text.InputType.TYPE_CLASS_NUMBER,"focused index requests numeric keyboard");
            }catch(Throwable failure){uiError[0]=failure;}});
            if(uiError[0]!=null)throw uiError[0];
            android.os.SystemClock.sleep(3000);
            runOnMainSync(()->{try{
                android.graphics.Rect visible=new android.graphics.Rect();activity.root.getWindowVisibleDisplayFrame(visible);
                for(android.view.View input:new android.view.View[]{activity.newIndex,activity.anomaly,activity.comment,activity.phone,activity.typeSelector,activity.body.getChildAt(activity.body.getChildCount()-1)}){
                    android.graphics.Rect bounds=new android.graphics.Rect();
                    check(input.getGlobalVisibleRect(bounds)&&bounds.height()==input.getHeight()&&bounds.bottom<=visible.bottom,"all inputs and validate fully visible with keyboard");
                }
                activity.getWindow().clearFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE);
            }catch(Throwable failure){uiError[0]=failure;}});
            if(uiError[0]!=null)throw uiError[0];
            waitForIdleSync();
            android.graphics.Bitmap screenshot=getUiAutomation().takeScreenshot();
            check(screenshot!=null,"real form screenshot");
            try(FileOutputStream output=new FileOutputStream(new File(ctx.getFilesDir(),"form-keyboard.png"))){screenshot.compress(android.graphics.Bitmap.CompressFormat.PNG,100,output);}screenshot.recycle();
            runOnMainSync(()->activity.confirmationDialog("releveur01",bundle.meters,bytes,activity.db.revision()).getButton(AlertDialog.BUTTON_POSITIVE).performClick());
            long deadline=android.os.SystemClock.elapsedRealtime()+30000;
            final boolean[] pending={true};
            while(pending[0]&&android.os.SystemClock.elapsedRealtime()<deadline){
                runOnMainSync(()->pending[0]=activity.busy);
                if(pending[0])android.os.SystemClock.sleep(100);
            }
            check(!pending[0],"replace button completes import");
            check(activity.db.ownRows("releveur01").size()==2&&activity.db.ownRows("releveur01").stream().allMatch(a->a[Model.NEW].isEmpty()),"replace button applies imported rows");
            runOnMainSync(()->activity.finish());
            maintenanceChecks(ctx,activity.db);
            result.putString("stream","PASS "+checks+" Android checks\n");result.putInt("checks",checks);finish(Activity.RESULT_OK,result);
        }catch(Throwable error){StringWriter out=new StringWriter();error.printStackTrace(new PrintWriter(out));result.putString("stream",out.toString());finish(Activity.RESULT_CANCELED,result);}
    }
    void maintenanceChecks(Context base,Store original)throws Exception{
        Context ctx=new ContextWrapper(base){
            public android.database.sqlite.SQLiteDatabase openOrCreateDatabase(String name,int mode,android.database.sqlite.SQLiteDatabase.CursorFactory factory){return getTargetContext().openOrCreateDatabase("instrumentation_maintenance.db",mode,factory);}
            public android.database.sqlite.SQLiteDatabase openOrCreateDatabase(String name,int mode,android.database.sqlite.SQLiteDatabase.CursorFactory factory,android.database.DatabaseErrorHandler handler){return getTargetContext().openOrCreateDatabase("instrumentation_maintenance.db",mode,factory,handler);}
            public File getDatabasePath(String name){return getTargetContext().getDatabasePath("instrumentation_maintenance.db");}
            public File getFilesDir(){File file=new File(base.getFilesDir(),"maintenance");file.mkdirs();return file;}
        };
        getTargetContext().deleteDatabase("instrumentation_maintenance.db");Store store=new Store(ctx);
        try(android.database.Cursor cursor=original.getReadableDatabase().query("users",null,null,null,null,null,null)){
            while(cursor.moveToNext()){android.content.ContentValues values=new android.content.ContentValues();android.database.DatabaseUtils.cursorRowToContentValues(cursor,values);store.getWritableDatabase().insertOrThrow("users",null,values);}
        }
        List<String[]> own=original.ownRows("releveur01"),other=original.ownRows("other");
        own.get(0)[27]="shared.jpg";own.get(1)[27]="own.jpg";other.get(0)[27]="shared.jpg";
        own.get(0)[Model.DATE]="15/10/2026 10:00:00";own.get(1)[Model.DATE]="";
        store.add(own,"maintenance","administrator");store.add(other,"maintenance","administrator");
        File photos=new File(ctx.getFilesDir(),"photos");photos.mkdirs();
        for(String name:new String[]{"shared.jpg","own.jpg"})try(FileOutputStream out=new FileOutputStream(new File(photos,name))){out.write(new byte[]{1,2,3});}
        List<String[]> visited=store.exportVisited("releveur01");
        List<List<File>> groups=PhotoBatch.plan(ctx,visited);
        check(groups.size()==1&&groups.get(0).size()==1&&groups.get(0).get(0).getName().equals("shared.jpg"),"photo plan excludes unvisited photos");
        byte[] zip=PhotoBatch.archive(groups.get(0));check(Arrays.equals(zip,PhotoBatch.archive(groups.get(0))),"photo ZIP deterministic for retry");
        try(java.util.zip.ZipInputStream in=new java.util.zip.ZipInputStream(new ByteArrayInputStream(zip))){check(in.getNextEntry().getName().equals("photos/shared.jpg")&&TableFile.limited(in,100).length==3&&in.getNextEntry()==null,"photo ZIP has visited photo only");}
        int catalogCount=store.anomalies(null,null).size(),userCount=store.users().size();
        rejects(()->DataMaintenance.purge(ctx,store,"releveur01",true,"releveur01",false),"reader cannot purge all owners");
        rejects(()->DataMaintenance.purge(ctx,store,"administrator",false,"administrator",true),"cannot delete administrator");
        DataMaintenance.purge(ctx,store,"releveur01",false,"releveur01",false);
        check(store.ownRows("releveur01").isEmpty()&&store.ownRows("other").size()==1,"reader purge isolated");
        check(store.users().size()==userCount&&"RELEVEUR".equals(store.loginRole("releveur01")),"purge preserves reader accounts");
        check(store.anomalies(null,null).size()==catalogCount,"purge preserves catalogs");
        check(new File(photos,"shared.jpg").exists()&&!new File(photos,"own.jpg").exists(),"purge keeps photo still referenced by another owner");
        DataMaintenance.purge(ctx,store,"administrator",false,"other",true);
        check(store.loginRole("other")==null&&store.ownRows("other").isEmpty()&&store.loginRole("releveur01")!=null,"admin deletion removes selected reader only");
        store.add(own,"maintenance","administrator");DataMaintenance.purge(ctx,store,"administrator",true,"administrator",false);
        check(store.list("",true,"",null,null,null,0).isEmpty()&&store.users().size()==userCount-1,"admin purge clears data while retaining accounts");
        check(store.anomalies(null,null).size()==catalogCount,"admin purge preserves catalogs");store.close();
    }
    TextView findWarning(android.view.View view){if(view instanceof TextView&&((TextView)view).getText().toString().startsWith("Ressaisie obligatoire"))return (TextView)view;if(view instanceof android.view.ViewGroup){android.view.ViewGroup group=(android.view.ViewGroup)view;for(int i=0;i<group.getChildCount();i++){TextView found=findWarning(group.getChildAt(i));if(found!=null)return found;}}return null;}
    boolean findContains(android.view.View view,String text){if(view instanceof TextView&&((TextView)view).getText().toString().contains(text))return true;if(view instanceof android.view.ViewGroup){android.view.ViewGroup group=(android.view.ViewGroup)view;for(int i=0;i<group.getChildCount();i++)if(findContains(group.getChildAt(i),text))return true;}return false;}
    boolean findText(android.view.View view,String text){if(view instanceof TextView&&((TextView)view).getText().toString().equals(text))return true;if(view instanceof android.view.ViewGroup){android.view.ViewGroup group=(android.view.ViewGroup)view;for(int i=0;i<group.getChildCount();i++)if(findText(group.getChildAt(i),text))return true;}return false;}
}
