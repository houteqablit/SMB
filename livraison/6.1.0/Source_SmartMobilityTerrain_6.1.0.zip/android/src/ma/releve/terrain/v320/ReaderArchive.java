package ma.releve.terrain.v320;
import android.content.*;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.AtomicFile;
import java.io.*;
import java.util.*;
final class ReaderArchive {
 static final String[] HEADERS={"Reseau","Tournee","Contrat","UR","Identifiant releveur","Nom releveur","Nouvel index","Libelle anomalie","Date et heure de releve","GPS X (longitude)","GPS Y (latitude)","Nouveau telephone","Nouveau type local (code)","Libelle du nouveau type local","Nouvelle unite de releve","Nouveau numero compteur"};
 static void schema(SQLiteDatabase db){
  StringBuilder sql=new StringBuilder("CREATE TABLE IF NOT EXISTS reader_archive(owner TEXT NOT NULL,uid TEXT NOT NULL,revision TEXT NOT NULL,owner_name TEXT NOT NULL");
  for(int n=0;n<HEADERS.length;n++)sql.append(",f").append(n).append(" TEXT NOT NULL");
  db.execSQL(sql.append(",PRIMARY KEY(owner,uid,revision))").toString());
  boolean has=false;try(Cursor c=db.rawQuery("PRAGMA table_info(reader_archive)",null)){while(c.moveToNext())if("f15".equals(c.getString(1)))has=true;}
  if(!has)db.execSQL("ALTER TABLE reader_archive ADD COLUMN f15 TEXT NOT NULL DEFAULT ''");
 }
 static String select(){return "SELECT c.releveur,CASE WHEN c.uuid='' THEN 'legacy_'||c._id ELSE c.uuid END,c.version,COALESCE(u.display_name,c.releveur),c.reseau,c.tournee,c.contrat,c.ur,CASE WHEN c.releveur_effectif='' THEN c.releveur ELSE c.releveur_effectif END,CASE WHEN c.nom_releveur_effectif='' THEN COALESCE(u.display_name,c.releveur) ELSE c.nom_releveur_effectif END,c.nouveau,COALESCE(a.libelle,''),c.date,c.x,c.y,c.nouveau_telephone,c.nouveau_type_local,CASE WHEN c.libelle_nouveau_type_local='' THEN COALESCE(t.libelle,'') ELSE c.libelle_nouveau_type_local END,c.nouvelle_unite_releve,c.nouveau_numero_compteur FROM compteurs c LEFT JOIN users u ON u.login=c.releveur LEFT JOIN anomalies a ON a.code=c.anomalie LEFT JOIN type_local t ON t.code=c.nouveau_type_local WHERE TRIM(c.date)<>''";}
 static void backfill(SQLiteDatabase db){db.execSQL("INSERT OR IGNORE INTO reader_archive "+select());}
 static void capture(SQLiteDatabase db,long id){db.execSQL("INSERT OR IGNORE INTO reader_archive "+select()+" AND c._id=?",new Object[]{id});}
 static void requireAdmin(Store store,String actor){if(!"ADMIN".equals(store.loginRole(actor)))throw new SecurityException("Administrateur requis pour les archives.");}
 static boolean hasOwner(Store store,String owner){try(Cursor c=store.getReadableDatabase().rawQuery("SELECT 1 FROM reader_archive WHERE owner=? LIMIT 1",new String[]{owner})){return c.moveToFirst();}}
 static List<String> owners(Store store,String actor){requireAdmin(store,actor);List<String> out=new ArrayList<>();try(Cursor c=store.getReadableDatabase().rawQuery("SELECT DISTINCT owner FROM reader_archive ORDER BY owner",null)){while(c.moveToNext())out.add(c.getString(0));}return out;}
 static String ownerName(Store store,String owner){String current=store.loginRole(owner)==null?"":store.displayName(owner);if(!current.isEmpty())return current;try(Cursor c=store.getReadableDatabase().rawQuery("SELECT owner_name FROM reader_archive WHERE owner=? ORDER BY rowid DESC LIMIT 1",new String[]{owner})){return c.moveToFirst()?c.getString(0):owner;}}
 static String[] columns(){String[] cols=new String[HEADERS.length];for(int n=0;n<cols.length;n++)cols[n]="f"+n;return cols;}
 static List<String[]> rows(Store store,String actor,String owner){requireAdmin(store,actor);return internalRows(store,owner);}
 private static List<String[]> internalRows(Store store,String owner){List<String[]> out=new ArrayList<>();out.add(HEADERS.clone());try(Cursor c=store.getReadableDatabase().query("reader_archive",columns(),"owner=?",new String[]{owner},null,null,"rowid")){while(c.moveToNext()){String[] row=new String[HEADERS.length];for(int n=0;n<row.length;n++)row[n]=c.getString(n);out.add(row);}}return out;}
 static File file(Context context,String owner,String ext)throws Exception{
  File folder=new File(context.getFilesDir(),"reader_archives");if(!folder.exists()&&!folder.mkdirs())throw new IOException("Stockage de l’archive indisponible.");
  return new File(folder,UploadProtocol.sha(owner.getBytes(java.nio.charset.StandardCharsets.UTF_8))+"."+ext);
 }
 static synchronized void appendMirrorSafely(Context context,Store store,Store.Record record){
  if(record.a[Model.DATE].trim().isEmpty())return;
  try{
   String[] row=null;try(Cursor c=store.getReadableDatabase().query("reader_archive",columns(),"owner=? AND uid=? AND revision=?",new String[]{record.a[Model.READER],record.a[Model.UUID_],record.a[Model.VER]},null,null,null,"1")){
    if(c.moveToFirst()){row=new String[HEADERS.length];for(int n=0;n<row.length;n++)row[n]=c.getString(n);}
   }
   if(row==null)return;
   File target=file(context,record.a[Model.READER],"txt");boolean fresh=!target.exists()||target.length()==0;
   ByteArrayOutputStream bytes=new ByteArrayOutputStream();List<String[]> rows=new ArrayList<>();if(fresh)rows.add(HEADERS);rows.add(row);TableFile.writeCsv(bytes,rows);byte[] data=bytes.toByteArray();
   try(FileOutputStream out=new FileOutputStream(target,true)){out.write(data,fresh?0:3,data.length-(fresh?0:3));}
  }catch(Exception error){android.util.Log.w("SMBArchive","Miroir TXT indisponible ; archive transactionnelle conservée.");}
 }
 static synchronized void mirror(Context context,Store store,String owner)throws Exception{
  if(!hasOwner(store,owner))return;
  AtomicFile target=new AtomicFile(file(context,owner,"txt"));FileOutputStream out=target.startWrite();try{TableFile.writeCsv(out,internalRows(store,owner));target.finishWrite(out);}catch(Exception error){target.failWrite(out);throw error;}
 }
 static void ensureMirrors(Context context,Store store)throws Exception{List<String> owners=new ArrayList<>();try(Cursor c=store.getReadableDatabase().rawQuery("SELECT DISTINCT owner FROM reader_archive",null)){while(c.moveToNext())owners.add(c.getString(0));}for(String owner:owners)mirror(context,store,owner);}
 static String send(Context context,Store store,String actor,String owner)throws Exception{
  requireAdmin(store,actor);List<String[]> rows=internalRows(store,owner);if(rows.size()<2)throw new IOException("Archive vide.");
  mirror(context,store,owner);ByteArrayOutputStream bytes=new ByteArrayOutputStream();TableFile.writeXlsx(bytes,rows);
  AtomicFile target=new AtomicFile(file(context,owner,"xlsx"));FileOutputStream out=target.startWrite();try{out.write(bytes.toByteArray());target.finishWrite(out);}catch(Exception error){target.failWrite(out);throw error;}
  DriveUpload.requireService(context);String name="Archive_"+ExportName.base(ownerName(store,owner),false,System.currentTimeMillis())+".xlsx";
  DriveUpload.sendFile(context,owner,bytes.toByteArray(),"xlsx",name);
  return (rows.size()-1)+" validation(s) archivées envoyées dans Drive pour "+owner+". Archive locale conservée.";
 }
 static synchronized void delete(Context context,Store store,String actor,String owner)throws Exception{
  requireAdmin(store,actor);
  // Remove private mirrors first; if this fails retain the authoritative journal for retry.
  for(String ext:new String[]{"txt","txt.bak","txt.new","xlsx","xlsx.bak","xlsx.new"}){File path=file(context,owner,ext);if(path.exists()&&!path.delete())throw new IOException("Suppression de l’archive locale impossible.");}
  store.getWritableDatabase().delete("reader_archive","owner=?",new String[]{owner});store.log(actor,"SUPPRIMER_ARCHIVE",owner);
 }
}
