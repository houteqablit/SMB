package ma.releve.terrain.v320;
import android.content.Context;
import android.graphics.*;
import android.view.*;
import java.io.*;
import java.net.*;
import java.util.*;
import java.util.concurrent.*;
/** Two-point map only. No history, geolocation bridge, route service or third-party JS. */
final class CounterMapView extends View {
 final double meterLon,meterLat;final boolean hasMeter;boolean hasReader,closed;
 double readerLon,readerLat,centerLon,centerLat;int level=17;
 float downX,downY,lastX,lastY;boolean moved;
 final Paint paint=new Paint(3);final Runnable openMeter;
 final ExecutorService downloads=Executors.newFixedThreadPool(2);
 final Map<String,Bitmap> tiles=new LinkedHashMap<>();final Set<String> pending=new HashSet<>();final Set<String> failed=new HashSet<>();
 final File cache;boolean tileFailed;
 static boolean valid(double lon,double lat){return !Double.isNaN(lon)&&!Double.isNaN(lat)&&!Double.isInfinite(lon)&&!Double.isInfinite(lat)&&lon>=-180&&lon<=180&&lat>=-90&&lat<=90&&!(lon==0&&lat==0);}
 CounterMapView(Context ctx,String x,String y,Runnable open){super(ctx);double lon=Double.NaN,lat=Double.NaN;try{lon=Double.parseDouble(x.replace(',','.'));lat=Double.parseDouble(y.replace(',','.'));}catch(Exception ignored){}meterLon=lon;meterLat=lat;hasMeter=valid(lon,lat);centerLon=hasMeter?lon:0;centerLat=hasMeter?lat:0;openMeter=open;cache=new File(ctx.getCacheDir(),"map610");cache.mkdirs();setContentDescription("Carte du compteur ; toucher le point vert pour ouvrir la saisie");setLayerType(View.LAYER_TYPE_SOFTWARE,null);}
 void setReader(double lon,double lat){if(!valid(lon,lat)||closed)return;readerLon=lon;readerLat=lat;hasReader=true;recenter();}
 void zoom(int delta){level=Math.max(2,Math.min(19,level+delta));invalidate();}
 double world(){return 256.0*(1<<level);}
 double px(double lon){return (lon+180)/360*world();}
 double py(double lat){double clamped=Math.max(-85.05112878,Math.min(85.05112878,lat));double sin=Math.sin(Math.toRadians(clamped));return (.5-Math.log((1+sin)/(1-sin))/(4*Math.PI))*world();}
 void recenter(){
  if(hasMeter&&hasReader){centerLon=(meterLon+readerLon)/2;centerLat=(meterLat+readerLat)/2;level=17;while(level>2&&(Math.abs(px(meterLon)-px(readerLon))>Math.max(100,getWidth()-80)||Math.abs(py(meterLat)-py(readerLat))>Math.max(100,getHeight()-80)))level--;}
  else if(hasMeter){centerLon=meterLon;centerLat=meterLat;}else if(hasReader){centerLon=readerLon;centerLat=readerLat;}invalidate();
 }
 float sx(double lon){return (float)(px(lon)-px(centerLon)+getWidth()/2.0);}
 float sy(double lat){return (float)(py(lat)-py(centerLat)+getHeight()/2.0);}
 @Override protected void onDraw(Canvas canvas){super.onDraw(canvas);canvas.drawColor(0xFFEAF0ED);if(closed)return;
  if(!hasMeter&&!hasReader){label(canvas,"Aucune position disponible",18,30,0xFF334455);return;}
  double left=px(centerLon)-getWidth()/2.0,top=py(centerLat)-getHeight()/2.0;int size=1<<level;
  for(int tx=(int)Math.floor(left/256);tx<=Math.floor((left+getWidth())/256);tx++)for(int ty=(int)Math.floor(top/256);ty<=Math.floor((top+getHeight())/256);ty++){
   if(ty<0||ty>=size)continue;int xx=((tx%size)+size)%size;String key=level+"/"+xx+"/"+ty;float x=(float)(tx*256-left),y=(float)(ty*256-top);Bitmap tile=tiles.get(key);
   if(tile!=null)canvas.drawBitmap(tile,null,new RectF(x,y,x+256,y+256),paint);else{paint.setColor(0xFFD3DFD8);paint.setStyle(Paint.Style.STROKE);canvas.drawRect(x,y,x+256,y+256,paint);paint.setStyle(Paint.Style.FILL);load(key);}
  }
  if(hasMeter&&hasReader){paint.setColor(0xFF555555);paint.setStrokeWidth(3);paint.setPathEffect(new DashPathEffect(new float[]{10,8},0));canvas.drawLine(sx(meterLon),sy(meterLat),sx(readerLon),sy(readerLat),paint);paint.setPathEffect(null);}
  if(hasReader)point(canvas,sx(readerLon),sy(readerLat),0xFF1976D2,"Vous");
  if(hasMeter)point(canvas,sx(meterLon),sy(meterLat),0xFF15953C,"Compteur");
  if(tileFailed)label(canvas,"Fond indisponible : vérifiez Internet",12,getHeight()-12,0xFF333333);
 }
 void label(Canvas c,String text,float x,float y,int color){paint.setColor(Color.WHITE);paint.setTextSize(14*getResources().getDisplayMetrics().scaledDensity);paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(4);c.drawText(text,x,y,paint);paint.setStyle(Paint.Style.FILL);paint.setColor(color);c.drawText(text,x,y,paint);}
 void point(Canvas c,float x,float y,int color,String label){paint.setColor(Color.WHITE);c.drawCircle(x,y,14,paint);paint.setColor(color);c.drawCircle(x,y,10,paint);label(c,label,x+16,y-12,color);}
 void load(String key){if(closed||failed.contains(key)||pending.contains(key)||pending.size()>=12)return;pending.add(key);downloads.execute(()->{Bitmap bitmap=null;try{
   File file=new File(cache,key.replace('/','_')+".png");
   if(file.isFile()&&System.currentTimeMillis()-file.lastModified()<7L*24*3600*1000)bitmap=BitmapFactory.decodeFile(file.getPath());
   if(bitmap==null){HttpURLConnection conn=(HttpURLConnection)new URL("https://tile.openstreetmap.org/"+key+".png").openConnection();conn.setConnectTimeout(8000);conn.setReadTimeout(8000);conn.setInstanceFollowRedirects(false);conn.setRequestProperty("User-Agent","SMB-Releve/6.1.0 (Android; https://github.com/houteqablit/SMB)");
    try{if(conn.getResponseCode()!=200)throw new IOException("Map HTTP");byte[] bytes;try(InputStream in=conn.getInputStream()){bytes=TableFile.limited(in,1048576);}bitmap=BitmapFactory.decodeByteArray(bytes,0,bytes.length);if(bitmap==null)throw new IOException("Map image");try(FileOutputStream out=new FileOutputStream(file)){out.write(bytes);}}finally{conn.disconnect();}
   }
   File[] disk=cache.listFiles();if(disk!=null&&disk.length>160){Arrays.sort(disk,Comparator.comparingLong(File::lastModified));for(int n=0;n<disk.length-128;n++)disk[n].delete();}
  }catch(Exception ignored){}
  final Bitmap result=bitmap;post(()->{pending.remove(key);if(closed){if(result!=null)result.recycle();return;}if(result==null){failed.add(key);tileFailed=true;invalidate();return;}tiles.put(key,result);while(tiles.size()>48){String first=tiles.keySet().iterator().next();Bitmap old=tiles.remove(first);old.recycle();}invalidate();});
 });}
 @Override public boolean onTouchEvent(MotionEvent e){if(e.getAction()==MotionEvent.ACTION_DOWN){downX=lastX=e.getX();downY=lastY=e.getY();moved=false;getParent().requestDisallowInterceptTouchEvent(true);return true;}if(e.getAction()==MotionEvent.ACTION_MOVE){float dx=e.getX()-lastX,dy=e.getY()-lastY;if(Math.abs(e.getX()-downX)+Math.abs(e.getY()-downY)>12)moved=true;double wx=px(centerLon)-dx,wy=py(centerLat)-dy;centerLon=((wx/world()*360+180)%360+360)%360-180;centerLat=Math.toDegrees(Math.atan(Math.sinh(Math.PI*(1-2*wy/world()))));lastX=e.getX();lastY=e.getY();invalidate();return true;}if(e.getAction()==MotionEvent.ACTION_UP){getParent().requestDisallowInterceptTouchEvent(false);if(!moved&&hasMeter&&Math.hypot(e.getX()-sx(meterLon),e.getY()-sy(meterLat))<48)performClick();return true;}return true;}
 @Override public boolean performClick(){super.performClick();if(!closed)openMeter.run();return true;}
 void close(){closed=true;downloads.shutdownNow();for(Bitmap b:tiles.values())b.recycle();tiles.clear();}
 @Override protected void onDetachedFromWindow(){close();super.onDetachedFromWindow();}
}
