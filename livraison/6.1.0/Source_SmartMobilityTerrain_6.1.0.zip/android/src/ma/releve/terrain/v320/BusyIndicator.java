package ma.releve.terrain.v320;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.os.SystemClock;
import android.view.View;
/** Indeterminate 12-segment green indicator; animation stops with its window. */
final class BusyIndicator extends View {
 private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);
 private final long started=SystemClock.uptimeMillis();
 BusyIndicator(Context context){super(context);setContentDescription("Opération en cours");paint.setStrokeCap(Paint.Cap.ROUND);}
 @Override protected void onDraw(Canvas canvas){
  super.onDraw(canvas);float radius=Math.min(getWidth(),getHeight())*.45f,cx=getWidth()/2f,cy=getHeight()/2f;
  paint.setStrokeWidth(Math.max(2,radius*.17f));int step=(int)((SystemClock.uptimeMillis()-started)/80%12);
  for(int n=0;n<12;n++){
   int age=(step-n+12)%12;paint.setColor(0xFF15953C);paint.setAlpha(255-age*17);
   double angle=Math.toRadians(n*30-90);float x=(float)Math.cos(angle),y=(float)Math.sin(angle);
   canvas.drawLine(cx+x*radius*.62f,cy+y*radius*.62f,cx+x*radius*.94f,cy+y*radius*.94f,paint);
  }
  if(isAttachedToWindow()&&isShown())postInvalidateOnAnimation();
 }
}
