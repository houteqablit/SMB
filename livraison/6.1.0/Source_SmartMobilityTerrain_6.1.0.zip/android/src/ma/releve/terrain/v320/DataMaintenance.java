package ma.releve.terrain.v320;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import java.io.*;
import java.util.*;
final class DataMaintenance {
 static List<File> purge(Context context,Store store,String actor,boolean all,String owner,boolean deleteReader)throws Exception{
  SQLiteDatabase db=store.getWritableDatabase();List<File> candidates=new ArrayList<>();
  db.beginTransaction();
  try{
   boolean isAdmin="ADMIN".equals(store.loginRole(actor));
   if((all||deleteReader||!actor.equals(owner))&&!isAdmin)throw new SecurityException("Administrateur requis.");
   if(deleteReader&&(!"RELEVEUR".equals(store.loginRole(owner))||actor.equals(owner)))throw new SecurityException("Seul un compte releveur distinct peut être supprimé.");
   List<Store.Record> purgedRecords=new ArrayList<>();
   try(Cursor c=db.query("compteurs",null,all?null:"releveur=?",all?null:new String[]{owner},null,null,null)){while(c.moveToNext())purgedRecords.add(new Store.Record(c));}
   for(Store.Record record:purgedRecords){
    if(!record.a[27].isEmpty())candidates.add(Exchange.photo(context,record.a[27]));
    db.delete("audit","record=?",new String[]{Long.toString(record.id)});
   }
   db.delete("audit",all?null:"user=?",all?null:new String[]{owner});
   for(String table:new String[]{"chargements","sauvegardes"}){
    String column=table.equals("chargements")?"source":"filename",folder=table.equals("chargements")?"sources":"exports";
    try(Cursor cursor=db.rawQuery("SELECT "+column+" FROM "+table+(all?"":" WHERE owner=?"),all?null:new String[]{owner})){
     while(cursor.moveToNext()){
      File parent=new File(context.getFilesDir(),folder),file=new File(parent,cursor.getString(0));
      if(file.getCanonicalFile().getParentFile().equals(parent.getCanonicalFile()))candidates.add(file);
     }
    }
    db.delete(table,all?null:"owner=?",all?null:new String[]{owner});
   }
   db.delete("compteurs",all?null:"releveur=?",all?null:new String[]{owner});
   // Ne pas effacer une photo ou une source encore référencée par une autre tournée.
   Set<String> retained=new HashSet<>();
   for(Store.Record record:store.list("",true,"",null,null,null,0))if(!record.a[27].isEmpty())retained.add(Exchange.photo(context,record.a[27]).getCanonicalPath());
   try(Cursor cursor=db.rawQuery("SELECT source FROM chargements",null)){while(cursor.moveToNext())retained.add(new File(new File(context.getFilesDir(),"sources"),cursor.getString(0)).getCanonicalPath());}
   candidates.removeIf(file->{try{return retained.contains(file.getCanonicalPath());}catch(IOException e){return true;}});
   if(deleteReader)db.delete("users","login=? AND role='RELEVEUR'",new String[]{owner});
   db.execSQL("UPDATE metadata SET revision=revision+1");
   store.log(db,actor,deleteReader?"SUPPRIMER_RELEVEUR":"PURGER_TOURNEES",all?"TOUTES":owner,"","");
   db.setTransactionSuccessful();
  }finally{db.endTransaction();}
  List<File> failures=new ArrayList<>();
  if(all)for(String folder:new String[]{"photos","sources","exports"}){
   File[] files=new File(context.getFilesDir(),folder).listFiles();if(files!=null)Collections.addAll(candidates,files);
  }
  for(File file:new LinkedHashSet<>(candidates))if(file.isFile()&&!file.delete())failures.add(file);
  return failures;
 }
}
