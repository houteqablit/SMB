#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
./test.sh | tee build-host-results.tmp
./build.sh
mkdir -p ../deliverables/6.1.0
mv build-host-results.tmp ../deliverables/6.1.0/host-test-results.txt
cp build/SmartMobilityTerrain-6.1.0.apk ../deliverables/6.1.0/
cp assets/Modele_SmartMobilityTerrain_6.1.0.xlsx ../deliverables/6.1.0/
cp tests/fixtures/{Releve.csv,Anomalie.csv,type_local.csv} ../deliverables/6.1.0/
python3 - <<'PY'
from pathlib import Path
import hashlib, zipfile
root=Path.cwd();output=root.parent/'deliverables'/'6.1.0'
with zipfile.ZipFile(output/'Source_SmartMobilityTerrain_6.1.0.zip','w',zipfile.ZIP_DEFLATED) as archive:
    for p in sorted(root.rglob('*')):
        if p.is_file() and 'build' not in p.relative_to(root).parts:
            archive.write(p,'android/'+str(p.relative_to(root)))
artifacts=['SmartMobilityTerrain-6.1.0.apk','Modele_SmartMobilityTerrain_6.1.0.xlsx','Source_SmartMobilityTerrain_6.1.0.zip']
(output/'SHA256SUMS').write_text(''.join(hashlib.sha256((output/n).read_bytes()).hexdigest()+'  '+n+'\n' for n in artifacts))
PY
