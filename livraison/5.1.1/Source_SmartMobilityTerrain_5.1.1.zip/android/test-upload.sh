#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
JDK=${SMB_JDK_HOME:-/workspace/tools/jdk17}
mkdir -p build/upload-tests
"$JDK/bin/javac" --release 17 -encoding UTF-8 -d build/upload-tests src/ma/releve/terrain/v320/UploadProtocol.java src/ma/releve/terrain/v320/PhoneConfirmation.java tests/ma/releve/terrain/v320/UploadProtocolTests.java
"$JDK/bin/java" -cp build/upload-tests ma.releve.terrain.v320.UploadProtocolTests
node drive-service/test-service.cjs
