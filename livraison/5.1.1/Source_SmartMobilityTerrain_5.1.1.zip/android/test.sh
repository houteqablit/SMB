#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
export PATH="${SMB_JDK_HOME:-/workspace/tools/jdk17}/bin:$PATH"
mkdir -p build/host-tests
base=src/ma/releve/terrain/v320
javac --release 17 -encoding UTF-8 -d build/host-tests "$base/Model.java" "$base/Model\$\$ExternalSyntheticBackportWithForwarding0.java" "$base/TableFile.java" "$base/DirectDrive.java" "$base/BackupPack.java" "$base/BundleImport.java" "$base/IndexConfirmation.java" tests/ma/releve/terrain/v320/CoreTests.java
java -cp build/host-tests ma.releve.terrain.v320.CoreTests "${1:-tests/fixtures}"
