package ma.releve.terrain.v320;
final class PhoneConfirmation {
 String previous="",confirmed="";
 static String normalize(String value){return value.trim().replaceAll("[\\s().-]","");}
 static boolean valid(String value){return normalize(value).matches("\\+?[0-9]{6,15}");}
 boolean accept(String value){String next=normalize(value);if(!valid(next))return false;if(next.equals(previous)){confirmed=next;return true;}previous=next;confirmed="";return false;}
 boolean matches(String value){return !confirmed.isEmpty()&&confirmed.equals(normalize(value));}
 void edited(String value){if(!matches(value)){confirmed="";previous="";}}
 void reset(){previous="";confirmed="";}
}
