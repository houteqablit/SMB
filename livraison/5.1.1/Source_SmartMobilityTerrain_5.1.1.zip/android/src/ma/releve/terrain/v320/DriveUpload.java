package ma.releve.terrain.v320;
import android.content.Context;
import android.content.SharedPreferences;
import android.security.keystore.*;
import android.util.Base64;
import java.io.*;
import java.net.*;
import java.security.KeyStore;
import java.nio.charset.StandardCharsets;
import javax.crypto.*;
import javax.crypto.spec.GCMParameterSpec;
import org.json.JSONObject;
final class DriveUpload {
 static final String ALIAS="smb_drive_510";
 static SecretKey key()throws Exception{
  KeyStore store=KeyStore.getInstance("AndroidKeyStore");store.load(null);
  if(store.containsAlias(ALIAS))return (SecretKey)store.getKey(ALIAS,null);
  KeyGenerator gen=KeyGenerator.getInstance("AES","AndroidKeyStore");
  gen.init(new KeyGenParameterSpec.Builder(ALIAS,KeyProperties.PURPOSE_ENCRYPT|KeyProperties.PURPOSE_DECRYPT).setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build());return gen.generateKey();
 }
 static SharedPreferences prefs(Context ctx){return ctx.getSharedPreferences("drive_upload",0);}
 static void configure(Context ctx,String url,String owner,String secret)throws Exception{
  url=UploadProtocol.endpoint(url);UploadProtocol.canonical(owner,"","",0);
  if(secret.isEmpty())secret=secret(ctx,owner);
  if(secret.length()<32||secret.length()>256)throw new IllegalArgumentException("Clé de transfert : 32 à 256 caractères.");
  Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding");cipher.init(Cipher.ENCRYPT_MODE,key());
  String value=Base64.encodeToString(cipher.getIV(),Base64.NO_WRAP)+":"+Base64.encodeToString(cipher.doFinal(secret.getBytes(StandardCharsets.UTF_8)),Base64.NO_WRAP);
  if(!prefs(ctx).edit().putString("endpoint",url).putString("key_"+owner,value).commit())throw new IOException("Configuration non enregistrée.");
 }
 static String secret(Context ctx,String owner)throws Exception{
  String value=prefs(ctx).getString("key_"+owner,"");if(value.isEmpty())throw new IOException("Envoi Drive non configuré pour ce compte. Contactez l’administrateur.");
  String[] parts=value.split(":");Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding");cipher.init(Cipher.DECRYPT_MODE,key(),new GCMParameterSpec(128,Base64.decode(parts[0],Base64.NO_WRAP)));
  return new String(cipher.doFinal(Base64.decode(parts[1],Base64.NO_WRAP)),StandardCharsets.UTF_8);
 }
 static String sendVisited(Context ctx,String owner,java.util.List<String[]> rows)throws Exception{
  if(rows.size()<2)throw new IOException("Aucun contrat visité : date de relève requise.");
  // Vérifier clé, service et toutes les photos avant le premier envoi.
  secret(ctx,owner);
  String endpoint=UploadProtocol.endpoint(prefs(ctx).getString("endpoint",""));
  JSONObject capabilities=new JSONObject(request(endpoint,null));
  if(capabilities.optInt("protocol")!=2)throw new IOException("Mettez à jour le script Drive 5.1.1 et son déploiement avant de décharger.");
  java.util.List<java.util.List<File>> groups=PhotoBatch.plan(ctx,rows);
  ByteArrayOutputStream excel=new ByteArrayOutputStream();TableFile.writeXlsx(excel,rows);
  int confirmed=0;
  try{
   sendFile(ctx,owner,excel.toByteArray(),"xlsx");confirmed++;
   for(java.util.List<File> group:groups){sendFile(ctx,owner,PhotoBatch.archive(group),"zip");confirmed++;}
  }catch(Exception error){throw new IOException(confirmed+" fichier(s) confirmé(s) avant interruption. Réessayez : les fichiers identiques seront dédupliqués. "+error.getMessage());}
  return (rows.size()-1)+" contrat(s) visité(s) déchargé(s) : 1 Excel et "+groups.size()+" ZIP de photos confirmés dans Drive.\nDonnées locales conservées. Aucune copie créée dans Téléchargements.";
 }
 static String sendFile(Context ctx,String owner,byte[] bytes,String format)throws Exception{
  if(bytes.length==0||bytes.length>UploadProtocol.MAX_BYTES)throw new IOException("Fichier vide ou supérieur à 6 Mio.");
  String url=UploadProtocol.endpoint(prefs(ctx).getString("endpoint",""));
  String hash=UploadProtocol.sha(bytes),id=UploadProtocol.transferId(owner,format,hash);long time=System.currentTimeMillis()/1000;
  JSONObject body=new JSONObject().put("protocol",2).put("format",format).put("owner",owner).put("sha256",hash).put("id",id).put("time",time).put("data",Base64.encodeToString(bytes,Base64.NO_WRAP));
  body.put("signature",UploadProtocol.signature(secret(ctx,owner),UploadProtocol.canonical(owner,hash,id,time,format)));
  JSONObject ack=new JSONObject(request(url,body.toString().getBytes(StandardCharsets.UTF_8)));
  if(!ack.optBoolean("ok")){
   String code=ack.optString("code","UNKNOWN");
   throw new IOException("Service Drive : "+(code.matches("[A-Z_]{1,32}")?code:"UNKNOWN")+". Vérifiez clé, dossier, horloge et déploiement.");
  }
  if(!id.equals(ack.optString("id"))||!hash.equals(ack.optString("sha256"))||!format.equals(ack.optString("format"))||ack.optString("fileId").isEmpty())throw new IOException("Accusé Drive incomplet ou incompatible. Données conservées.");
  return ack.optString("fileId");
 }
 static String request(String endpoint,byte[] body)throws Exception{
  String next=endpoint;
  for(int hop=0;hop<4;hop++){
   HttpURLConnection connection=(HttpURLConnection)new URL(next).openConnection();
   connection.setInstanceFollowRedirects(false);connection.setConnectTimeout(20000);connection.setReadTimeout(90000);
   try{
    if(hop==0&&body!=null){connection.setRequestMethod("POST");connection.setDoOutput(true);connection.setRequestProperty("Content-Type","application/json; charset=UTF-8");connection.setFixedLengthStreamingMode(body.length);try(OutputStream out=connection.getOutputStream()){out.write(body);}}
    int status=connection.getResponseCode();
    if(status==302||status==303){
     URI redirect=new URI(next).resolve(connection.getHeaderField("Location"));
     if(!"https".equals(redirect.getScheme())||!"script.googleusercontent.com".equals(redirect.getHost())||redirect.getUserInfo()!=null||redirect.getPort()!=-1)throw new IOException("Redirection Drive refusée. Vérifiez le déploiement du service.");
     next=redirect.toString();continue;
    }
    if(status!=200)throw new IOException("Envoi Drive refusé (HTTP "+status+"). Données locales conservées.");
    try(InputStream in=connection.getInputStream()){return new String(TableFile.limited(in,32768),StandardCharsets.UTF_8);}
   }finally{connection.disconnect();}
  }
  throw new IOException("Trop de redirections Drive.");
 }
}
