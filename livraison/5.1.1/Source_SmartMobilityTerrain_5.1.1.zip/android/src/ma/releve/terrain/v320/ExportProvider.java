package ma.releve.terrain.v320;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import java.io.File;
import java.io.FileNotFoundException;

public final class ExportProvider extends ContentProvider {
    @Override // android.content.ContentProvider
    public int delete(Uri uri, String str, String[] strArr) {
        throw new UnsupportedOperationException();
    }

    File file(Uri uri) throws FileNotFoundException {
        String lastPathSegment = uri.getLastPathSegment();
        if (lastPathSegment == null || !lastPathSegment.matches("[A-Za-z0-9_.-]+\\.(zip|xlsx|csv)")) {
            throw new FileNotFoundException("Nom interdit");
        }
        return new File(new File(getContext().getFilesDir(), "exports"), lastPathSegment);
    }

    @Override // android.content.ContentProvider
    public String getType(Uri uri) {
        String lastPathSegment = uri.getLastPathSegment();
        return (lastPathSegment == null || !lastPathSegment.endsWith(".xlsx")) ? (lastPathSegment == null || !lastPathSegment.endsWith(".csv")) ? "application/zip" : "text/csv" : "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
    }

    @Override // android.content.ContentProvider
    public Uri insert(Uri uri, ContentValues contentValues) {
        throw new UnsupportedOperationException();
    }

    @Override // android.content.ContentProvider
    public boolean onCreate() {
        return true;
    }

    @Override // android.content.ContentProvider
    public ParcelFileDescriptor openFile(Uri uri, String str) throws FileNotFoundException {
        if (str.equals("r")) {
            return ParcelFileDescriptor.open(file(uri), 268435456);
        }
        throw new FileNotFoundException("Lecture seule");
    }

    @Override // android.content.ContentProvider
    public Cursor query(Uri uri, String[] strArr, String str, String[] strArr2, String str2) {
        try {
            File file = file(uri);
            MatrixCursor matrixCursor = new MatrixCursor(new String[]{"_display_name", "_size"});
            matrixCursor.addRow(new Object[]{file.getName(), Long.valueOf(file.length())});
            return matrixCursor;
        } catch (Exception e) {
            return null;
        }
    }

    @Override // android.content.ContentProvider
    public int update(Uri uri, ContentValues contentValues, String str, String[] strArr) {
        throw new UnsupportedOperationException();
    }
}
