package ma.releve.terrain.v320;
import android.content.Context;
import java.io.*;
import java.util.*;
import java.util.zip.*;
final class PhotoBatch {
 static List<List<File>> plan(Context ctx,List<String[]> visited)throws Exception{
  List<List<File>> groups=new ArrayList<>();List<File> group=new ArrayList<>();long size=0;Set<String> seen=new HashSet<>();
  for(int i=1;i<visited.size();i++){
   String name=visited.get(i)[27];if(name.isEmpty()||!seen.add(name))continue;
   File file=Exchange.photo(ctx,name);
   if(!file.isFile())throw new IOException("Photo manquante : "+name+". Aucun nouveau déchargement effectué.");
   if(file.length()>5*1024*1024)throw new IOException("Une photo dépasse 5 Mio : reprenez-la avant le déchargement.");
   if(!group.isEmpty()&&size+file.length()>5*1024*1024){groups.add(group);group=new ArrayList<>();size=0;}
   group.add(file);size+=file.length();
  }
  if(!group.isEmpty())groups.add(group);return groups;
 }
 static byte[] archive(List<File> files)throws Exception{
  ByteArrayOutputStream bytes=new ByteArrayOutputStream();
  try(ZipOutputStream zip=new ZipOutputStream(bytes)){
   for(File file:files){ZipEntry entry=new ZipEntry("photos/"+file.getName());entry.setTime(0);zip.putNextEntry(entry);try(InputStream in=new FileInputStream(file)){byte[] buffer=new byte[8192];int n;while((n=in.read(buffer))!=-1)zip.write(buffer,0,n);}zip.closeEntry();}
  }
  if(bytes.size()>UploadProtocol.MAX_BYTES)throw new IOException("Lot de photos trop volumineux.");
  return bytes.toByteArray();
 }
}
