package ma.releve.terrain.v320;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.zip.*;
import org.xml.sax.*;
import org.xml.sax.helpers.DefaultHandler;

/** Validates all three sources before any database mutation. Extra sheets/files are refused. */
final class BundleImport {
    final List<String[]> meters, anomalies, types;
    BundleImport(List<String[]> m, List<String[]> a, List<String[]> t) { meters=m; anomalies=a; types=t; }
    static Map<String,byte[]> unzip(byte[] bytes) throws Exception {
        Map<String,byte[]> out=new LinkedHashMap<>(); long total=0;
        try (ZipInputStream z=new ZipInputStream(new ByteArrayInputStream(bytes))) {
            ZipEntry e;
            while ((e=z.getNextEntry())!=null) {
                if(e.isDirectory()) continue;
                String n=e.getName();
                if(n.startsWith("/") || Arrays.asList(n.split("/")).contains("..") || out.containsKey(n)) throw new IOException("Entrée ZIP invalide ou répétée");
                byte[] b=TableFile.limited(z, 33554432L); total+=b.length;
                if(total>104857600L || out.size()>=500) throw new IOException("Archive trop volumineuse");
                out.put(n,b);
            }
        }
        return out;
    }
    static byte[] zip(Map<String,byte[]> entries) throws IOException {
        ByteArrayOutputStream b=new ByteArrayOutputStream();
        try(ZipOutputStream z=new ZipOutputStream(b)) {
            for(Map.Entry<String,byte[]> e:entries.entrySet()) {z.putNextEntry(new ZipEntry(e.getKey()));z.write(e.getValue());z.closeEntry();}
        }
        return b.toByteArray();
    }
    static BundleImport read(byte[] bytes,String owner) throws Exception {
        if(bytes.length>20971520) throw new IOException("Fichier limité à 20 Mo");
        Map<String,byte[]> entries=unzip(bytes);
        Map<String,List<String[]>> tables=new HashMap<>();
        String[] names={"Releve","Anomalie","type_local"};
        if(entries.containsKey("xl/workbook.xml")) {
            Map<String,String> sheets=new LinkedHashMap<>();
            TableFile.parse(entries.get("xl/workbook.xml"),new DefaultHandler(){
                public void startElement(String uri,String local,String q,Attributes a)throws SAXException {
                    if(local.equals("sheet")) {
                        String name=a.getValue("name"), id=a.getValue("http://schemas.openxmlformats.org/officeDocument/2006/relationships","id");
                        if(name==null || id==null || sheets.put(name,id)!=null) throw new SAXException("Feuille répétée ou invalide");
                    }
                }
            });
            if(sheets.size()!=3 || !sheets.keySet().containsAll(Arrays.asList(names))) throw new IOException("Feuilles requises exactement : Releve, Anomalie, type_local");
            for(String name:names) {
                Map<String,byte[]> view=new LinkedHashMap<>(entries);
                String xml="<workbook xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\"><sheets><sheet name=\""+name+"\" sheetId=\"1\" r:id=\""+TableFile.xml(sheets.get(name))+"\"/></sheets></workbook>";
                view.put("xl/workbook.xml",xml.getBytes(StandardCharsets.UTF_8));
                tables.put(name,TableFile.readXlsx(new ByteArrayInputStream(zip(view))));
            }
        } else {
            if(entries.size()!=3) throw new IOException("ZIP requis : Releve.csv, Anomalie.csv, type_local.csv uniquement");
            for(String name:names) {
                byte[] b=entries.get(name+".csv");
                if(b==null) throw new IOException("Fichier manquant : "+name+".csv");
                String text=new String(b,StandardCharsets.UTF_8).replaceFirst("^\uFEFF","");
                if(!text.substring(0,text.indexOf('\n')<0?text.length():text.indexOf('\n')).contains(";")) throw new IOException("Séparateur CSV attendu : ;");
                List<String[]> csv=TableFile.read(new ByteArrayInputStream(b));
                if(csv.isEmpty())throw new IOException("CSV vide : "+name);
                int width=csv.get(0).length;
                for(String[] row:csv)if(!Arrays.stream(row).allMatch(String::isEmpty)&&row.length!=width)throw new IOException("Nombre de colonnes incohérent : "+name);
                tables.put(name,csv);
            }
        }
        List<String[]> meters=TableFile.validateImport(tables.get("Releve"));
        for(String[] row:meters) {if(owner!=null){if(!row[Model.READER].isEmpty()&&!row[Model.READER].equals(owner))throw new IOException("Fichier d’un autre releveur refusé");row[Model.READER]=owner;}}
        List<String[]> anomalies=catalog(tables.get("Anomalie"),true);
        List<String[]> types=catalog(tables.get("type_local"),false);
        return new BundleImport(meters,anomalies,types);
    }
    static List<String[]> catalog(List<String[]> rows,boolean anomalies)throws IOException {
        String[][] aliases=anomalies?new String[][]{{"codeanomalie","code"},{"libelleanomalie","libelle"},{"reseau","reseaux"},{"casconsommation"},{"photoobligatoire"},{"deuxiemepassage"}}:new String[][]{{"codetypelocal","code"},{"libelletypelocal","libelle"}};
        if(rows==null || rows.size()<2)throw new IOException("Catalogue vide");
        int[] columns=new int[aliases.length];Arrays.fill(columns,-1);
        for(int i=0;i<rows.get(0).length;i++)for(int j=0;j<aliases.length;j++)if(Arrays.asList(aliases[j]).contains(TableFile.normalize(rows.get(0)[i]))) {if(columns[j]!=-1)throw new IOException("Colonne répétée");columns[j]=i;}
        for(int c:columns)if(c<0)throw new IOException("Colonne de catalogue manquante");
        List<String[]> result=new ArrayList<>(); Set<String> codes=new HashSet<>();
        for(int i=1;i<rows.size();i++) {
            String[] raw=rows.get(i), row=new String[columns.length];
            if(Arrays.stream(raw).allMatch(String::isEmpty))continue;
            for(int j=0;j<columns.length;j++)row[j]=columns[j]<raw.length?raw[columns[j]].trim():"";
            if(!row[0].matches("[A-Za-z0-9_.-]{1,80}")||row[1].isEmpty()||!codes.add(row[0]))throw new IOException("Code/libellé vide, invalide ou répété");
            if(anomalies) {
                for(int j=2;j<6;j++)row[j]=row[j].toUpperCase(Locale.ROOT);
                for(String net:row[2].split("[|,; ]+"))if(!Arrays.asList("EA","BT").contains(net))throw new IOException("Réseau de catalogue invalide");
                for(String cas:row[3].split("[|,; ]+"))if(!Arrays.asList("NEGATIF","ZERO","POSITIF","SANS_INDEX","SANS_REFERENCE").contains(cas))throw new IOException("Cas de consommation invalide");
                if(row[2].isEmpty()||row[3].isEmpty())throw new IOException("Réseau/cas vide");
                for(int j=4;j<6;j++)if(!Arrays.asList("OUI","NON").contains(row[j]))throw new IOException("OUI/NON attendu");
            }
            result.add(row);
        }
        if(result.isEmpty())throw new IOException("Catalogue vide");
        return result;
    }
}
