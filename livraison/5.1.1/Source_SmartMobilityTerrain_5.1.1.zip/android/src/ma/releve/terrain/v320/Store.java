package ma.releve.terrain.v320;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Base64;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import org.json.JSONArray;

final class Store extends SQLiteOpenHelper {
    Store(Context context) {
        super(context, "releve.db", (SQLiteDatabase.CursorFactory) null, 4);
    }

    void createMeters(SQLiteDatabase sQLiteDatabase) throws SQLException {
        StringBuilder sb = new StringBuilder("CREATE TABLE compteurs (_id INTEGER PRIMARY KEY AUTOINCREMENT");
        for (String str : Model.FIELDS) {
            sb.append(", ").append(str).append(" TEXT NOT NULL DEFAULT ''");
        }
        sb.append(", UNIQUE(campagne,reseau,contrat,serie,produit))");
        sQLiteDatabase.execSQL(sb.toString());
        sQLiteDatabase.execSQL("CREATE INDEX filtre_ur ON compteurs(ur,tournee,releveur)");
    }

    void additional(SQLiteDatabase sQLiteDatabase) throws SQLException {
        sQLiteDatabase.execSQL("CREATE TABLE IF NOT EXISTS users(login TEXT PRIMARY KEY, hash TEXT NOT NULL, salt TEXT NOT NULL, role TEXT NOT NULL, display_name TEXT NOT NULL)");
        sQLiteDatabase.execSQL("CREATE TABLE IF NOT EXISTS anomalies(code TEXT PRIMARY KEY, libelle TEXT NOT NULL, reseaux TEXT NOT NULL, cas TEXT NOT NULL, photo TEXT NOT NULL, repassage TEXT NOT NULL)");
        sQLiteDatabase.execSQL("CREATE TABLE IF NOT EXISTS audit(_id INTEGER PRIMARY KEY AUTOINCREMENT, time TEXT NOT NULL, user TEXT NOT NULL, action TEXT NOT NULL, record TEXT NOT NULL, before_json TEXT NOT NULL, after_json TEXT NOT NULL)");
        sQLiteDatabase.execSQL("CREATE TABLE IF NOT EXISTS type_local(code TEXT PRIMARY KEY, libelle TEXT NOT NULL)");
        String[][] strArr = {new String[]{"DEMO_NA", "Non accessible", "EA|BT", "SANS_INDEX", "NON", "OUI"}, new String[]{"DEMO_INTR", "Compteur introuvable", "EA|BT", "SANS_INDEX", "OUI", "OUI"}, new String[]{"DEMO_BLOC", "Compteur bloqué", "EA|BT", "ZERO|POSITIF", "OUI", "NON"}, new String[]{"DEMO_NEG", "Index inférieur", "EA|BT", "NEGATIF", "OUI", "NON"}, new String[]{"DEMO_DEF", "Compteur défectueux", "EA|BT", "NEGATIF|ZERO|POSITIF|SANS_INDEX|SANS_REFERENCE", "OUI", "NON"}, new String[]{"DEMO_CHG", "Compteur changé", "EA|BT", "NEGATIF|ZERO|POSITIF|SANS_REFERENCE", "OUI", "NON"}, new String[]{"DEMO_NEUF", "Compteur absent de la liste", "EA|BT", "SANS_INDEX|SANS_REFERENCE", "OUI", "OUI"}};
        for (int i = 0; i < 7; i++) {
            String[] strArr2 = strArr[i];
            ContentValues contentValues = new ContentValues();
            String[] strArr3 = {"code", "libelle", "reseaux", "cas", "photo", "repassage"};
            for (int i2 = 0; i2 < 6; i2++) {
                contentValues.put(strArr3[i2], strArr2[i2]);
            }
            sQLiteDatabase.insertWithOnConflict("anomalies", null, contentValues, 4);
        }
    }

    @Override // android.database.sqlite.SQLiteOpenHelper
    public void onCreate(SQLiteDatabase sQLiteDatabase) throws SQLException {
        createMeters(sQLiteDatabase);
        sQLiteDatabase.execSQL("CREATE TABLE metadata(revision INTEGER NOT NULL)");
        sQLiteDatabase.execSQL("INSERT INTO metadata VALUES(0)");
        additional(sQLiteDatabase);
        archives(sQLiteDatabase);
    }

    @Override // android.database.sqlite.SQLiteOpenHelper
    public void onUpgrade(SQLiteDatabase sQLiteDatabase, int i, int i2) throws SQLException {
        if (i == 1) {
            ArrayList arrayList = new ArrayList();
            Cursor cursorQuery = sQLiteDatabase.query("compteurs", null, null, null, null, null, null);
            while (cursorQuery.moveToNext()) {
                try {
                    String[] strArrBlank = Model.blank();
                    for (int i3 = 0; i3 < 14; i3++) {
                        strArrBlank[i3] = cursorQuery.getString(cursorQuery.getColumnIndexOrThrow(Model.FIELDS[i3]));
                    }
                    strArrBlank[36] = "LEGACY_V1";
                    strArrBlank[28] = strArrBlank[10].isEmpty() ? "A_RELEVER" : strArrBlank[7].isEmpty() ? "NON_RELEVE" : "RELEVE";
                    arrayList.add(strArrBlank);
                } catch (Throwable th) {
                    if (cursorQuery != null) {
                        try {
                            cursorQuery.close();
                        } catch (Throwable th2) {
                            th.addSuppressed(th2);
                        }
                    }
                    throw th;
                }
            }
            if (cursorQuery != null) {
                cursorQuery.close();
            }
            sQLiteDatabase.execSQL("DROP INDEX IF EXISTS filtre_ur");
            sQLiteDatabase.execSQL("ALTER TABLE compteurs RENAME TO compteurs_v1");
            createMeters(sQLiteDatabase);
            Iterator it = arrayList.iterator();
            while (it.hasNext()) {
                sQLiteDatabase.insertOrThrow("compteurs", null, values((String[]) it.next()));
            }
            sQLiteDatabase.execSQL("DROP TABLE compteurs_v1");
            additional(sQLiteDatabase);
        }
        if (i < 4) sQLiteDatabase.execSQL("CREATE TABLE IF NOT EXISTS type_local(code TEXT PRIMARY KEY, libelle TEXT NOT NULL)");
        if (i < 3) {
            archives(sQLiteDatabase);
        }
    }

    void archives(SQLiteDatabase sQLiteDatabase) throws SQLException {
        sQLiteDatabase.execSQL("CREATE TABLE sauvegardes(_id INTEGER PRIMARY KEY AUTOINCREMENT, owner TEXT NOT NULL, filename TEXT NOT NULL, created TEXT NOT NULL, count INTEGER NOT NULL)");
        sQLiteDatabase.execSQL("CREATE TABLE chargements(owner TEXT PRIMARY KEY, source TEXT NOT NULL)");
    }

    List<String[]> ownRows(String str) {
        ArrayList arrayList = new ArrayList();
        Iterator<Record> it = list(str, false, "", null, null, null, 0).iterator();
        while (it.hasNext()) {
            arrayList.add((String[]) it.next().a.clone());
        }
        return arrayList;
    }

    String source(String str) {
        Cursor cursorRawQuery = getReadableDatabase().rawQuery("SELECT source FROM chargements WHERE owner=?", new String[]{str});
        try {
            String string = cursorRawQuery.moveToFirst() ? cursorRawQuery.getString(0) : "";
            if (cursorRawQuery != null) {
                cursorRawQuery.close();
            }
            return string;
        } catch (Throwable th) {
            if (cursorRawQuery != null) {
                try {
                    cursorRawQuery.close();
                } catch (Throwable th2) {
                    th.addSuppressed(th2);
                }
            }
            throw th;
        }
    }

    List<String[]> backups(String str) {
        ArrayList arrayList = new ArrayList();
        Cursor cursorRawQuery = getReadableDatabase().rawQuery("SELECT filename,created,count FROM sauvegardes WHERE owner=? ORDER BY _id DESC", new String[]{str});
        while (cursorRawQuery.moveToNext()) {
            try {
                arrayList.add(new String[]{cursorRawQuery.getString(0), cursorRawQuery.getString(1), cursorRawQuery.getString(2)});
            } catch (Throwable th) {
                if (cursorRawQuery != null) {
                    try {
                        cursorRawQuery.close();
                    } catch (Throwable th2) {
                        th.addSuppressed(th2);
                    }
                }
                throw th;
            }
        }
        if (cursorRawQuery != null) {
            cursorRawQuery.close();
        }
        return arrayList;
    }

    void registerBackup(String owner,String name,int count) {
        ContentValues v=new ContentValues();v.put("owner",owner);v.put("filename",name);v.put("created",OffsetDateTime.now().toString());v.put("count",count);
        getWritableDatabase().insertOrThrow("sauvegardes",null,v);
    }
    List<String[]> typeRows() {
        List<String[]> rows = new ArrayList<>();
        rows.add(new String[]{"Code type local", "Libelle type local"});
        try(Cursor c=getReadableDatabase().rawQuery("SELECT code,libelle FROM type_local ORDER BY code", null)) { while(c.moveToNext()) rows.add(new String[]{c.getString(0),c.getString(1)}); }
        return rows;
    }
    void replaceCatalogs(SQLiteDatabase db, BundleImport b) {
        db.delete("anomalies",null,null); db.delete("type_local",null,null);
        for(String[] row:b.anomalies) {
            ContentValues v=new ContentValues(); String[] keys={"code","libelle","reseaux","cas","photo","repassage"};
            for(int i=0;i<keys.length;i++)v.put(keys[i],row[i]);db.insertOrThrow("anomalies",null,v);
        }
        for(String[] row:b.types) {ContentValues v=new ContentValues();v.put("code",row[0]);v.put("libelle",row[1]);db.insertOrThrow("type_local",null,v);}
    }
    synchronized void replaceBundle(String owner,List<String[]> rows,long revision,String source,String backup,int count,BundleImport bundle) {
        SQLiteDatabase db=getWritableDatabase();db.beginTransaction();
        try {
            replaceOwn(owner,rows,revision,source,backup,count);
            if(bundle!=null)replaceCatalogs(db,bundle);
            db.setTransactionSuccessful();
        } finally {db.endTransaction();}
    }

    synchronized void replaceOwn(String str, List<String[]> list, long j, String str2, String str3, int i) {
        SQLiteDatabase writableDatabase = getWritableDatabase();
        writableDatabase.beginTransaction();
        try {
            if (revision() != j) {
                throw new IllegalStateException("Les données ont changé. Relancez la synchronisation.");
            }
            Iterator<String[]> it = list.iterator();
            while (it.hasNext()) {
                if (!it.next()[23].equals(str)) {
                    throw new IllegalArgumentException("Fichier d’un autre releveur refusé.");
                }
            }
            writableDatabase.delete("compteurs", "releveur=?", new String[]{str});
            Iterator<String[]> it2 = list.iterator();
            while (it2.hasNext()) {
                writableDatabase.insertOrThrow("compteurs", null, values(it2.next()));
            }
            ContentValues contentValues = new ContentValues();
            contentValues.put("owner", str);
            contentValues.put("source", str2);
            writableDatabase.insertWithOnConflict("chargements", null, contentValues, 5);
            if (!str3.isEmpty()) {
                ContentValues contentValues2 = new ContentValues();
                contentValues2.put("owner", str);
                contentValues2.put("filename", str3);
                contentValues2.put("created", OffsetDateTime.now().toString());
                contentValues2.put("count", Integer.valueOf(i));
                writableDatabase.insertOrThrow("sauvegardes", null, contentValues2);
            }
            log(writableDatabase, str, "TOURNEE_REMPLACEE", "", "", "Nouveaux=" + list.size() + "; sauvegarde=" + str3);
            writableDatabase.execSQL("UPDATE metadata SET revision=revision+1");
            writableDatabase.setTransactionSuccessful();
        } finally {
            writableDatabase.endTransaction();
        }
    }

    static final class Record {
        String[] a;
        long id;

        Record(Cursor cursor) {
            this.id = cursor.getLong(cursor.getColumnIndexOrThrow("_id"));
            this.a = new String[Model.FIELDS.length];
            for (int i = 0; i < this.a.length; i++) {
                this.a[i] = cursor.getString(cursor.getColumnIndexOrThrow(Model.FIELDS[i]));
            }
        }

        Record(String[] strArr) {
            this.a = strArr;
        }
    }

    ContentValues values(String[] strArr) {
        ContentValues contentValues = new ContentValues();
        for (int i = 0; i < Model.FIELDS.length; i++) {
            contentValues.put(Model.FIELDS[i], strArr[i]);
        }
        return contentValues;
    }

    Record get(long j) {
        Cursor cursorQuery = getReadableDatabase().query("compteurs", null, "_id=?", new String[]{"" + j}, null, null, null);
        try {
            Record record = cursorQuery.moveToFirst() ? new Record(cursorQuery) : null;
            if (cursorQuery != null) {
                cursorQuery.close();
            }
            return record;
        } catch (Throwable th) {
            if (cursorQuery != null) {
                try {
                    cursorQuery.close();
                } catch (Throwable th2) {
                    th.addSuppressed(th2);
                }
            }
            throw th;
        }
    }

    void log(SQLiteDatabase sQLiteDatabase, String str, String str2, String str3, String str4, String str5) throws SQLException {
        ContentValues contentValues = new ContentValues();
        contentValues.put("time", OffsetDateTime.now().toString());
        contentValues.put("user", str);
        contentValues.put("action", str2);
        contentValues.put("record", str3);
        contentValues.put("before_json", str4);
        contentValues.put("after_json", str5);
        sQLiteDatabase.insertOrThrow("audit", null, contentValues);
    }

    void log(String str, String str2, String str3) throws SQLException {
        log(getWritableDatabase(), str, str2, "", "", str3);
    }

    synchronized int[] addBundle(BundleImport bundle,String campaign,String actor) {
        SQLiteDatabase db=getWritableDatabase();db.beginTransaction();
        try {
            int[] counts=add(bundle.meters,campaign,actor);
            replaceCatalogs(db,bundle);
            db.execSQL("UPDATE metadata SET revision=revision+1");
            log(db,actor,"CATALOGUES_REMPLACES","","","Import administrateur à trois sources");
            db.setTransactionSuccessful();return counts;
        } finally {db.endTransaction();}
    }

    synchronized int[] add(List<String[]> list, String str, String str2) {
        int i;
        SQLiteDatabase writableDatabase = getWritableDatabase();
        writableDatabase.beginTransaction();
        try {
            i = 0;
            for (String[] strArr : list) {
                strArr[36] = str;
                if (writableDatabase.insertWithOnConflict("compteurs", null, values(strArr), 4) != -1) {
                    i++;
                }
            }
            if (i > 0) {
                writableDatabase.execSQL("UPDATE metadata SET revision=revision+1");
            }
            log(writableDatabase, str2, "IMPORT", str, "", "Ajoutés=" + i + ", conservés=" + (list.size() - i));
            writableDatabase.setTransactionSuccessful();
            writableDatabase.endTransaction();
        } catch (Throwable th) {
            writableDatabase.endTransaction();
            throw th;
        }
        return new int[]{i, list.size() - i};
    }

    synchronized void save(Record record, String str) {
        SQLiteDatabase writableDatabase = getWritableDatabase();
        writableDatabase.beginTransaction();
        try {
            Record record2 = record.id == 0 ? null : get(record.id);
            String[] strArr = record.a;
            StringBuilder sbAppend = new StringBuilder().append("");
            long j = 1;
            if (record2 != null) {
                j = 1 + Long.parseLong(record2.a[31].isEmpty() ? "0" : record2.a[31]);
            }
            strArr[31] = sbAppend.append(j).toString();
            record.a[29] = "LOCAL";
            if (record.id == 0) {
                record.id = writableDatabase.insertOrThrow("compteurs", null, values(record.a));
            } else if (writableDatabase.update("compteurs", values(record.a), "_id=?", new String[]{"" + record.id}) != 1) {
                throw new IllegalStateException("Compteur introuvable.");
            }
            log(writableDatabase, str, record2 == null ? "CREATION" : "RELEVE", record.a[30], record2 == null ? "" : new JSONArray((Collection) Arrays.asList(record2.a)).toString(), new JSONArray((Collection) Arrays.asList(record.a)).toString());
            writableDatabase.execSQL("UPDATE metadata SET revision=revision+1");
            writableDatabase.setTransactionSuccessful();
        } finally {
            writableDatabase.endTransaction();
        }
    }

    String scope(String str, boolean z) {
        return z ? "1=1" : "releveur='" + str.replace("'", "''") + "'";
    }

    List<Record> list(String str, boolean z, String str2, String str3, String str4, String str5, int i) {
        return list(str, z, str2, str3, str4, str5, i, null);
    }

        List<Record> list(String owner,boolean admin,String query,String ur,String tour,String status,int limit,String campaign) {
        String where=scope(owner,admin); List<String> args=new ArrayList<>();
        if(campaign!=null){where+=" AND campagne=?";args.add(campaign);}
        if(!query.isEmpty()) {
            where+=" AND (instr(lower(contrat),lower(?))>0 OR instr(lower(nom),lower(?))>0 OR instr(lower(serie),lower(?))>0 OR instr(lower(adresse),lower(?))>0 OR instr(lower(ur),lower(?))>0 OR instr(lower(identifiant),lower(?))>0)";
            for(int i=0;i<6;i++)args.add(query);
        }
        if(ur!=null){where+=" AND ur=?";args.add(ur);}
        if(tour!=null){where+=" AND tournee=?";args.add(tour);}
        if("_RELEVES".equals(status))where+=" AND nouveau<>''";
        else if("_NON_RELEVES".equals(status))where+=" AND nouveau=''";
        else if(status!=null){where+=" AND etat=?";args.add(status);}
        List<Record> result=new ArrayList<>();
        try(Cursor c=getReadableDatabase().query("compteurs",null,where,args.toArray(new String[0]),null,null,"CASE WHEN ordre='' THEN 1 ELSE 0 END,CAST(ordre AS INTEGER),_id",limit==0?null:Integer.toString(limit))) {
            while(c.moveToNext())result.add(new Record(c));
        }
        return result;
    }

    List<String> distinct(String str, String str2, boolean z) {
        ArrayList arrayList = new ArrayList();
        Cursor cursorRawQuery = getReadableDatabase().rawQuery("SELECT DISTINCT " + str + " FROM compteurs WHERE " + scope(str2, z) + " ORDER BY " + str, null);
        while (cursorRawQuery.moveToNext()) {
            try {
                arrayList.add(cursorRawQuery.getString(0));
            } catch (Throwable th) {
                if (cursorRawQuery != null) {
                    try {
                        cursorRawQuery.close();
                    } catch (Throwable th2) {
                        th.addSuppressed(th2);
                    }
                }
                throw th;
            }
        }
        if (cursorRawQuery != null) {
            cursorRawQuery.close();
        }
        return arrayList;
    }

    String loginRole(String owner){
        try(Cursor cursor=getReadableDatabase().rawQuery("SELECT role FROM users WHERE login=?",new String[]{owner})){return cursor.moveToFirst()?cursor.getString(0):null;}
    }

    List<String[]> export(String owner, boolean admin) {
        List<String[]> rows=new ArrayList<>();
        String[] header=Arrays.copyOf(Model.LABELS,Model.LABELS.length+1);
        header[Model.LABELS.length]="Libelle anomalie";rows.add(header);
        java.util.Map<String,String> labels=new java.util.HashMap<>();
        for(Anomaly anomaly:anomalies(null,null))labels.put(anomaly.code,anomaly.label);
        for(Record record:list(owner,admin,"",null,null,null,0)){
            String[] row=Arrays.copyOf(record.a,header.length);
            row[Model.LABELS.length]=labels.containsKey(record.a[8])?labels.get(record.a[8]):"";
            rows.add(row);
        }
        return rows;
    }

    List<String[]> exportVisited(String owner){
        List<String[]> rows=export(owner,false),visited=new ArrayList<>();visited.add(rows.get(0));
        for(int i=1;i<rows.size();i++)if(!rows.get(i)[Model.DATE].trim().isEmpty())visited.add(rows.get(i));
        return visited;
    }

    List<Record> pending(String str, boolean z) {
        ArrayList arrayList = new ArrayList();
        for (Record record : list(str, z, "", null, null, null, 0)) {
            if (record.a[29].equals("EN_ATTENTE")) {
                arrayList.add(record);
            }
        }
        return arrayList;
    }

    synchronized void ack(String str, String str2, String str3) {
        SQLiteDatabase writableDatabase = getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("sync", "SYNCHRONISE");
        if (writableDatabase.update("compteurs", contentValues, "uuid=? AND version=?", new String[]{str, str2}) > 0) {
            log(writableDatabase, str3, "SYNCHRONISATION", str, "", str2);
        }
    }

    long revision() {
        Cursor cursorRawQuery = getReadableDatabase().rawQuery("SELECT revision FROM metadata", null);
        try {
            cursorRawQuery.moveToFirst();
            long j = cursorRawQuery.getLong(0);
            if (cursorRawQuery != null) {
                cursorRawQuery.close();
            }
            return j;
        } catch (Throwable th) {
            if (cursorRawQuery != null) {
                try {
                    cursorRawQuery.close();
                } catch (Throwable th2) {
                    th.addSuppressed(th2);
                }
            }
            throw th;
        }
    }

    synchronized void assign(String str, String str2, String str3, String str4, String str5, String str6) {
        SQLiteDatabase writableDatabase = getWritableDatabase();
        writableDatabase.beginTransaction();
        try {
            Cursor cursorQuery = writableDatabase.query("compteurs", null, "campagne=? AND reseau=? AND ur=? AND tournee=?", new String[]{str, str2, str3, str4}, null, null, null);
            while (cursorQuery.moveToNext()) {
                try {
                    Record record = new Record(cursorQuery);
                    if (record.a[10].isEmpty()) {
                        ContentValues contentValues = new ContentValues();
                        contentValues.put("releveur", str5);
                        writableDatabase.update("compteurs", contentValues, "_id=?", new String[]{"" + record.id});
                        log(writableDatabase, str6, "AFFECTATION", record.a[30], record.a[23], str5);
                    }
                } finally {
                }
            }
            if (cursorQuery != null) {
                cursorQuery.close();
            }
            writableDatabase.execSQL("UPDATE metadata SET revision=revision+1");
            writableDatabase.setTransactionSuccessful();
        } finally {
            writableDatabase.endTransaction();
        }
    }

    List<String[]> audit() {
        ArrayList arrayList = new ArrayList();
        arrayList.add(new String[]{"Date ISO", "Utilisateur", "Action", "UUID", "Avant JSON", "Apres JSON"});
        Cursor cursorRawQuery = getReadableDatabase().rawQuery("SELECT time,user,action,record,before_json,after_json FROM audit ORDER BY _id DESC", null);
        while (cursorRawQuery.moveToNext()) {
            try {
                String[] strArr = new String[6];
                for (int i = 0; i < 6; i++) {
                    strArr[i] = cursorRawQuery.getString(i);
                }
                arrayList.add(strArr);
            } catch (Throwable th) {
                if (cursorRawQuery != null) {
                    try {
                        cursorRawQuery.close();
                    } catch (Throwable th2) {
                        th.addSuppressed(th2);
                    }
                }
                throw th;
            }
        }
        if (cursorRawQuery != null) {
            cursorRawQuery.close();
        }
        return arrayList;
    }

    static String hash(String str, String str2) throws Exception {
        return Base64.encodeToString(SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(new PBEKeySpec(str.toCharArray(), Base64.decode(str2, 0), 120000, 256)).getEncoded(), 2);
    }

    boolean hasUsers() {
        Cursor cursorRawQuery = getReadableDatabase().rawQuery("SELECT COUNT(*) FROM users", null);
        try {
            cursorRawQuery.moveToFirst();
            boolean z = cursorRawQuery.getInt(0) > 0;
            if (cursorRawQuery != null) {
                cursorRawQuery.close();
            }
            return z;
        } catch (Throwable th) {
            if (cursorRawQuery != null) {
                try {
                    cursorRawQuery.close();
                } catch (Throwable th2) {
                    th.addSuppressed(th2);
                }
            }
            throw th;
        }
    }

    void user(String str, String str2, String str3, String str4, String str5) throws Exception {
        if (!str.matches("[A-Za-z0-9_.-]{3,40}")) {
            throw new Exception("Identifiant : 3 à 40 lettres, chiffres, points, tirets ou underscores.");
        }
        if (str4.trim().isEmpty()) {
            throw new Exception("Nom du releveur obligatoire.");
        }
        if (str2.length() < 8) {
            throw new Exception("Mot de passe : au moins 8 caractères.");
        }
        byte[] bArr = new byte[16];
        new SecureRandom().nextBytes(bArr);
        String strEncodeToString = Base64.encodeToString(bArr, 2);
        ContentValues contentValues = new ContentValues();
        contentValues.put("login", str);
        contentValues.put("hash", hash(str2, strEncodeToString));
        contentValues.put("salt", strEncodeToString);
        contentValues.put("role", str3);
        contentValues.put("display_name", str4.trim());
        getWritableDatabase().insertOrThrow("users", null, contentValues);
        log(str5, "UTILISATEUR_CREE", str + " " + str3);
    }

    String login(String str, String str2) throws Exception {
        Cursor cursorQuery = getReadableDatabase().query("users", null, "login=?", new String[]{str}, null, null, null);
        try {
            if (!cursorQuery.moveToFirst()) {
                if (cursorQuery != null) {
                    cursorQuery.close();
                }
                return null;
            }
            String string = MessageDigest.isEqual(hash(str2, cursorQuery.getString(cursorQuery.getColumnIndexOrThrow("salt"))).getBytes("UTF-8"), cursorQuery.getString(cursorQuery.getColumnIndexOrThrow("hash")).getBytes("UTF-8")) ? cursorQuery.getString(cursorQuery.getColumnIndexOrThrow("role")) : null;
            if (cursorQuery != null) {
                cursorQuery.close();
            }
            return string;
        } catch (Throwable th) {
            if (cursorQuery != null) {
                try {
                    cursorQuery.close();
                } catch (Throwable th2) {
                    th.addSuppressed(th2);
                }
            }
            throw th;
        }
    }

    void changePassword(String account, String current, String replacement, String confirmation) throws Exception {
        if (replacement.length() < 8) throw new Exception("Mot de passe : au moins 8 caractères.");
        if (!replacement.equals(confirmation)) throw new Exception("Les nouveaux mots de passe ne correspondent pas.");
        SQLiteDatabase database = getWritableDatabase();
        database.beginTransaction();
        try {
            if (login(account, current) == null) throw new Exception("Mot de passe actuel incorrect.");
            byte[] salt = new byte[16];
            new SecureRandom().nextBytes(salt);
            String encoded = Base64.encodeToString(salt, 2);
            ContentValues values = new ContentValues();
            values.put("salt", encoded);
            values.put("hash", hash(replacement, encoded));
            if (database.update("users", values, "login=?", new String[]{account}) != 1)
                throw new Exception("Compte introuvable.");
            log(account, "MOT_DE_PASSE_MODIFIE", "Modification du mot de passe local");
            database.setTransactionSuccessful();
        } finally {
            database.endTransaction();
        }
    }

    String displayName(String str) {
        Cursor cursorQuery = getReadableDatabase().query("users", new String[]{"display_name"}, "login=?", new String[]{str}, null, null, null);
        try {
            if (cursorQuery.moveToFirst()) {
                str = cursorQuery.getString(0);
            }
            if (cursorQuery != null) {
                cursorQuery.close();
            }
            return str;
        } catch (Throwable th) {
            if (cursorQuery != null) {
                try {
                    cursorQuery.close();
                } catch (Throwable th2) {
                    th.addSuppressed(th2);
                }
            }
            throw th;
        }
    }

    void rename(String str, String str2, String str3) throws SQLException {
        if (str2.trim().isEmpty()) {
            throw new IllegalArgumentException("Nom obligatoire.");
        }
        ContentValues contentValues = new ContentValues();
        contentValues.put("display_name", str2.trim());
        getWritableDatabase().update("users", contentValues, "login=?", new String[]{str});
        log(str3, "NOM_RELEVEUR", str + " = " + str2.trim());
    }

    static final class Anomaly {
        String cases;
        String code;
        String label;
        String nets;
        boolean photo;
        boolean repeat;

        Anomaly(String[] strArr) {
            this.code = strArr[0];
            this.label = strArr[1];
            this.nets = strArr[2];
            this.cases = strArr[3];
            this.photo = strArr[4].equals("OUI");
            this.repeat = strArr[5].equals("OUI");
        }

        public String toString() {
            return this.code + " — " + this.label + (this.photo ? " • 📷" : "");
        }
    }

    List<String> users() {
        ArrayList arrayList = new ArrayList();
        Cursor cursorRawQuery = getReadableDatabase().rawQuery("SELECT login FROM users ORDER BY login", null);
        while (cursorRawQuery.moveToNext()) {
            try {
                arrayList.add(cursorRawQuery.getString(0));
            } catch (Throwable th) {
                if (cursorRawQuery != null) {
                    try {
                        cursorRawQuery.close();
                    } catch (Throwable th2) {
                        th.addSuppressed(th2);
                    }
                }
                throw th;
            }
        }
        if (cursorRawQuery != null) {
            cursorRawQuery.close();
        }
        return arrayList;
    }

    List<Anomaly> anomalies(String str, String str2) {
        ArrayList arrayList = new ArrayList();
        Cursor cursorRawQuery = getReadableDatabase().rawQuery("SELECT code,libelle,reseaux,cas,photo,repassage FROM anomalies ORDER BY code", null);
        while (cursorRawQuery.moveToNext()) {
            try {
                String[] strArr = new String[6];
                for (int i = 0; i < 6; i++) {
                    strArr[i] = cursorRawQuery.getString(i);
                }
                Anomaly anomaly = new Anomaly(strArr);
                if (str == null || Model.contains(anomaly.nets, str)) {
                    if (str2 == null || Model.contains(anomaly.cases, str2)) {
                        arrayList.add(anomaly);
                    }
                }
            } catch (Throwable th) {
                if (cursorRawQuery != null) {
                    try {
                        cursorRawQuery.close();
                    } catch (Throwable th2) {
                        th.addSuppressed(th2);
                    }
                }
                throw th;
            }
        }
        if (cursorRawQuery != null) {
            cursorRawQuery.close();
        }
        return arrayList;
    }

    List<String[]> anomalyRows() {
        ArrayList arrayList = new ArrayList();
        arrayList.add(new String[]{"Code", "Libelle", "Reseaux", "Cas consommation", "Photo obligatoire", "Deuxieme passage"});
        for (Anomaly anomaly : anomalies(null, null)) {
            String str = anomaly.code;
            String str2 = anomaly.label;
            String str3 = anomaly.nets;
            String str4 = anomaly.cases;
            String str5 = "OUI";
            String str6 = anomaly.photo ? "OUI" : "NON";
            if (!anomaly.repeat) {
                str5 = "NON";
            }
            arrayList.add(new String[]{str, str2, str3, str4, str6, str5});
        }
        return arrayList;
    }

    static List<String[]> validateAnomalies(List<String[]> rows) throws Exception {
        return BundleImport.catalog(rows,true);
    }

    synchronized void replaceAnomalies(List<String[]> list, String str) {
        SQLiteDatabase writableDatabase = getWritableDatabase();
        writableDatabase.beginTransaction();
        try {
            writableDatabase.delete("anomalies", null, null);
            String[] strArr = {"code", "libelle", "reseaux", "cas", "photo", "repassage"};
            for (String[] strArr2 : list) {
                ContentValues contentValues = new ContentValues();
                for (int i = 0; i < 6; i++) {
                    contentValues.put(strArr[i], strArr2[i]);
                }
                writableDatabase.insertOrThrow("anomalies", null, contentValues);
            }
            writableDatabase.execSQL("UPDATE metadata SET revision=revision+1");
            log(writableDatabase, str, "CATALOGUE_REMPLACE", "", "", "Codes=" + list.size());
            writableDatabase.setTransactionSuccessful();
        } finally {
            writableDatabase.endTransaction();
        }
    }
}
