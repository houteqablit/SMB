package ma.releve.terrain.v320;
/** First entry remains in memory, never in a second visible field. */
final class IndexConfirmation {
    String first=""; boolean confirmed;
    void reset(){first="";confirmed=false;}
    boolean pending(){return !first.isEmpty()&&!confirmed;}
    void edited(String value){if(confirmed&&!same(first,value))reset();}
    static boolean same(String a,String b){return Model.numeric(a)&&Model.numeric(b)&&Model.num(a).compareTo(Model.num(b))==0;}
    boolean accept(String value,boolean abnormal){
        if(pending()){confirmed=same(first,value);if(!confirmed)first=value;return confirmed;}
        if(!abnormal)return true;
        if(confirmed&&same(first,value))return true;
        first=value;confirmed=false;return false;
    }
}
