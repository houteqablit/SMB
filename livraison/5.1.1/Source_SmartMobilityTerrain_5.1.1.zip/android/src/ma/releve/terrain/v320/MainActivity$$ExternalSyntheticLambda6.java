package ma.releve.terrain.v320;

/* compiled from: D8$$SyntheticClass */
public final /* synthetic */ class MainActivity$$ExternalSyntheticLambda6 implements Runnable {
    public final /* synthetic */ MainActivity f$0;

    public MainActivity$$ExternalSyntheticLambda6(MainActivity owner) { this.f$0 = owner; }

    @Override // java.lang.Runnable
    public final void run() {
        this.f$0.home();
    }
}
