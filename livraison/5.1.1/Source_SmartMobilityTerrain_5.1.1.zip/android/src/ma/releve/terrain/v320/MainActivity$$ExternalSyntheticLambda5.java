package ma.releve.terrain.v320;

import ma.releve.terrain.v320.MainActivity;

/* compiled from: D8$$SyntheticClass */
public final /* synthetic */ class MainActivity$$ExternalSyntheticLambda5 implements MainActivity.Done {
    public final /* synthetic */ MainActivity f$0;

    public MainActivity$$ExternalSyntheticLambda5(MainActivity owner) { this.f$0 = owner; }

    @Override // ma.releve.terrain.v320.MainActivity.Done
    public final void result(String str) {
        this.f$0.alert(str);
    }
}
