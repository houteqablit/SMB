package ma.releve.terrain.v320;

import android.content.Context;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import ma.releve.terrain.v320.BackupPack;
import ma.releve.terrain.v320.Store;

final class LocalTransfer {
    LocalTransfer() {
    }

    static List<String[]> validate(byte[] bArr, String str) throws Exception {
        DirectDrive.checkContent(bArr);
        List<String[]> listValidateImport = BundleImport.read(bArr, str).meters;
        for (String[] strArr : listValidateImport) {
            if (!strArr[23].isEmpty() && !strArr[23].equals(str)) {
                throw new IOException("Fichier affecté à un autre releveur : " + strArr[23]);
            }
            strArr[23] = str;
        }
        return listValidateImport;
    }

    static File folder(Context context, String str) throws IOException {
        File file = new File(context.getFilesDir(), str);
        if (file.isDirectory() || file.mkdirs()) {
            return file;
        }
        throw new IOException("Stockage local inaccessible.");
    }

    static File source(Context context, Store store, String str) {
        String strSource = store.source(str);
        if (strSource.isEmpty()) {
            return null;
        }
        return new File(new File(context.getFilesDir(), "sources"), strSource);
    }

    static void durable(File file, byte[] bArr) throws IOException {
        FileOutputStream fileOutputStream = new FileOutputStream(file);
        try {
            fileOutputStream.write(bArr);
            fileOutputStream.flush();
            fileOutputStream.getFD().sync();
            fileOutputStream.close();
        } catch (Throwable th) {
            try {
                fileOutputStream.close();
            } catch (Throwable th2) {
                th.addSuppressed(th2);
            }
            throw th;
        }
    }

    static File backup(Context context, String str, List<String[]> list, File file) throws Exception {
        File fileFolder = folder(context, "exports");
        String str2 = "Sauvegarde_" + str + "_" + new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date()) + "_" + UUID.randomUUID().toString().substring(0, 8) + ".zip";
        File file2 = new File(fileFolder, str2 + ".tmp");
        File file3 = new File(fileFolder, str2);
        try {
            FileOutputStream fileOutputStream = new FileOutputStream(file2);
            try {
                Store catalogStore = new Store(context);
                try {BackupPack.write(fileOutputStream, str, list, folder(context, "photos"), file, catalogStore.anomalyRows(), catalogStore.typeRows());} finally {catalogStore.close();}
                fileOutputStream.getFD().sync();
                fileOutputStream.close();
                if (file2.renameTo(file3)) {
                    return file3;
                }
                throw new IOException("Sauvegarde impossible.");
            } catch (Throwable th) {
                try {
                    fileOutputStream.close();
                    throw th;
                } catch (Throwable th2) {
                    th.addSuppressed(th2);
                    throw th;
                }
            }
        } catch (Exception e) {
            file2.delete();
            throw e;
        }
    }

        static String replace(Context context, Store store, String owner, List<String[]> rows, byte[] bytes, boolean save, long revision, boolean restoring) throws Exception {
        return replace(context,store,owner,rows,bytes,save,revision,restoring,null);
    }
    static String replace(Context context, Store store, String owner, List<String[]> rows, byte[] bytes, boolean save, long revision, boolean restoring, BundleImport restoredCatalogs) throws Exception {
        List<String[]> old = store.ownRows(owner);
        File previous = source(context, store, owner);
        File backup = save ? backup(context, owner, old, previous) : null;
        File newSource = null;
        boolean committed = false;
        try {
            String sourceName = "";
            if (bytes != null) {
                sourceName = owner + "_" + UUID.randomUUID() + ".bin";
                newSource = new File(folder(context, "sources"), sourceName);
                durable(newSource, bytes);
            }
            if (!restoring) {
                String campaign = new SimpleDateFormat("yyyy-MM-dd_HHmmss").format(new Date());
                for (String[] row : rows) row[Model.CAMPAIGN] = campaign;
            }
            BundleImport bundle = restoring ? restoredCatalogs : bytes == null ? null : BundleImport.read(bytes, owner);
            store.replaceBundle(owner, rows, revision, sourceName, backup == null ? "" : backup.getName(), old.size(), bundle);
            committed = true;
            try {
                HashSet<String> referenced = new HashSet<>();
                for (Store.Record r : store.list(owner, true, "", null, null, null, 0)) referenced.add(r.a[Model.PHOTO]);
                for (String[] r : old) if (!r[Model.PHOTO].isEmpty() && !referenced.contains(r[Model.PHOTO])) Exchange.photo(context, r[Model.PHOTO]).delete();
                if (previous != null) previous.delete();
            } catch (Exception ignored) { }
            return rows.size() + " compteurs chargés.";
        } finally {
            if (!committed && newSource != null) newSource.delete();
        }
    }

    static void restorePhotos(Context context, BackupPack.Snapshot snapshot) throws Exception {
        File fileFolder = folder(context, "photos");
        for (Map.Entry<String, byte[]> entry : snapshot.photos.entrySet()) {
            File file = new File(fileFolder, entry.getKey());
            if (file.exists()) {
                FileInputStream fileInputStream = new FileInputStream(file);
                try {
                    if (!Arrays.equals(TableFile.limited(fileInputStream, 104857600L), entry.getValue())) {
                        throw new IOException("Une photo porte déjà le même nom avec un contenu différent. Restauration annulée.");
                    }
                    fileInputStream.close();
                } catch (Throwable th) {
                    try {
                        fileInputStream.close();
                    } catch (Throwable th2) {
                        th.addSuppressed(th2);
                    }
                    throw th;
                }
            } else {
                durable(file, entry.getValue());
            }
        }
    }
}
