package ma.releve.terrain.v320;

import java.math.BigDecimal;

public final class ReadingRules {
    public static BigDecimal number(String str) {
        return new BigDecimal(str.trim().replace(',', '.'));
    }

    public static String validate(String str, String str2, String str3, String str4) {
        if (str2.trim().isEmpty()) {
            if (str3.trim().isEmpty()) {
                return "Saisissez un index ou une anomalie.";
            }
            return null;
        }
        if (!str2.trim().matches("[0-9]+([.,][0-9]{1,3})?")) {
            return "Index invalide : nombre positif, avec au maximum 3 décimales.";
        }
        if (number(str2).compareTo(number(str)) >= 0 || !(str3.trim().isEmpty() || str4.trim().isEmpty())) {
            return null;
        }
        return "Index inférieur à l’ancien : renseignez une anomalie et un commentaire justificatif.";
    }
}
