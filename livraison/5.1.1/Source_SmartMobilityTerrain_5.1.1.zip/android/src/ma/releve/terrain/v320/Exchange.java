package ma.releve.terrain.v320;

import android.content.Context;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.HashSet;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

final class Exchange {
    Exchange() {
    }

    static File photo(Context context, String str) throws IOException {
        if (str.matches("[A-Za-z0-9_.-]+\\.jpg")) {
            return new File(new File(context.getFilesDir(), "photos"), str);
        }
        throw new IOException("Nom photo invalide.");
    }

    static void zip(Context context, OutputStream outputStream, List<String[]> list, String str) throws Exception {
        ZipOutputStream zipOutputStream = new ZipOutputStream(outputStream);
        zipOutputStream.putNextEntry(new ZipEntry(str + ".xlsx"));
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        TableFile.writeXlsx(byteArrayOutputStream, list);
        zipOutputStream.write(byteArrayOutputStream.toByteArray());
        zipOutputStream.closeEntry();
        zipOutputStream.putNextEntry(new ZipEntry(str + ".csv"));
        ByteArrayOutputStream byteArrayOutputStream2 = new ByteArrayOutputStream();
        TableFile.writeCsv(byteArrayOutputStream2, list);
        zipOutputStream.write(byteArrayOutputStream2.toByteArray());
        zipOutputStream.closeEntry();
        HashSet hashSet = new HashSet();
        for (int i = 1; i < list.size(); i++) {
            String str2 = list.get(i)[27];
            if (!str2.isEmpty() && hashSet.add(str2)) {
                File filePhoto = photo(context, str2);
                if (!filePhoto.isFile()) {
                    throw new IOException("Photo manquante : " + str2);
                }
                zipOutputStream.putNextEntry(new ZipEntry("photos/" + str2));
                FileInputStream fileInputStream = new FileInputStream(filePhoto);
                try {
                    byte[] bArr = new byte[8192];
                    while (true) {
                        int i2 = fileInputStream.read(bArr);
                        if (i2 == -1) {
                            break;
                        } else {
                            zipOutputStream.write(bArr, 0, i2);
                        }
                    }
                    fileInputStream.close();
                    zipOutputStream.closeEntry();
                } catch (Throwable th) {
                    try {
                        fileInputStream.close();
                    } catch (Throwable th2) {
                        th.addSuppressed(th2);
                    }
                    throw th;
                }
            }
        }
        zipOutputStream.finish();
        zipOutputStream.flush();
    }

    static String safe(String str) {
        String strReplaceAll = str.replaceAll("[^A-Za-z0-9_.-]", "_");
        return strReplaceAll.isEmpty() ? "releve" : strReplaceAll;
    }
}
