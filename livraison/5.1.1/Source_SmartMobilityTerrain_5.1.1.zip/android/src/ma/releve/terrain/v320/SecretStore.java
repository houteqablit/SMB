package ma.releve.terrain.v320;

import android.content.Context;
import android.security.keystore.KeyGenParameterSpec;
import android.util.Base64;
import java.security.KeyStore;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

final class SecretStore {
    SecretStore() {
    }

    static SecretKey key() throws Exception {
        KeyStore keyStore = KeyStore.getInstance("AndroidKeyStore");
        keyStore.load(null);
        if (!keyStore.containsAlias("smartmobility_sync")) {
            KeyGenerator keyGenerator = KeyGenerator.getInstance("AES", "AndroidKeyStore");
            keyGenerator.init(new KeyGenParameterSpec.Builder("smartmobility_sync", 3).setBlockModes("GCM").setEncryptionPaddings("NoPadding").build());
            keyGenerator.generateKey();
        }
        return (SecretKey) keyStore.getKey("smartmobility_sync", null);
    }

    static void set(Context context, String str, String str2) throws Exception {
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(1, key());
        context.getSharedPreferences("sync", 0).edit().putString("token_" + str, Base64.encodeToString(cipher.getIV(), 2) + ":" + Base64.encodeToString(cipher.doFinal(str2.getBytes("UTF-8")), 2)).commit();
    }

    static String get(Context context, String str) throws Exception {
        String string = context.getSharedPreferences("sync", 0).getString("token_" + str, "");
        if (string.isEmpty()) {
            return "";
        }
        String[] strArrSplit = string.split(":");
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(2, key(), new GCMParameterSpec(128, Base64.decode(strArrSplit[0], 2)));
        return new String(cipher.doFinal(Base64.decode(strArrSplit[1], 2)), "UTF-8");
    }
}
