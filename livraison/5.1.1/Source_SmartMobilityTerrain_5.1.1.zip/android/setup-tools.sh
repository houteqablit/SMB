#!/bin/bash
set -euo pipefail
mkdir -p /workspace/tool-downloads /workspace/tools/jdk17 /workspace/android-sdk
python3 - <<'PY'
import hashlib, pathlib, subprocess, zipfile, tarfile
cache=pathlib.Path('/workspace/tool-downloads')
sdk=pathlib.Path('/workspace/android-sdk')
packages=[
 ('jdk.tar.gz','https://github.com/adoptium/temurin17-binaries/releases/download/jdk-17.0.16%2B8/OpenJDK17U-jdk_x64_linux_hotspot_17.0.16_8.tar.gz',None,None),
 ('platform.zip','https://dl.google.com/android/repository/platform-35_r02.zip','0bb560a90a7a2cbd0dd8348224d518b638fe7949','platforms'),
 ('build-tools.zip','https://dl.google.com/android/repository/build-tools_r35_linux.zip','2cfaa0bbb2336e9ec18ed3ecea84fa2e2af607bc','build-tools'),
 ('platform-tools.zip','https://dl.google.com/android/repository/platform-tools_r37.0.1-linux.zip','477254aa5f903c15cf51001717bdf347fb6b53e0',''),
]
for name,url,digest,dest in packages:
    p=cache/name
    if not p.exists():subprocess.run(['curl','-fLsS','--max-time','180',url,'-o',str(p)],check=True)
    if dest is None:
        checksum=cache/'jdk.sha256'
        subprocess.run(['curl','-fLsS','--max-time','30',url+'.sha256.txt','-o',str(checksum)],check=True)
        assert hashlib.sha256(p.read_bytes()).hexdigest()==checksum.read_text().split()[0], 'JDK checksum mismatch'
        jdk=pathlib.Path('/workspace/tools/jdk17')
        if not (jdk/'bin/javac').exists():subprocess.run(['tar','-xzf',str(p),'--strip-components=1','-C',str(jdk)],check=True)
    else:
        assert hashlib.sha1(p.read_bytes()).hexdigest()==digest, name+' checksum mismatch'
        expected=sdk/({'platforms':'platforms/android-35/android.jar','build-tools':'build-tools/35.0.0/aapt2','':'platform-tools/adb'}[dest])
        if not expected.exists():
            with zipfile.ZipFile(p) as z:
                for i in z.infolist():
                    target=(sdk/dest/i.filename).resolve()
                    assert target.is_relative_to(sdk.resolve())
                z.extractall(sdk/dest)
                for i in z.infolist():
                    mode=(i.external_attr>>16)&0o777
                    if mode:(sdk/dest/i.filename).chmod(mode)
            if dest=='build-tools':(sdk/'build-tools/android-15').rename(sdk/'build-tools/35.0.0')
    print(name, 'verified')
PY
