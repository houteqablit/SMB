# Validation 4.1.0

Compilation AAPT2 / Java 17 / D8, alignement et signatures v2/v3 vérifiés. VersionName 4.1.0, versionCode 12, minSdk 26, targetSdk 35. Mise à jour de la 3.2.0 avec même certificat testée sur Android 8.

53 contrôles JVM réussis. 93 contrôles Android réussis avec INSTRUMENTATION_CODE: -1 : comportements précédents, réseau déroulant BT par défaut, icônes EA/BT actualisées, UR majuscule, catalogue commun filtré par réseau pour les compteurs hors liste, validation de l’anomalie sans ancien index, retrait d’une sélection devenue incompatible et filtrage consommation du formulaire principal. Réouverture d’un compteur hors liste sauvegardé avec conservation du catalogue et de l’anomalie, UR majuscule persistée en SQLite.

Le constructeur AllCaps avec Locale a été remplacé par le constructeur compatible Android 8 après détection de son incompatibilité lors des tests. Le filtre force les majuscules à la saisie et au collage ; la validation normalise aussi la valeur.

Captures réelles du formulaire principal et des compteurs hors liste EA/BT avec clavier ouvert sur écran 360 × 640. Contrôle géométrique des champs et de la validation du formulaire hors liste par le runner visuel. Protection de capture levée temporairement dans le runner de test seulement ; l’APK conserve FLAG_SECURE. Les captures utilisent uniquement des données fictives.

Correctif compilation 12 : moyenne et taux acceptent les décimales positives longues et la notation scientifique Excel, sans arrondi. Nombres négatifs, hors plage ou de précision excessive refusés. Le fichier utilisateur fourni pour diagnostic reste hors des sources et de la livraison. Les anciens index vides ou non numériques restent à corriger dans les données avant l’import selon le schéma actuel.

Limites : aucun téléphone réel ni caméra/GPS/Drive matériel n’a été testé. Android 15 / API 35 non validé à l’exécution ; tests Android sur API 26 avec émulateur officiel en mode logiciel. Vérifier les grands claviers, grandes polices et autres dimensions sur votre téléphone. Le code provient de la reconstruction 3.1.1 et des spécifications ; sources historiques originales absentes. Signature de développement ; clé privée exclue des sources.
