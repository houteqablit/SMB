# SmartMobility Terrain 4.1.0

Installer SmartMobilityTerrain-4.1.0.apk par-dessus la 3.2.0 actuelle, sans la désinstaller. Même package et même certificat : conserver comptes, relevés, catalogues et photos. Android 8 minimum. La 3.1.1 reste une application distincte.

Menu ⋮ → Nouveau compteur hors liste. Choisir BT (par défaut) ou EA dans la liste déroulante. L’icône éclair rouge ou goutte bleue suit la sélection. Saisir l’UR, automatiquement forcée en majuscules, et le numéro du compteur. Saisir l’index, choisir une anomalie du réseau et prendre la photo obligatoire, puis valider. Le formulaire hors liste propose toutes les anomalies du réseau à partir du catalogue déjà importé, car il ne dispose pas d’ancien index. Le formulaire principal propose les anomalies compatibles avec réseau et consommation pour les compteurs importés. Les compteurs hors liste enregistrés gardent le catalogue de leur réseau et leur anomalie à la réouverture.

Importer d’abord un modèle Excel à trois feuilles Releve, Anomalie, type_local si le catalogue est vide. Les anciens fichiers 3.2.0 restent compatibles. Le modèle de démonstration utilise des données fictives et le compte releveur01 ; créer ce compte ou adapter l’affectation. Les codes DEMO_ sont à remplacer par votre catalogue réel.

Les corrections de la 3.2.0 sont conservées : formulaire compact, tailles 32/28, gras, espacements, confirmation de deux index consécutifs identiques avec message rouge, photos, GPS, sauvegardes, comptes et changement de mot de passe.
