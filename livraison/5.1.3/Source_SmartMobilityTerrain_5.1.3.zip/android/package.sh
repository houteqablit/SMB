#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
./test.sh | tee build-host-results.tmp
./build.sh
mkdir -p ../deliverables
mv build-host-results.tmp ../deliverables/host-test-results.txt
cp build/SmartMobilityTerrain-5.1.3.apk ../deliverables/
cp assets/Modele_SmartMobilityTerrain_5.1.3.xlsx ../deliverables/
cp tests/fixtures/{Releve.csv,Anomalie.csv,type_local.csv} ../deliverables/
python3 - <<'PY'
from pathlib import Path
import hashlib, zipfile
root=Path.cwd();output=root.parent/'deliverables'
with zipfile.ZipFile(output/'Source_SmartMobilityTerrain_5.1.3.zip','w',zipfile.ZIP_DEFLATED) as archive:
    for p in sorted(root.rglob('*')):
        if p.is_file() and 'build' not in p.relative_to(root).parts:
            archive.write(p,'android/'+str(p.relative_to(root)))
artifacts=['SmartMobilityTerrain-5.1.3.apk','Modele_SmartMobilityTerrain_5.1.3.xlsx','Source_SmartMobilityTerrain_5.1.3.zip']
(output/'SHA256SUMS').write_text(''.join(hashlib.sha256((output/n).read_bytes()).hexdigest()+'  '+n+'\n' for n in artifacts))
PY
