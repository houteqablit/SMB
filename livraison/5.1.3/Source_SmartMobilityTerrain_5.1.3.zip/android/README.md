# SMB-Relève 5.1.3 — compilation 19

Guide actuel : drive-service/MISE_A_JOUR_5.1.3.md. Archive privée des validations, actions administrateur ciblées, nouvelle UR, libellé du nouveau type local, ordre du compteur, reprise du premier non visité. Mise à jour compatible de 5.1.2 et sauvegardes antérieures à 42 champs.

# SMB-Relève 5.1.2 — compilation 18

Guide actuel : drive-service/MISE_A_JOUR_5.1.2.md. Options releveurs, identité, noms des déchargements, pagination et libération de caches. Script Drive à redéployer pour le protocole 3.

# SmartMobility Terrain 5.1.1 — compilation 17

Mise à jour de la 5.1.0, même package et signature ; installer sans désinstaller.

Anomalie obligatoire avant photo et validation. Nouveau téléphone confirmé par deux saisies consécutives identiques. Menus Charger mes données / Décharger les relevés. Déchargement limité aux contrats visités (date renseignée), Excel + ZIP de photos par lots, accusés vérifiés et renvois dédupliqués.

Purge révisée : données chargées seulement, comptes/catalogues/options/Drive conservés. Releveur : ses données ; administrateur : toutes les tournées. Suppression d’un compte releveur par action administrateur séparée avec réauthentification et confirmation. Options administrateur communes aux releveurs : Mes sauvegardes, exports manuels et photo obligatoire pour tous les compteurs.

Lire drive-service/MISE_A_JOUR_5.1.1.md : remplacer le script et mettre à jour le déploiement existant avant de décharger les photos. Les clés existantes sont conservées. La configuration locale laisse le champ clé vide à l’affichage et conserve sa valeur enregistrée lors d’une édition sans nouvelle clé.

Tests : ./test.sh ; ./test-upload.sh ; ./build.sh ; ./device-test.sh. Les tests de purge sont désormais isolés dans la suite Android, avec conservation vérifiée des comptes ; l’ancien runner d’effacement complet de la 5.1.0 a été retiré. Les appels Google du service sont simulés localement ; aucun transfert dans le Drive réel n’est revendiqué.

Les sections suivantes décrivent les versions historiques. La 5.1.1 et son guide prévalent, notamment pour la purge et l’envoi de photos.

---

# SmartMobility Terrain 5.1.0

VersionCode 16, même package et certificat que la 4.1.0. Installer par-dessus sans désinstaller. Android 8 minimum. Signature de développement.

## Nouveautés de la 5.1.0

- Menu « Envoyer les relevés vers Drive » : envoi direct d’un Excel en mémoire au service Apps Script, sans fichier XLSX local créé. Relevés du compte connecté, toutes campagnes ; pas de photos dans ce flux.
- Code anomalie conservé et colonne Libelle anomalie ajoutée aux exports Excel/CSV et aux fichiers de relève des archives de sauvegarde. Les données binaires de restauration conservent leur format compatible.
- Service Apps Script prêt à déployer dans le compte propriétaire du Drive. Clé par compte, signature HMAC-SHA256, date, contrôle SHA-256, réception confirmée et déduplication des renvois. Aucun mot de passe Google dans l’APK. Clés chiffrées via Android Keystore ; configuration réservée à l’administrateur.
- Purger la base de données dans le menu principal et Administration : mot de passe + PURGER avant remise à zéro Android de toutes les données de l’application sur le téléphone, tous comptes compris. Ne supprime ni Drive ni exports externes. Après purge, recréer l’administrateur.

## Préparer et tester

Dans android : `./test.sh`, `./test-upload.sh`, `./build.sh`, puis `./device-test.sh` avec un émulateur de recette. JDK 17 et SDK Android 35 / Build Tools 35.0.0. Node.js requis pour les tests du service simulé. Lire drive-service/INSTALLATION_DRIVE.md pour le déploiement réel. L’APK est build/SmartMobilityTerrain-5.1.0.apk. Ne pas inclure de secrets réels dans les sources.

L’envoi réel Google ne peut être validé sans le déploiement du propriétaire du compte. Les tests locaux de Code.gs utilisent des services Google simulés ; ils ne constituent pas un test Drive en production. Excel maximal : 6 Mio. L’horloge du téléphone doit être à l’heure (tolérance dix minutes). Les tournées restent disponibles hors connexion. Les relevés et photos ne sont jamais supprimés automatiquement après envoi ; seule la purge explicite les efface.

Toutes les fonctions de la 4.1.0 sont conservées : import trois feuilles, recherche, formulaire compact, couleurs et tailles, confirmation de deux index consécutifs, hors liste BT/EA, comptes, GPS, sauvegardes et exports manuels. Le modèle conserve les trois feuilles et la compatibilité 3.2.0/4.1.0.

---

Les sections ci-dessous sont l’historique de réalisation de la 4.1.0 ; les nouveautés et versions ci-dessus prévalent.

# SmartMobility Terrain 4.1.0

Version 4.1.0 (versionCode 15), mise à jour de la 3.2.0 avec le même package et la même signature. Installer sans désinstaller pour conserver les données.

Application Android native Java, hors connexion, minSdk 26, compile/target SDK 35. Package indépendant `ma.releve.terrain.v320`, fournisseurs de fichiers indépendants : l’installation ne remplace pas `ma.releve.terrain` 3.1.1 et ne partage pas sa base privée. Aucun compte administrateur ni mot de passe applicatif par défaut. Créer l’administrateur au premier démarrage.

Les sources historiques n’étant pas fournies, ce projet est une reconstruction à partir du DEX de l’APK 3.1.1 et des documents du dossier de transmission. Les erreurs de décompilation identifiées ont été corrigées, puis les modifications 3.2.0 ont été ajoutées. Ce projet ne doit pas être présenté comme le projet source historique retrouvé. La signature est une nouvelle signature de développement, indépendante de la signature 3.1.1.

## Compilation et vérification

Dans `/workspace/SMB/android` :

```sh
./setup-tools.sh
./test.sh
./build.sh
```

Prérequis reproductibles : Temurin JDK 17.0.16+8, Android Platform 35 révision 2 et Build Tools 35.0.0. Les archives sont téléchargées depuis les éditeurs et leurs empreintes vérifiées avant extraction. Aucun Gradle ni bibliothèque Maven n’est requis. `ANDROID_SDK_ROOT` et `SMB_JDK_HOME` permettent d’utiliser une installation existante. Le SDK installé par `setup-tools.sh` réside dans `/workspace/android-sdk`, le JDK dans `/workspace/tools/jdk17`.

L’APK est créé dans `build/SmartMobilityTerrain-4.1.0.apk`. La compilation exécute AAPT2, javac, D8, zipalign, apksigner et vérifie la signature. La clé de développement est créée hors du dépôt dans `/workspace/smb-signing/development.jks` ; `SMB_SIGN_DIR` permet de changer ce dossier. Conserver cette clé pour les mises à jour de cette version. Le mot de passe de développement dans le script n’en fait pas une clé de production. Ne pas publier la clé privée.

Sur un émulateur Android démarré et visible dans `adb devices`, lancer `./device-test.sh`. Les tests SQLite utilisent une base nommée `instrumentation_releve.db` et un sous-dossier de fichiers dédié, distincts des données applicatives. Les tests d’interface ouvrent l’application cible : utiliser un émulateur de recette dédié. Le démarrage sans KVM peut nécessiter plusieurs minutes. Si Android redémarre pendant son initialisation, examiner les journaux système ; le paramètre Android `system_server_watchdog_timeout_ms` peut être augmenté sur cet émulateur de recette uniquement, sans changer l’application.

Le script contrôle explicitement le résultat de l’instrumentation, car `am instrument` peut retourner un statut shell nul après une erreur.

## Correctif après retour utilisateur

VersionName 3.2.0, versionCode 10 : installer le nouvel APK par-dessus la 3.2.0 précédente, sans la désinstaller. Même package et même clé de signature, données conservées.

La confirmation d’import affiche un bouton **Remplacer** à côté d’**Annuler**, ainsi que les actions Sauvegarder / Exporter et Envoyer les relèves. Le message et les actions sont visibles ensemble. Seul Remplacer applique l’import.

Dans le menu principal du releveur et dans Administration, **Modifier mon mot de passe** demande le mot de passe actuel, un nouveau mot de passe d’au moins huit caractères et sa confirmation. L’opération concerne uniquement le compte connecté ; elle conserve le rôle, les affectations et les relevés. Les mots de passe ne sont pas inscrits dans l’audit. Le nouveau mot de passe sera requis à la prochaine connexion.

## Import et catalogues

Importer un `.xlsx` contenant exactement `Releve`, `Anomalie`, `type_local`. Les feuilles supplémentaires sont refusées. Autres possibilités : ZIP contenant exactement `Releve.csv`, `Anomalie.csv`, `type_local.csv`, ou sélection multiple de ces trois CSV depuis Ma tournée / Synchroniser. Un CSV unique est refusé pour la synchronisation complète. Les CSV utilisent UTF-8 avec BOM facultatif et `;`.

Le modèle livré reprend les 18 colonnes historiques. Conserver les identifiants et téléphones comme texte. Les exemples appartiennent à `releveur01` ; créer ce compte et s’y connecter pour importer le modèle de démonstration, ou adapter la colonne `Identifiant releveur` à votre compte. Les dix colonnes obligatoires, dates, index, moyenne/taux, doublons et affectation sont contrôlés. Aucun remplacement ne commence avant validation des trois sources.

Schéma réel du catalogue `Anomalie` : `Code anomalie`, `Libelle anomalie`, `Reseau`, `Cas consommation`, `Photo obligatoire`, `Deuxieme passage`. Les anciens intitulés `Code`, `Libelle`, `Reseaux` sont aussi reconnus. Les champs sont mappés vers `anomalies(code,libelle,reseaux,cas,photo,repassage)`. Réseaux EA/BT ; cas NEGATIF, ZERO, POSITIF, SANS_INDEX, SANS_REFERENCE ; valeurs photo/deuxième passage OUI/NON. Plusieurs réseaux/cas peuvent être séparés par `|`. Les codes DEMO_ sont fictifs et doivent être remplacés par votre catalogue officiel.

`type_local` : `Code type local`, `Libelle type local`, mappés vers `type_local(code,libelle)`. Le formulaire conserve et affiche le type actuel même après retrait du catalogue ; le menu propose les codes et leurs libellés. Les valeurs originales Telephone et Type local restent distinctes de Nouveau telephone et Nouveau type local dans les exports.

Les compteurs du compte connecté et les deux catalogues sont remplacés dans une transaction SQLite. Collision avec un autre compte, catalogue invalide ou révision périmée provoque un rollback. Les compteurs des autres comptes sont conservés ; les catalogues sont communs au téléphone, comme le catalogue historique. L’import administrateur conserve le comportement historique d’ajout sans effacement : il valide les trois sources, ajoute uniquement les contrats absents pour la campagne choisie et remplace les deux catalogues dans la même transaction, sans écraser les saisies existantes. Il conserve les affectations du fichier ; les tournées personnelles restent limitées au compte connecté.

La confirmation propose quatre actions : Sauvegarder / Exporter, Envoyer les relèves, Confirmer le remplacement, Annuler. Sauvegarder crée une archive locale consultable/exportable dans Mes sauvegardes et retourne à la confirmation. Envoyer prépare le partage Android puis retourne à la confirmation. Aucune de ces deux actions ne déclenche le remplacement. Seule Confirmer le remplacement applique la mutation.

## Fonctionnement conservé et modifications

Comptes PBKDF2 salés, profils, noms des releveurs, affectation des contrats non visités, campagnes, catalogue, paramètres de régularité, historique, recherche, filtres, ordre numérique, précédent/suivant et gestes, deuxième passage, compteurs hors liste, sauvegardes/restauration, exports XLSX/CSV/ZIP, sélecteur Android et partage Drive sont présents dans la reconstruction.

Après connexion : liste des compteurs, message vide exact « Pas de compteurs chargés », menu ⋮ en haut à gauche. Identité claire, bleu pétrole et validation verte, distinction EA/BT conservée.

Pour un index anormal, la première valeur est conservée en mémoire et le champ est vidé. Ressaisir la même valeur dans le même champ, puis prendre la photo. Une différence bloque ; une modification après confirmation remet à zéro la confirmation et l’association de la photo. Les icônes photo et consultation sont placées à droite de l’index. Le téléphone se modifie depuis le champ accompagné de l’action ✎. Le type de local utilise le catalogue déroulant.

À chaque validation, acquisition GPS automatique bornée à 20 secondes : X longitude, Y latitude, précision et horodatage. Les positions antérieures au début de l’acquisition sont ignorées. En cas d’indisponibilité, réessayer, annuler ou confirmer explicitement sans GPS. Aucun bouton GPS manuel.

Les sauvegardes ZIP contiennent les 42 champs, les photos référencées, la source si présente et les deux catalogues. La restauration sauvegarde d’abord la tournée courante et restaure les catalogues enregistrés. Les archives historiques dépourvues de catalogues restent lisibles sans modifier les catalogues actuels. Une sauvegarde créée avant le premier import peut contenir un catalogue de types vide.

Le partage Drive ouvre le sélecteur/partage Android ; il ne prouve pas réception et ne modifie pas le statut en « envoyé ». Aucun serveur ni secret cloud n’est nécessaire au fonctionnement local. Les permissions Google restent requises sur le téléphone pour les fichiers privés.

## Recette sur téléphone

Avant déploiement terrain : installer à côté de 3.1.1 sur Android 8+ ; créer administrateur et releveur ; essayer un petit fichier affecté au compte ; vérifier annulation, sauvegarde, partage et confirmation, rollback d’un fichier invalide, export et restauration ; contrôler rendu extérieur, gestes, caméra réelle, GPS réel, refus de permissions, GPS indisponible et partage vers votre compte Drive. Les résultats exécutés sont dans `../deliverables/VALIDATION.md`. Les tests automatisés ne remplacent pas cette recette matérielle.

## Formulaire compact (versionCode 10)

L’écran de saisie utilise une seule page sans conteneur de défilement, avec des lignes réparties dans la hauteur disponible lorsque le clavier est ouvert. Index et icônes photo, anomalie, commentaire, téléphone/type local et validation sont présents ensemble. Les détails longs du client sont consultables en touchant le résumé. La lisibilité dépend de la taille de l’écran, du clavier et de la taille de police configurée.

L’en-tête affiche UR / tournée, nom du compte connecté et relevés enregistrés / total pour les filtres actifs (campagne, UR, tournée, recherche, statut), sans limite d’affichage de 150. Un relevé enregistré est compté lorsque sa date de relève est renseignée, y compris une anomalie sans index. Compteurs EA en bleu et gras, BT en rouge et gras. L’ancien index et la date de l’ancienne relève figurent sur une seule ligne.

Les libellés explicatifs de l’index et de calcul, le nom de photo, les coordonnées GPS, la case de deuxième passage et les boutons Précédent / Suivant sont masqués. GPS, photos et deuxième passage automatique selon l’anomalie restent fonctionnels ; les gestes de navigation sont conservés. L’ordre de parcours utilise la colonne Ordre de releve numériquement, puis l’identifiant local pour départager les égalités ; les ordres absents sont placés à la fin.

Confirmation d’index anormal : chaque tentative différente devient la dernière tentative en mémoire. Seules deux tentatives consécutives égales confirment l’index, par exemple 1250 → 1205 → 1250 → 1255 → 1255. Le clavier reste affiché lors des reprises. La touche de confirmation du clavier soumet la tentative ; après confirmation, la photo obligatoire est demandée. L’anomalie compatible, le commentaire obligatoire pour une consommation négative et les autres contrôles restent requis avant enregistrement.

Pour une capture de recette seule sur l’émulateur dédié, après les tests complets : `./device-test.sh VisualTests`. Ce runner réutilise exclusivement la base `instrumentation_releve.db`, ouvre le clavier numérique et écrit `visual-test.png` dans les fichiers de test de l’application. Il ne crée pas de compte dans la base applicative. La protection de capture est levée temporairement dans l’activité de test ; l’APK conserve FLAG_SECURE.

## Lisibilité et avertissement de ressaisie (compilation 10)

Les champs de saisie, les listes et le bouton de validation sont en gras, taille 14. Le numéro du compteur est en gras, taille 32, bleu pour EA et rouge pour BT ; l’index saisi est en taille 28. La ligne de l’ancien index est suivie de la date précédente pour conserver l’affichage compact.

Une tentative d’index anormal non confirmée ouvre une boîte de dialogue intitulée Confirmation de l’index. Le texte d’obligation de ressaisie est rouge et gras. Le bouton Ressaisir redonne le focus au champ et réaffiche le clavier. Chaque valeur différente devient la référence suivante ; deux saisies consécutives identiques restent requises.

## Espacements, réseaux et tailles doublées (compilation 10)

Espacement de 4 dp entre les lignes du formulaire et entre les boutons photo. Goutte bleue pour EA ou éclair rouge pour BT au-dessus du bouton appareil photo. Le numéro du compteur seul est en taille 32 (double de 16) ; l’index saisi est en taille 28 (double de 14). Les autres champs restent en gras, taille 14. Les trois lignes de résumé sont réparties dans la hauteur disponible pour conserver les contrôles avec le clavier ouvert.

## Compteur hors liste — 4.1.0

Liste déroulante réseau BT / EA, BT sélectionné par défaut. L’icône éclair rouge ou goutte bleue et la couleur du compteur suivent le réseau. L’UR est forcée en majuscules lors de la frappe, du collage et de la validation. Le numéro du compteur et l’en-tête UR sont actualisés pendant la saisie.

Le formulaire hors liste utilise le catalogue d’anomalies importé commun et propose toutes les anomalies du réseau sélectionné, sans filtrage par cas de consommation puisque l’ancien index n’est pas connu. Changer de réseau enlève une sélection incompatible. Les compteurs importés du formulaire principal filtrent par réseau et cas de consommation ; un compteur hors liste enregistré conserve le catalogue de son réseau et son anomalie à la réouverture. Une anomalie, l’UR, le numéro et la photo restent requis pour un compteur hors liste. Les exigences de deuxième passage et de photo du catalogue restent appliquées. Le modèle 4.1.0 contient les mêmes trois feuilles et reste compatible avec les fichiers 3.2.0.

## Correctif import Excel — compilation 12

Moyenne journalière et taux de variation acceptent les valeurs décimales positives ou nulles et la notation scientifique Excel, y compris les décimales de précision de ses cellules numériques. Les valeurs négatives, nombres hors plage et nombres excessivement longs restent refusés. Aucun arrondi n’est appliqué : la valeur du classeur est conservée.

Les colonnes supprimées dans un fichier communiqué à des fins de confidentialité ne sont pas réintroduites dans ce fichier. Le fichier réellement importé conserve les colonnes obligatoires du schéma existant. Les données utilisateurs de diagnostic ne font pas partie des sources ou de la livraison publique.

## Normalisation demandée des nombres — compilation 13

À l’import seulement, Ancien index, Moyenne journaliere et Taux variation sont arrondis à deux décimales (HALF_UP). Valeurs vides, négatives, non numériques ou hors plage deviennent zéro. Les valeurs de la tournée courante ne sont modifiées que lors d’un import confirmé selon le flux existant. Les identifiants, numéros de compteur, téléphones, dates et ordre de relève ne sont pas traités par cette règle de nombres de consommation. Une date Excel comportant une fraction d’heure est reconnue en conservant son jour calendaire.

Attention : un ancien index remplacé par zéro sert de base au calcul de consommation. Le fichier privé reçu pour diagnostic et ses copies locales de validation sont exclus de la livraison publique.

## Identifiant et jours — compilation 14

Identifiant en gras taille 28 entre adresse et compteur. Nombre de jours depuis l’ancienne date, en gras taille 40 : 29–31 vert, 28 et 32 orange, moins de 28 ou plus de 32 rouge.

## Recherche — compilation 15

Champ et bouton depuis la liste des compteurs, action Rechercher un compteur depuis le menu principal. Recherche dans les campagnes du compte connecté, indépendante des filtres de tournée. Liste des correspondances avec numéro, réseau, identifiant et adresse. Aucun résultat : Annuler conserve l’écran, Nouveau compteur hors liste ouvre le formulaire après confirmation si une saisie est non enregistrée.
