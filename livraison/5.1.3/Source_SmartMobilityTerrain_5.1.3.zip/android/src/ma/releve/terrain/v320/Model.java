package ma.releve.terrain.v320;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.ResolverStyle;
import java.time.temporal.ChronoUnit;
import java.util.Arrays;
import java.util.Locale;
import java.util.UUID;

public final class Model {
    public static final int ACC = 37;
    public static final int ACTOR = 40;
    public static final int ACTORNAME = 41;
    public static final int ADR = 2;
    public static final int ANO = 8;
    public static final int C = 0;
    public static final int CAMPAIGN = 36;
    public static final int CMJ = 26;
    public static final int COMM = 9;
    public static final int CONF = 33;
    public static final int CONS = 24;
    public static final int DATE = 10;
    public static final int DAYS = 25;
    public static final int EPOCH = 32;
    public static final int IDENT = 21;
    public static final int ISO = 35;
    public static final int LOCAL = 13;
    public static final int MEAN = 19;
    public static final int N = 1;
    public static final int NET = 14;
    public static final int NEW = 7;
    public static final int NEWLOCAL = 39;
    public static final int NEWTEL = 38;
    public static final int NEWUR = 42;
    public static final int NEWLOCAL_LABEL = 43;
    public static final int OLD = 6;
    public static final int ORDER = 22;
    public static final int PHOTO = 27;
    public static final int PREV = 17;
    public static final int PROD = 16;
    public static final int READER = 23;
    public static final int SER = 4;
    public static final int STATE = 28;
    public static final int STATUS = 18;
    public static final int SYNC = 29;
    public static final int TEL = 5;
    public static final int THRESH = 20;
    public static final int TOUR = 15;
    public static final int UR = 3;
    public static final int UUID_ = 30;
    public static final int VER = 31;
    public static final int VISIT = 34;
    public static final int X = 11;
    public static final int Y = 12;
    public static final String[] FIELDS = {"contrat", "nom", "adresse", "ur", "serie", "telephone", "ancien", "nouveau", "anomalie", "commentaire", "date", "x", "y", "local", "reseau", "tournee", "produit", "date_ancienne", "statut_photo", "moyenne", "variation", "identifiant", "ordre", "releveur", "consommation", "jours", "cmj", "photo", "etat", "sync", "uuid", "version", "epoch", "confirmation", "passage", "date_iso", "campagne", "precision_gps", "nouveau_telephone", "nouveau_type_local", "releveur_effectif", "nom_releveur_effectif", "nouvelle_unite_releve", "libelle_nouveau_type_local"};
    public static final String[] LABELS = {"Contrat", "Nom", "Adresse", "UR", "Numero compteur", "Telephone", "Ancien index", "Nouvel index", "Code anomalie", "Commentaire", "Date et heure de releve", "GPS X (longitude)", "GPS Y (latitude)", "Type local", "Reseau", "Tournee", "Produit", "Date ancienne releve", "Statut photo", "Moyenne journaliere", "Taux variation", "Identifiant", "Ordre de releve", "Identifiant releveur", "Consommation", "Nombre jours", "Consommation journaliere", "Photo compteur", "Statut releve", "Statut synchronisation", "UUID releve", "Version", "Horodatage systeme", "Index confirme", "Passage", "Date ISO", "Campagne", "Precision GPS (m)", "Nouveau telephone", "Nouveau type local", "Identifiant releveur effectif", "Nom du releveur", "Nouvelle unite de releve", "Libelle du nouveau type local"};
    public static final int[] IMPORT = {14, 0, 1, 2, 3, 15, 4, 16, 6, 17, 5, 13, 18, 19, 20, 21, 22, 23};

    public static final class Result {
        public boolean abnormal;
        public BigDecimal cmj;
        public BigDecimal cons;
        public long days;
        public boolean photo;
        public String cas = "SANS_INDEX";
        public String error = "";
        public String reason = "";
    }

    public static String[] headers() {
        int length = IMPORT.length;
        String[] strArr = new String[length];
        for (int i = 0; i < length; i++) {
            strArr[i] = LABELS[IMPORT[i]];
        }
        return strArr;
    }

    public static String[] blank() {
        String[] strArr = new String[FIELDS.length];
        Arrays.fill(strArr, "");
        strArr[30] = UUID.randomUUID().toString();
        strArr[31] = "0";
        strArr[28] = "A_RELEVER";
        strArr[29] = "NON_ENVOYE";
        strArr[18] = "NON";
        strArr[34] = "1";
        return strArr;
    }

    public static BigDecimal num(String str) {
        return new BigDecimal(str.trim().replace(',', '.'));
    }

    public static String decimal(BigDecimal bigDecimal) {
        return Model$$ExternalSyntheticBackportWithForwarding0.m(bigDecimal).toPlainString();
    }

    public static boolean numeric(String str) {
        return str != null && str.trim().matches("[0-9]+([.,][0-9]{1,3})?");
    }

    public static LocalDate date(String str) {
        String strTrim = str.trim();
        if (strTrim.matches("[0-9]{5}([.,][0-9]{1,17})?")) {
            return LocalDate.of(1899, 12, 30).plusDays(num(strTrim).setScale(0,java.math.RoundingMode.DOWN).longValueExact());
        }
        if (strTrim.length() >= 10) {
            strTrim = strTrim.substring(0, 10);
        }
        try {
            return LocalDate.parse(strTrim, DateTimeFormatter.ofPattern("dd/MM/uuuu").withResolverStyle(ResolverStyle.STRICT));
        } catch (Exception e) {
            return LocalDate.parse(strTrim, DateTimeFormatter.ISO_LOCAL_DATE);
        }
    }

        public static Result assess(String[] strArr, String str, LocalDate localDate) {
        boolean z = true;
        Result result = new Result();
        String strTrim = str.trim();
        if (!strArr[18].equalsIgnoreCase("OUI")) {
            z = strArr[0].isEmpty();
        }
        result.photo = z;
        if (!strArr[17].isEmpty()) {
            try {
                result.days = ChronoUnit.DAYS.between(date(strArr[17]), localDate);
                if (result.days < 0) {
                    result.error = "La date système précède l’ancienne relève.";
                    return result;
                }
            } catch (Exception e) {
                result.error = "Date ancienne relève invalide.";
                return result;
            }
        }
        if (strTrim.isEmpty()) {
            return result;
        }
        if (!numeric(strTrim)) {
            result.error = "Index numérique attendu (3 décimales maximum). Effacez le champ pour une anomalie sans index.";
            return result;
        }
        if (strArr[6].isEmpty()) {
            result.cas = "SANS_REFERENCE";
            result.photo = true;
            return result;
        }
        if (!numeric(strArr[6])) {
            result.error = "Ancien index invalide.";
            return result;
        }
        result.cons = num(strTrim).subtract(num(strArr[6]));
        result.cas = result.cons.signum() < 0 ? "NEGATIF" : result.cons.signum() == 0 ? "ZERO" : "POSITIF";
        if (result.cons.signum() < 0) {
            result.abnormal = true;
            result.photo = true;
            result.reason = "Index inférieur à l’ancien index.";
        }
        if (!strArr[17].isEmpty() && result.days == 0) {
            result.error = "La nouvelle relève doit être postérieure à l’ancienne relève.";
            return result;
        }
        if (result.days > 0) {
            result.cmj = result.cons.divide(BigDecimal.valueOf(result.days), 8, RoundingMode.HALF_UP);
            if (result.cons.signum() >= 0 && !strArr[19].isEmpty() && !strArr[20].isEmpty()) {
                BigDecimal bigDecimalNum = num(strArr[19]);
                BigDecimal bigDecimalDivide = num(strArr[20]).divide(new BigDecimal("100"), 8, RoundingMode.HALF_UP);
                BigDecimal bigDecimalMultiply = bigDecimalNum.multiply(BigDecimal.ONE.subtract(bigDecimalDivide));
                BigDecimal bigDecimalMultiply2 = bigDecimalNum.multiply(BigDecimal.ONE.add(bigDecimalDivide));
                if (result.cons.compareTo(bigDecimalMultiply.multiply(BigDecimal.valueOf(result.days))) < 0 || result.cons.compareTo(bigDecimalMultiply2.multiply(BigDecimal.valueOf(result.days))) > 0) {
                    result.abnormal = true;
                    result.photo = true;
                    result.reason = (result.cons.compareTo(bigDecimalMultiply2.multiply(BigDecimal.valueOf(result.days))) > 0 ? "Hausse" : "Baisse") + " de consommation journalière hors seuil.";
                }
            }
        }
        return result;
    }

    public static boolean contains(String str, String str2) {
        for (String str3 : str.toUpperCase(Locale.ROOT).split("[|,; ]+")) {
            if (str3.equals(str2)) {
                return true;
            }
        }
        return false;
    }
}
