package ma.releve.terrain.v320;
import java.text.Normalizer;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;
final class ExportName {
 static String base(String displayName,boolean admin,long time){
  String name=Normalizer.normalize(displayName,Normalizer.Form.NFD).replaceAll("\\p{M}","").replaceAll("[^A-Za-z0-9_-]+","_").replaceAll("^_+|_+$","");
  if(name.isEmpty())name="Sans_nom";
  if(name.length()>80)name=name.substring(0,80);
  SimpleDateFormat date=new SimpleDateFormat("ddMMyyyy_HHmmss_SSS",Locale.ROOT);date.setTimeZone(TimeZone.getTimeZone("Africa/Casablanca"));
  return (admin?"Administrateur_":"Releveur_")+name+"_"+date.format(new Date(time));
 }
}
