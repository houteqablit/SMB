// Tests locaux avec services Google simulés ; aucun appel à un compte réel.
const fs=require('fs'),vm=require('vm'),crypto=require('crypto'),assert=require('assert');
const files=new Map();let reads=0,creates=0,locks=0,checks=0;
const token='ONLY_TEST_KEY_012345678901234567890123456789';
const digest=b=>crypto.createHash('sha256').update(b).digest('hex');
const context={Date,JSON,Number,Error,Utilities:{Charset:{UTF_8:'utf8'},DigestAlgorithm:{SHA_256:'sha256'},
 computeHmacSha256Signature:(text,key)=>[...crypto.createHmac('sha256',key).update(text).digest()],
 computeDigest:(_,value)=>[...crypto.createHash('sha256').update(Array.isArray(value)?Buffer.from(value):value).digest()],
 base64Decode:text=>[...Buffer.from(text,'base64')],newBlob:(bytes,mime,name)=>({bytes,name,mime})},
 PropertiesService:{getScriptProperties:()=>({getProperty:name=>name==='TOKEN_releveur01'?token:name==='FOLDER_ID'?'PRIVATE_FOLDER':null})},
 DriveApp:{getFolderById:id=>{reads++;assert.equal(id,'PRIVATE_FOLDER');return {
 getFilesByName:name=>({hasNext:()=>files.has(name),next:()=>files.get(name)}),
 createFile:blob=>{creates++;const file={getId:()=>String(creates),getName:()=>blob.name,setDescription:()=>{},getBlob:()=>({getBytes:()=>blob.bytes})};files.set(blob.name,file);return file;}
 };}},LockService:{getScriptLock:()=>({waitLock:()=>locks++,releaseLock:()=>locks--})},
 ContentService:{MimeType:{JSON:'json'},createTextOutput:text=>({setMimeType:()=>JSON.parse(text)})}};
vm.createContext(context);vm.runInContext(fs.readFileSync(__dirname+'/Code.gs','utf8'),context);
function payload(data=Buffer.from('PK\x03\x04only-test'),owner='releveur01'){
 const p={owner,sha256:digest(data),time:Math.floor(Date.now()/1000),data:data.toString('base64')};p.id=digest(owner+'\n'+p.sha256);return sign(p);
}
function sign(p){p.signature=crypto.createHmac('sha256',token).update(p.owner+'\n'+p.sha256+'\n'+p.id+'\n'+p.time).digest('hex');return p;}
function send(p){return context.doPost({postData:{contents:JSON.stringify(p)}});}
function check(v){checks++;assert.ok(v);}
let p=payload();let ack=send(p);check(ack.ok&&ack.sha256===p.sha256&&ack.id===p.id&&creates===1);
check(send(p).ok&&creates===1&&locks===0);
p=payload();p.signature='0'.repeat(64);let prior=reads;check(!send(p).ok&&reads===prior);
p=payload();p.time-=3600;sign(p);check(!send(p).ok);
p=payload();p.data=Buffer.from('PKTAMPER').toString('base64');check(!send(p).ok);
p=payload(Buffer.from('PKdata'),'unknown');check(!send(p).ok);
p=payload();p.id='0'.repeat(64);sign(p);check(!send(p).ok);
check(!context.doPost({postData:{contents:'broken-json'}}).ok);
p=payload(Buffer.from('not-excel'));check(!send(p).ok);
p=payload();p.data='X'.repeat(8388609);check(!send(p).ok);
p=payload(Buffer.from('PKsecond-data'));check(send(p).ok&&creates===2);
check(locks===0);
check(context.doGet().service==='SmartMobilityTerrain'&&context.doGet().version==='5.1.0');
console.log('PASS '+checks+' Apps Script service checks (Google mocks)');
