package ma.releve.terrain.v320;
import android.app.*;
import android.content.*;
import android.os.*;
import java.io.*;
/** Exclusivement sur émulateur de recette : efface réellement toutes les données de l'application. */
public class PurgeTests extends Instrumentation {
 public void onCreate(Bundle b){super.onCreate(b);start();}
 public void onStart(){try{
  MainActivity activity=(MainActivity)startActivitySync(new Intent(getTargetContext(),MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
  String owner="purge_demo_"+System.currentTimeMillis();
  activity.db.user(owner,"OnlyTest123!","RELEVEUR","Purge Demo","test");
  File photos=new File(activity.getFilesDir(),"photos");photos.mkdirs();
  try(FileOutputStream out=new FileOutputStream(new File(photos,"purge-marker.jpg"))){out.write(1);}
  File exports=new File(activity.getFilesDir(),"exports");exports.mkdirs();
  try(FileOutputStream out=new FileOutputStream(new File(exports,"purge-marker.zip"))){out.write(1);}
  activity.getSharedPreferences("purge-marker",0).edit().putBoolean("present",true).commit();
  runOnMainSync(()->{activity.user=owner;activity.admin=false;activity.purgeScreen();activity.purgePassword.setText("OnlyTest123!");activity.purgeWord.setText("PURGER");});
  Bundle status=new Bundle();status.putString("stream","PURGE_TEST_ARMED: emulator-only app data reset\n");sendStatus(1,status);
  runOnMainSync(()->activity.purgeDialog.getButton(AlertDialog.BUTTON_POSITIVE).performClick());
  // Android ferme le processus pendant la remise à zéro : le contrôleur vérifie les fichiers supprimés.
  SystemClock.sleep(3000);throw new AssertionError("Purge n’a pas fermé le processus");
 }catch(Throwable error){Bundle out=new Bundle();out.putString("stream",error.toString());finish(Activity.RESULT_CANCELED,out);}}
}
