package ma.releve.terrain.v320;
import java.nio.charset.StandardCharsets;
public class UploadProtocolTests {
 static int count;
 static void check(boolean condition){count++;if(!condition)throw new AssertionError("Upload protocol check "+count);}
 static void rejects(String url){try{UploadProtocol.endpoint(url);throw new AssertionError("URL accepted");}catch(IllegalArgumentException expected){count++;}}
 public static void main(String[] args)throws Exception{
  check(UploadProtocol.endpoint("https://script.google.com/macros/s/ABC_123/exec").endsWith("/exec"));
  rejects("http://script.google.com/macros/s/ABC/exec");rejects("https://evil.test/macros/s/ABC/exec");rejects("https://script.google.com.evil.test/macros/s/ABC/exec");rejects("https://script.google.com/macros/s/ABC/dev");rejects("https://script.google.com/macros/s/ABC/exec?secret=x");rejects("https://user@script.google.com/macros/s/ABC/exec");
  check(UploadProtocol.sha("abc".getBytes(StandardCharsets.UTF_8)).equals("ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad"));
  check(UploadProtocol.signature("key","The quick brown fox jumps over the lazy dog").equals("f7bc83f430538424b13298e6aa6fb143ef4d59a14946175997479dbc2d1a3cd8"));
  check(!UploadProtocol.signature("key","a").equals(UploadProtocol.signature("key","b")));
  try{UploadProtocol.canonical("bad\nreader","","",0);throw new AssertionError();}catch(IllegalArgumentException expected){count++;}
  System.out.println("PASS "+count+" upload protocol checks");
 }
}
