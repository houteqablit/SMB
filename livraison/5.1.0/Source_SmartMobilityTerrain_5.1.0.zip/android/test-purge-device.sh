#!/bin/bash
# DESTRUCTIF, UNIQUEMENT SUR ÉMULATEUR : toutes les données de cette application sont effacées.
set -euo pipefail
cd "$(dirname "$0")"
ADB=${ANDROID_SDK_ROOT:-/workspace/android-sdk}/platform-tools/adb
export ANDROID_SERIAL=${1:-emulator-5554}
if [[ "$ANDROID_SERIAL" != emulator-* ]] || [[ $("$ADB" shell getprop ro.kernel.qemu | tr -d '\r') != 1 ]]; then
 echo 'REFUS : test de purge réservé à un émulateur Android de recette.' >&2
 exit 2
fi
"$ADB" root >/dev/null
"$ADB" wait-for-device
cp build/device-test-results.txt build/full-tests-before-purge.txt
set +e
./device-test.sh PurgeTests > build/purge-device-results.txt 2>&1
status=$?
set -e
cp build/full-tests-before-purge.txt build/device-test-results.txt
if [[ $status == 0 ]]; then echo 'Échec : processus non arrêté par Android.' >&2; exit 1; fi
rg -q 'PURGE_TEST_ARMED' build/purge-device-results.txt
"$ADB" wait-for-device
"$ADB" shell 'test ! -e /data/user/0/ma.releve.terrain.v320/files/photos/purge-marker.jpg'
"$ADB" shell 'test ! -e /data/user/0/ma.releve.terrain.v320/files/exports/purge-marker.zip'
"$ADB" shell 'test ! -e /data/user/0/ma.releve.terrain.v320/shared_prefs/purge-marker.xml'
"$ADB" shell 'test ! -e /data/user/0/ma.releve.terrain.v320/databases/releve.db'
"$ADB" shell pm path ma.releve.terrain.v320 | rg -q '^package:'
echo 'PASS purge Android réelle sur émulateur : base, photos, sauvegardes et préférences supprimées ; APK conservé.' | tee -a build/purge-device-results.txt
