#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
export PATH="${SMB_JDK_HOME:-/workspace/tools/jdk17}/bin:$PATH"
SDK=${ANDROID_SDK_ROOT:-/workspace/android-sdk}
TOOLS="$SDK/build-tools/35.0.0"
JAR="$SDK/platforms/android-35/android.jar"
mkdir -p build/gen build/classes build/dex
"$TOOLS/aapt2" compile --dir res -o build/resources.zip
"$TOOLS/aapt2" link -o build/base.apk -I "$JAR" --manifest AndroidManifest.xml --java build/gen -A assets build/resources.zip
find src build/gen -name '*.java' > build/sources.txt
javac --release 17 -encoding UTF-8 -cp "$JAR" -d build/classes @build/sources.txt
find build/classes -name '*.class' > build/classes.txt
"$TOOLS/d8" --lib "$JAR" --min-api 26 --output build/dex @build/classes.txt
cp build/base.apk build/unsigned.apk
(cd build/dex && zip -q ../unsigned.apk classes*.dex)
"$TOOLS/zipalign" -f 4 build/unsigned.apk build/aligned.apk
SIGN_DIR=${SMB_SIGN_DIR:-/workspace/smb-signing}
mkdir -p "$SIGN_DIR"
if [ ! -f "$SIGN_DIR/development.jks" ]; then
 keytool -genkeypair -keystore "$SIGN_DIR/development.jks" -alias smb320 -keyalg RSA -keysize 3072 -validity 3650 -dname 'CN=SmartMobility Development' -storepass changeit -keypass changeit
 chmod 600 "$SIGN_DIR/development.jks"
fi
"$TOOLS/apksigner" sign --ks "$SIGN_DIR/development.jks" --ks-pass pass:changeit --out build/SmartMobilityTerrain-5.1.0.apk build/aligned.apk
"$TOOLS/apksigner" verify --verbose build/SmartMobilityTerrain-5.1.0.apk

"$TOOLS/zipalign" -c 4 build/SmartMobilityTerrain-5.1.0.apk
