package ma.releve.terrain.v320;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;

public final class DirectDrive {
    public static final long LIMIT = 20971520;

    interface Fetcher {
        byte[] get(URI uri) throws Exception;
    }

    public static String query(URI uri, String str) throws IOException {
        String rawQuery = uri.getRawQuery();
        if (rawQuery != null) {
            for (String str2 : rawQuery.split("&")) {
                String[] strArrSplit = str2.split("=", 2);
                if (URLDecoder.decode(strArrSplit[0], "UTF-8").equals(str)) {
                    return strArrSplit.length < 2 ? "" : URLDecoder.decode(strArrSplit[1], "UTF-8");
                }
            }
        }
        return "";
    }

    static List<String> urls(String str) throws Exception {
        String strQuery = "";
        if (str == null) {
            throw new IOException("Lien vide.");
        }
        try {
            URI uri = new URI(str.replace("\\&", "&").replace("\u200b", "").replace("\ufeff", "").replace("\u200e", "").replace("\u200f", "").replace((char) 160, ' ').trim());
            String lowerCase = uri.getHost() == null ? "" : uri.getHost().toLowerCase(Locale.ROOT);
            if (!"https".equalsIgnoreCase(uri.getScheme()) || uri.getUserInfo() != null || uri.getPort() != -1 || !Arrays.asList("drive.google.com", "www.drive.google.com", "drive.usercontent.google.com", "docs.google.com").contains(lowerCase)) {
                throw new IOException("Lien HTTPS Drive ou Google Sheets attendu (drive.google.com ou docs.google.com/spreadsheets). Pour un fichier privé, utilisez Importer le fichier depuis votre téléphone.");
            }
            String path = uri.getPath();
            if (path == null) {
                path = "";
            }
            if (path.contains("/folders/")) {
                throw new IOException("Lien d’un fichier XLSX/CSV attendu, pas celui d’un dossier.");
            }
            String[] strArrSplit = path.split("/");
            boolean zEquals = false;
            int i = 0;
            while (i < strArrSplit.length - 2) {
                int i2 = i + 1;
                if (strArrSplit[i2].equals("d") && ((lowerCase.equals("docs.google.com") && strArrSplit[i].equals("spreadsheets")) || (!lowerCase.equals("docs.google.com") && strArrSplit[i].equals("file")))) {
                    strQuery = strArrSplit[i + 2];
                    zEquals = lowerCase.equals("docs.google.com");
                    break;
                }
                i = i2;
            }
            if (strQuery.isEmpty() && !lowerCase.equals("docs.google.com") && (path.equals("/open") || path.equals("/uc") || path.equals("/download"))) {
                strQuery = query(uri, "id");
            }
            if (!strQuery.matches("[A-Za-z0-9_-]{10,200}")) {
                throw new IOException("Lien de fichier invalide. Utilisez Partager → Copier le lien du fichier.");
            }
            String strQuery2 = query(uri, "resourcekey");
            if (!strQuery2.isEmpty() && !strQuery2.matches("[A-Za-z0-9_-]{1,300}")) {
                throw new IOException("Clé du lien invalide.");
            }
            String str2 = strQuery2.isEmpty() ? "" : "&resourcekey=" + URLEncoder.encode(strQuery2, "UTF-8");
            String str3 = "https://drive.google.com/uc?export=download&id=" + strQuery + str2;
            if (!zEquals) {
                return Collections.singletonList(str3);
            }
            String str4 = "https://docs.google.com/spreadsheets/d/" + strQuery + "/export?format=xlsx" + str2;
            return "true".equalsIgnoreCase(query(uri, "rtpof")) ? Arrays.asList(str3, str4) : Arrays.asList(str4, str3);
        } catch (URISyntaxException e) {
            throw new IOException("Lien incomplet : recopiez uniquement l’adresse HTTPS du fichier.");
        }
    }

    public static String url(String str) throws Exception {
        return urls(str).get(0);
    }

    static byte[] download(String str, Fetcher fetcher) throws Exception {
        Iterator<String> it = urls(str).iterator();
        Exception e = null;
        while (it.hasNext()) {
            try {
                byte[] bArr = fetcher.get(URI.create(it.next()));
                checkContent(bArr);
                return bArr;
            } catch (Exception e2) {
                e = e2;
            }
        }
        throw new IOException("Téléchargement refusé ou fichier indisponible. " + (e == null ? "" : e.getMessage()) + " Utilisez Importer le fichier depuis votre téléphone.");
    }

    public static byte[] download(String str) throws Exception {
        return download(str, new Fetcher() { // from class: ma.releve.terrain.v320.DirectDrive$$ExternalSyntheticLambda0
            @Override // ma.releve.terrain.v320.DirectDrive.Fetcher
            public final byte[] get(URI uri) throws Exception {
                return DirectDrive.fetch(uri);
            }
        });
    }

    static boolean allowed(URI uri) {
        String host = uri.getHost();
        return "https".equalsIgnoreCase(uri.getScheme()) && uri.getUserInfo() == null && uri.getPort() == -1 && host != null && (host.equals("drive.google.com") || host.equals("drive.usercontent.google.com") || host.equals("docs.google.com") || host.endsWith(".googleusercontent.com"));
    }

    static byte[] fetch(URI uri) throws Exception {
        for (int i = 0; i < 6; i++) {
            if (!allowed(uri)) {
                throw new IOException("Téléchargement privé ou redirection non autorisée. Importez le fichier depuis votre téléphone ou sélectionnez Drive dans le sélecteur.");
            }
            HttpURLConnection httpURLConnection = (HttpURLConnection) uri.toURL().openConnection();
            httpURLConnection.setInstanceFollowRedirects(false);
            httpURLConnection.setConnectTimeout(15000);
            httpURLConnection.setReadTimeout(30000);
            httpURLConnection.setRequestProperty("User-Agent", "SmartMobilityTerrain/5.1.0");
            try {
                int responseCode = httpURLConnection.getResponseCode();
                if (responseCode < 300 || responseCode >= 400) {
                    if (responseCode != 200) {
                        throw new IOException("Drive refuse le téléchargement (HTTP " + responseCode + "). Importez le fichier depuis votre téléphone ou sélectionnez Drive dans le sélecteur.");
                    }
                    String contentType = httpURLConnection.getContentType();
                    if (contentType != null && contentType.toLowerCase(Locale.ROOT).contains("text/html")) {
                        throw new IOException("Drive demande une connexion, une confirmation ou bloque le téléchargement. Utilisez Importer le fichier depuis votre téléphone.");
                    }
                    if (httpURLConnection.getContentLengthLong() > LIMIT) {
                        throw new IOException("Fichier de plus de 20 Mo.");
                    }
                    InputStream inputStream = httpURLConnection.getInputStream();
                    try {
                        byte[] bArrLimited = TableFile.limited(inputStream, LIMIT);
                        if (inputStream != null) {
                            inputStream.close();
                        }
                        checkContent(bArrLimited);
                        return bArrLimited;
                    } finally {
                    }
                }
                String headerField = httpURLConnection.getHeaderField("Location");
                if (headerField == null) {
                    throw new IOException("Redirection Drive sans destination.");
                }
                uri = uri.resolve(headerField);
                httpURLConnection.disconnect();
            } finally {
                httpURLConnection.disconnect();
            }
        }
        throw new IOException("Trop de redirections Drive. Importez le fichier depuis votre téléphone.");
    }

    public static void checkContent(byte[] bArr) throws IOException {
        if (bArr.length == 0) {
            throw new IOException("Fichier téléchargé vide.");
        }
        if (bArr.length >= 2 && bArr[0] == 80 && bArr[1] == 75) {
            return;
        }
        String lowerCase = new String(bArr, 0, Math.min(bArr.length, 4096), StandardCharsets.UTF_8).trim().toLowerCase(Locale.ROOT);
        if (lowerCase.startsWith("<!doctype html") || lowerCase.startsWith("<html") || lowerCase.contains("<html") || lowerCase.startsWith("<?xml")) {
            throw new IOException("Le lien a renvoyé une page Web, pas un fichier XLSX/CSV. Importez le fichier depuis votre téléphone.");
        }
    }
}
