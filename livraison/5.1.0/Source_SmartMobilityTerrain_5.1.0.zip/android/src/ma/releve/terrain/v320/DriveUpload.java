package ma.releve.terrain.v320;
import android.content.Context;
import android.content.SharedPreferences;
import android.security.keystore.*;
import android.util.Base64;
import java.io.*;
import java.net.*;
import java.security.KeyStore;
import java.nio.charset.StandardCharsets;
import javax.crypto.*;
import javax.crypto.spec.GCMParameterSpec;
import org.json.JSONObject;
final class DriveUpload {
 static final String ALIAS="smb_drive_510";
 static SecretKey key()throws Exception{
  KeyStore store=KeyStore.getInstance("AndroidKeyStore");store.load(null);
  if(store.containsAlias(ALIAS))return (SecretKey)store.getKey(ALIAS,null);
  KeyGenerator gen=KeyGenerator.getInstance("AES","AndroidKeyStore");
  gen.init(new KeyGenParameterSpec.Builder(ALIAS,KeyProperties.PURPOSE_ENCRYPT|KeyProperties.PURPOSE_DECRYPT).setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build());return gen.generateKey();
 }
 static SharedPreferences prefs(Context ctx){return ctx.getSharedPreferences("drive_upload",0);}
 static void configure(Context ctx,String url,String owner,String secret)throws Exception{
  url=UploadProtocol.endpoint(url);UploadProtocol.canonical(owner,"","",0);
  if(secret.length()<32||secret.length()>256)throw new IllegalArgumentException("Clé de transfert : 32 à 256 caractères.");
  Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding");cipher.init(Cipher.ENCRYPT_MODE,key());
  String value=Base64.encodeToString(cipher.getIV(),Base64.NO_WRAP)+":"+Base64.encodeToString(cipher.doFinal(secret.getBytes(StandardCharsets.UTF_8)),Base64.NO_WRAP);
  if(!prefs(ctx).edit().putString("endpoint",url).putString("key_"+owner,value).commit())throw new IOException("Configuration non enregistrée.");
 }
 static String secret(Context ctx,String owner)throws Exception{
  String value=prefs(ctx).getString("key_"+owner,"");if(value.isEmpty())throw new IOException("Envoi Drive non configuré pour ce compte. Contactez l’administrateur.");
  String[] parts=value.split(":");Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding");cipher.init(Cipher.DECRYPT_MODE,key(),new GCMParameterSpec(128,Base64.decode(parts[0],Base64.NO_WRAP)));
  return new String(cipher.doFinal(Base64.decode(parts[1],Base64.NO_WRAP)),StandardCharsets.UTF_8);
 }
 static String send(Context ctx,String owner,byte[] xlsx)throws Exception{
  if(xlsx.length==0||xlsx.length>UploadProtocol.MAX_BYTES)throw new IOException("Excel vide ou supérieur à 6 Mio. Réduisez la tournée.");
  String url=UploadProtocol.endpoint(prefs(ctx).getString("endpoint",""));
  String hash=UploadProtocol.sha(xlsx),id=UploadProtocol.sha((owner+"\n"+hash).getBytes(StandardCharsets.UTF_8));long time=System.currentTimeMillis()/1000;
  JSONObject body=new JSONObject().put("owner",owner).put("sha256",hash).put("id",id).put("time",time).put("data",Base64.encodeToString(xlsx,Base64.NO_WRAP));
  body.put("signature",UploadProtocol.signature(secret(ctx,owner),UploadProtocol.canonical(owner,hash,id,time)));
  JSONObject ack=new JSONObject(request(url,body.toString().getBytes(StandardCharsets.UTF_8)));
  if(!ack.optBoolean("ok")||!id.equals(ack.optString("id"))||!hash.equals(ack.optString("sha256"))||ack.optString("fileId").isEmpty())throw new IOException("Drive n’a pas confirmé la réception. Données locales conservées. Vérifiez la configuration ou réessayez.");
  return "Excel reçu dans Drive : "+ack.optString("name")+"\nAucune copie Excel créée sur le téléphone. Relevés et photos conservés dans l’application.";
 }
 static String request(String endpoint,byte[] body)throws Exception{
  String next=endpoint;
  for(int hop=0;hop<4;hop++){
   HttpURLConnection connection=(HttpURLConnection)new URL(next).openConnection();
   connection.setInstanceFollowRedirects(false);connection.setConnectTimeout(20000);connection.setReadTimeout(90000);
   try{
    if(hop==0){connection.setRequestMethod("POST");connection.setDoOutput(true);connection.setRequestProperty("Content-Type","application/json; charset=UTF-8");connection.setFixedLengthStreamingMode(body.length);try(OutputStream out=connection.getOutputStream()){out.write(body);}}
    int status=connection.getResponseCode();
    if(status==302||status==303){
     URI redirect=new URI(next).resolve(connection.getHeaderField("Location"));
     if(!"https".equals(redirect.getScheme())||!"script.googleusercontent.com".equals(redirect.getHost())||redirect.getUserInfo()!=null||redirect.getPort()!=-1)throw new IOException("Redirection Drive refusée. Vérifiez le déploiement du service.");
     next=redirect.toString();continue;
    }
    if(status!=200)throw new IOException("Envoi Drive refusé (HTTP "+status+"). Données locales conservées.");
    try(InputStream in=connection.getInputStream()){return new String(TableFile.limited(in,32768),StandardCharsets.UTF_8);}
   }finally{connection.disconnect();}
  }
  throw new IOException("Trop de redirections Drive.");
 }
}
