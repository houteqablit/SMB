package ma.releve.terrain.v320;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.SQLException;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Rect;
import android.graphics.drawable.GradientDrawable;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.ConnectivityManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.MotionEvent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import android.widget.TextView;
import android.widget.Toast;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import ma.releve.terrain.v320.BackupPack;
import ma.releve.terrain.v320.Model;
import ma.releve.terrain.v320.Store;

public final class MainActivity extends Activity {
    static final int BG = 0xFFF7FAFC;
    static final int GRAY = -10259318;
    static final int GREEN = 0xFF218567;
    static final int NAVY = -15585976;
    final IndexConfirmation indexConfirmation = new IndexConfirmation();
    boolean internalIndexChange;
    AlertDialog indexPrompt;
    Spinner typeSelector;
    Store.Record active;
    Spinner anomaly;
    Runnable autoTick;
    LinearLayout body;
    TextView calculation;
    LinearLayout cards;
    EditText comment;
    EditText confirm;
    ConnectivityManager connectivity;
    Store db;
    float downX;
    float downY;
    long gpsStarted;
    Location fix;
    TextView gpsText;
    Runnable gpsTimeout;
    LocationListener listener;
    LocationManager lm;
    EditText local;
    EditText netEdit;
    Spinner netSelector;
    android.widget.ImageView meterNetworkIcon;
    TextView formMeterText;
    TextView formIdentifierText;
    TextView formRouteHeading;
    ConnectivityManager.NetworkCallback network;
    EditText newIndex;
    EditText phone;
    TextView photoText;
    CheckBox repeat;
    Bundle restore;
    LinearLayout root;
    EditText search;
    File selectedArchive;
    EditText serEdit;
    TextView stats;
    boolean swipeAllowed;
    EditText urEdit;
    List<Store.Anomaly> choices = new ArrayList();
    String user = "";
    String query = "";
    String chosenUr = null;
    String chosenTour = null;
    String chosenCampaign = null;
    String status = null;
    String capture = "";
    String photoFor = "";
    String exportFormat = "xlsx";
    boolean admin = false;
    boolean busy = false;
    boolean dirty = false;
    boolean saveAfterGps = false;
    int errors = 0;
    long blockedUntil = 0;
    ExecutorService worker = Executors.newSingleThreadExecutor();
    Handler handler = new Handler();
    long lastAuto = 0;
    List<Long> routeIds = new ArrayList();

    interface BytesJob {
        byte[] run() throws Exception;
    }

    interface Done {
        void result(String str);
    }

    interface Job {
        String run() throws Exception;
    }

    interface Selection {
        void choose(String str);
    }

    @Override // android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        getWindow().addFlags(8192);
        this.db = new Store(this);
        this.db.getWritableDatabase();
        this.lm = (LocationManager) getSystemService("location");
        this.connectivity = (ConnectivityManager) getSystemService("connectivity");
        this.restore = bundle;
        loginScreen();
    }

    @Override // android.app.Activity
    protected void onSaveInstanceState(Bundle bundle) {
        super.onSaveInstanceState(bundle);
        if (this.active != null) {
            bundle.putLong("id", this.active.id);
            bundle.putStringArray("record", (String[]) this.active.a.clone());
            bundle.putString("new", value(this.newIndex));
            bundle.putString("confirm", value(this.confirm));
            bundle.putString("firstIndex", this.indexConfirmation.first);
            bundle.putBoolean("indexConfirmed", this.indexConfirmation.confirmed);
            bundle.putString("comment", value(this.comment));
            bundle.putString("phone", value(this.phone));
            bundle.putString("local", value(this.local));
            bundle.putString("selected", selected() == null ? "" : selected().code);
            bundle.putString("capture", this.capture);
            bundle.putString("photoFor", this.photoFor);
            bundle.putBoolean("repeat", this.repeat.isChecked());
            bundle.putString("owner", this.user);
            if (this.urEdit != null) {
                bundle.putString("urDraft", value(this.urEdit));
            }
            if (this.serEdit != null) {
                bundle.putString("serDraft", value(this.serEdit));
            }
            int size = this.routeIds.size();
            long[] jArr = new long[size];
            for (int i = 0; i < size; i++) {
                jArr[i] = this.routeIds.get(i).longValue();
            }
            bundle.putLongArray("route", jArr);
        }
    }

    int dp(int i) {
        return (int) (i * getResources().getDisplayMetrics().density);
    }

    String value(EditText editText) {
        return editText == null ? "" : editText.getText().toString().trim();
    }

    GradientDrawable shape(int i, int i2) {
        GradientDrawable gradientDrawable = new GradientDrawable();
        gradientDrawable.setColor(i);
        gradientDrawable.setCornerRadius(dp(i2));
        return gradientDrawable;
    }

    void outline(Spinner spinner) {
        spinner.setBackground(inputShape());
        spinner.setPadding(dp(10), dp(5), dp(10), dp(5));
        spinner.setMinimumHeight(dp(48));
    }

    GradientDrawable inputShape() {
        GradientDrawable gradientDrawableShape = shape(-525057, 8);
        gradientDrawableShape.setStroke(dp(2), -10838595);
        return gradientDrawableShape;
    }

    TextView text(String str, int i, int i2) {
        TextView textView = new TextView(this);
        textView.setText(str);
        textView.setTextSize(i);
        textView.setTextColor(i2);
        textView.setPadding(0, dp(5), 0, dp(5));
        return textView;
    }

    Button button(String str, final Runnable runnable) {
        Button button = new Button(this);
        button.setText(str);
        button.setAllCaps(false);
        button.setTextColor(-1);
        button.setTextSize(14.0f);
        button.setBackground(shape(GREEN, 10));
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, dp(48));
        layoutParams.setMargins(0, dp(7), 0, dp(4));
        button.setLayoutParams(layoutParams);
        button.setOnClickListener(new View.OnClickListener() { // from class: ma.releve.terrain.v320.MainActivity$$ExternalSyntheticLambda85
            @Override // android.view.View.OnClickListener
            public final void onClick(View view) {
                MainActivity.this.m16lambda$button$0$mareleveterrainMainActivity(runnable, view);
            }
        });
        return button;
    }

    /* renamed from: lambda$button$0$ma-releve-terrain-MainActivity, reason: not valid java name */
    /* synthetic */ void m16lambda$button$0$mareleveterrainMainActivity(Runnable runnable, View view) {
        if (this.busy) {
            toast("Opération en cours…");
        } else {
            runnable.run();
        }
    }

    void mainMenu() {
        if(this.user.isEmpty())return;
        new AlertDialog.Builder(this).setTitle("Menu principal").setItems(new String[]{"Liste des compteurs","Tableau de bord","Administrateur 🔒","Ma tournée / Synchroniser","Mes sauvegardes","Nouveau compteur hors liste","Exporter Excel / CSV / photos","Envoyer les relevés vers Drive","Retour","Modifier mon mot de passe","Déconnexion","Rechercher un compteur","Purger la base de données","Configurer l’envoi Drive"},(d,i)->{
            Runnable action;
            switch(i){
                case 0: action=()->home();break;
                case 1: action=()->dashboard();break;
                case 2: action=()->adminGate();break;
                case 3: action=()->myDrive();break;
                case 4: action=()->backups();break;
                case 5: action=()->newMeter();break;
                case 6: action=()->exportMenu();break;
                case 7: action=()->sendDirectDrive();break;
                case 8: action=()->home();break;
                case 9: action=()->changePasswordScreen();break;
                case 10: action=()->{stopGps();user="";admin=false;active=null;loginScreen();};break;
                case 11: action=()->searchMeterDialog();break;
                case 12: action=()->purgeScreen();break;
                default: action=()->driveConfiguration();break;
            }
            if(i==11){searchMeterDialog();return;}
            if(active!=null && dirty)new AlertDialog.Builder(this).setTitle("Saisie non enregistrée").setMessage("Abandonner les modifications ?").setNegativeButton("Annuler",null).setPositiveButton("Abandonner",(dd,w)->action.run()).show();else action.run();
        }).show();
    }
    void changePasswordScreen() {
        if (this.user.isEmpty()) return;
        final String account = this.user;
        shell("Modifier mon mot de passe • " + account);
        this.body.addView(button("‹ Retour", () -> {if (admin) administration(); else home();}));
        EditText current = field("Mot de passe actuel", "", 129, false);
        EditText replacement = field("Nouveau mot de passe (8 caractères minimum)", "", 129, false);
        EditText confirmation = field("Confirmer le nouveau mot de passe", "", 129, false);
        for (EditText input : new EditText[]{current, replacement, confirmation}) {
            input.setSaveEnabled(false);
            if (android.os.Build.VERSION.SDK_INT >= 26)
                input.setImportantForAutofill(android.view.View.IMPORTANT_FOR_AUTOFILL_NO);
        }
        this.body.addView(button("Enregistrer le mot de passe", () -> {
            final String oldPassword = current.getText().toString();
            final String newPassword = replacement.getText().toString();
            final String repeated = confirmation.getText().toString();
            async(() -> {
                db.changePassword(account, oldPassword, newPassword, repeated);
                return "Mot de passe modifié. Utilisez le nouveau mot de passe à votre prochaine connexion.";
            }, message -> {
                current.setText(""); replacement.setText(""); confirmation.setText("");
                if (admin) administration(); else home();
                alert(message);
            }, message -> {current.setText(""); alert(message);});
        }));
    }

    boolean ensureIndexConfirmed() {
        String entered=value(this.newIndex);
        Model.Result assessment=result();
        if(!assessment.error.isEmpty()){alert(assessment.error);return false;}
        if(this.indexConfirmation.accept(entered,assessment.abnormal)) {
            this.confirm.setText(this.indexConfirmation.confirmed ? this.indexConfirmation.first : "");
            return true;
        }
        this.internalIndexChange=true;
        this.newIndex.setText("");
        this.internalIndexChange=false;
        this.newIndex.setHint("Ressaisissez l’index");
        this.newIndex.requestFocus();
        showIndexPrompt();
        return false;
    }

    void showIndexPrompt() {
        if (indexPrompt != null && indexPrompt.isShowing()) indexPrompt.dismiss();
        TextView message=text("Ressaisie obligatoire de l’index.\nSaisissez à nouveau l’index : deux saisies consécutives doivent être identiques avant la photo et la validation.",14,0xFFD32F2F);
        message.setTypeface(null,android.graphics.Typeface.BOLD);
        message.setPadding(dp(20),dp(12),dp(20),dp(12));
        indexPrompt=new AlertDialog.Builder(this).setTitle("Confirmation de l’index")
            .setView(message).setPositiveButton("Ressaisir",(dialog,which)->{
                if (newIndex != null && active != null) {
                    newIndex.requestFocus();
                    newIndex.post(()->((android.view.inputmethod.InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).showSoftInput(newIndex,android.view.inputmethod.InputMethodManager.SHOW_IMPLICIT));
                }
            }).create();
        indexPrompt.show();
        indexPrompt.getWindow().addFlags(android.view.WindowManager.LayoutParams.FLAG_ALT_FOCUSABLE_IM);
    }

    void shell(String str) {
        this.root = new LinearLayout(this);
        this.root.setOrientation(1);
        this.root.setBackgroundColor(BG);
        this.root.setFitsSystemWindows(true);
        LinearLayout linearLayout = new LinearLayout(this);
        linearLayout.setOrientation(1);
        linearLayout.setPadding(dp(20), dp(14), dp(20), dp(12));
        linearLayout.setBackgroundColor(0xFFE9F3F5);
        TextView textViewText = text("SmartMobility Terrain", 24, NAVY);
        textViewText.setTypeface(null, 1);
        LinearLayout heading = new LinearLayout(this);
        Button menu = button("⋮", () -> mainMenu());
        menu.setContentDescription("Menu principal");
        heading.addView(menu, new LinearLayout.LayoutParams(dp(52),dp(52)));
        heading.addView(textViewText, new LinearLayout.LayoutParams(0,-2,1));
        linearLayout.addView(heading);
        linearLayout.addView(text(str, 13, NAVY));
        this.root.addView(linearLayout);
        ScrollView scrollView = new ScrollView(this);
        scrollView.setFillViewport(true);
        this.body = new LinearLayout(this);
        this.body.setOrientation(1);
        this.body.setPadding(dp(16), dp(12), dp(16), dp(24));
        scrollView.addView(this.body);
        this.root.addView(scrollView, new LinearLayout.LayoutParams(-1, 0, 1.0f));
        setContentView(this.root);
        this.cards = null;
    }

    EditText field(String str, String str2, int i, boolean z) {
        this.body.addView(text(str, 14, NAVY));
        EditText editText = new EditText(this);
        editText.setText(str2);
        editText.setInputType(i);
        editText.setSingleLine(!z);
        if (z) {
            editText.setMinLines(2);
        }
        editText.setPadding(dp(12), dp(10), dp(12), dp(10));
        editText.setTextColor(NAVY);
        editText.setHintTextColor(GRAY);
        editText.setBackground(inputShape());
        this.body.addView(editText, new LinearLayout.LayoutParams(-1, -2));
        return editText;
    }

    EditText field(String str, String str2) {
        return field(str, str2, 1, false);
    }

    Spinner selector(String str, final List<String> list, final Selection selection) {
        this.body.addView(text(str, 13, GRAY));
        Spinner spinner = new Spinner(this);
        outline(spinner);
        spinner.setAdapter((SpinnerAdapter) new ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, list));
        this.body.addView(spinner);
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() { // from class: ma.releve.terrain.v320.MainActivity.1
            @Override // android.widget.AdapterView.OnItemSelectedListener
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long j) {
                selection.choose((String) list.get(i));
            }

            @Override // android.widget.AdapterView.OnItemSelectedListener
            public void onNothingSelected(AdapterView<?> adapterView) {
            }
        });
        return spinner;
    }

    /* renamed from: lambda$loginScreen$1$ma-releve-terrain-MainActivity, reason: not valid java name */
    /* synthetic */ String m47lambda$loginScreen$1$mareleveterrainMainActivity(boolean z, String str, String str2) throws Exception {
        if (z) {
            this.db.user(str, str2, "ADMIN", str, str);
            return "ADMIN";
        }
        String strLogin = this.db.login(str, str2);
        if (strLogin != null) {
            return strLogin;
        }
        throw new Exception("Identifiant ou mot de passe incorrect.");
    }

    /* renamed from: lambda$loginScreen$2$ma-releve-terrain-MainActivity, reason: not valid java name */
    /* synthetic */ void m48lambda$loginScreen$2$mareleveterrainMainActivity(String str, String str2) throws SQLException {
        this.errors = 0;
        this.user = str;
        this.admin = str2.equals("ADMIN");
        this.db.log(this.user, "CONNEXION", "Connexion locale");
        home();
        restoreDraft();
        maybeAuto();
    }

    /* renamed from: lambda$loginScreen$3$ma-releve-terrain-MainActivity, reason: not valid java name */
    /* synthetic */ void m49lambda$loginScreen$3$mareleveterrainMainActivity(String str) {
        this.errors++;
        if (this.errors >= 5) {
            this.blockedUntil = SystemClock.elapsedRealtime() + 30000;
            this.errors = 0;
        }
        alert(str);
    }

    /* renamed from: lambda$loginScreen$4$ma-releve-terrain-MainActivity, reason: not valid java name */
    /* synthetic */ void m50lambda$loginScreen$4$mareleveterrainMainActivity(EditText editText, EditText editText2, final boolean z) {
        if (SystemClock.elapsedRealtime() < this.blockedUntil) {
            alert("Réessayez dans 30 secondes.");
            return;
        }
        final String strValue = value(editText);
        final String strValue2 = value(editText2);
        async(new Job() { // from class: ma.releve.terrain.v320.MainActivity$$ExternalSyntheticLambda71
            @Override // ma.releve.terrain.v320.MainActivity.Job
            public final String run() throws Exception {
                return MainActivity.this.m47lambda$loginScreen$1$mareleveterrainMainActivity(z, strValue, strValue2);
            }
        }, new Done() { // from class: ma.releve.terrain.v320.MainActivity$$ExternalSyntheticLambda72
            @Override // ma.releve.terrain.v320.MainActivity.Done
            public final void result(String str) throws SQLException {
                MainActivity.this.m48lambda$loginScreen$2$mareleveterrainMainActivity(strValue, str);
            }
        }, new Done() { // from class: ma.releve.terrain.v320.MainActivity$$ExternalSyntheticLambda73
            @Override // ma.releve.terrain.v320.MainActivity.Done
            public final void result(String str) {
                MainActivity.this.m49lambda$loginScreen$3$mareleveterrainMainActivity(str);
            }
        });
    }

    void loginScreen() {
        stopGps();
        this.active = null;
        this.user = "";
        this.admin = false;
        this.busy = false;
        shell(this.db.hasUsers() ? "Connexion individuelle • données locales" : "Première utilisation • créer l’administrateur");
        final boolean z = !this.db.hasUsers();
        final EditText editTextField = field("Identifiant", "");
        final EditText editTextField2 = field("Mot de passe (8 caractères minimum)", "", 129, false);
        this.body.addView(button(z ? "Créer l’administrateur" : "Se connecter", new Runnable() { // from class: ma.releve.terrain.v320.MainActivity$$ExternalSyntheticLambda84
            @Override // java.lang.Runnable
            public final void run() {
                MainActivity.this.m50lambda$loginScreen$4$mareleveterrainMainActivity(editTextField, editTextField2, z);
            }
        }));
        this.body.addView(text("Comptes et habilitations locaux au téléphone. L’administrateur crée les releveurs et leur affecte les tournées.", 13, GRAY));
    }

    void restoreDraft() {
        if (this.restore == null || !this.user.equals(this.restore.getString("owner"))) {
            return;
        }
        String[] stringArray = this.restore.getStringArray("record");
        if (stringArray == null) {
            this.restore = null;
            return;
        }
        Store.Record record = new Store.Record(stringArray);
        record.id = this.restore.getLong("id");
        long[] longArray = this.restore.getLongArray("route");
        this.routeIds.clear();
        if (longArray != null) {
            for (long j : longArray) {
                this.routeIds.add(Long.valueOf(j));
            }
        }
        if (this.admin || record.a[23].equals(this.user)) {
            form(record);
            this.newIndex.setText(this.restore.getString("new", ""));
            this.confirm.setText(this.restore.getString("confirm", ""));
            this.indexConfirmation.first = this.restore.getString("firstIndex", "");
            this.indexConfirmation.confirmed = this.restore.getBoolean("indexConfirmed", false);
            this.comment.setText(this.restore.getString("comment", ""));
            this.phone.setText(this.restore.getString("phone", ""));
            this.local.setText(this.restore.getString("local", ""));
            if(this.typeSelector!=null) {
                List<String> codes=(List<String>)this.typeSelector.getTag();String restoredType=value(this.local);
                if(!codes.contains(restoredType)){codes.add(restoredType);((ArrayAdapter<String>)this.typeSelector.getAdapter()).add(restoredType);}
                this.typeSelector.setSelection(codes.indexOf(restoredType));
            }
            chooseCode(this.restore.getString("selected", ""));
            this.capture = this.restore.getString("capture", "");
            this.photoFor = this.restore.getString("photoFor", "");
            this.repeat.setChecked(this.restore.getBoolean("repeat"));
            if (this.urEdit != null) {
                this.urEdit.setText(this.restore.getString("urDraft", stringArray[3]));
            }
            if (this.serEdit != null) {
                this.serEdit.setText(this.restore.getString("serDraft", stringArray[4]));
            }
            if (!this.capture.isEmpty()) {
                this.photoText.setText("Photo en cours : " + this.capture);
                try {
                    if (Exchange.photo(this, this.capture).length() > 0) {
                        processPhoto(this.capture);
                    }
                } catch (Exception e) {
                }
            }
        }
        this.restore = null;
    }

    AlertDialog searchResultsDialog;
    List<Store.Record> searchMeterMatches(String term){
        return db.list(user,admin,term.trim(),null,null,null,0);
    }
    void searchMeterDialog(){
        EditText input=new EditText(this);
        input.setHint("Compteur, identifiant, contrat, UR, nom ou adresse");
        input.setSingleLine(true);
        AlertDialog dialog=new AlertDialog.Builder(this).setTitle("Rechercher un compteur").setView(input)
            .setNegativeButton("Annuler",null).setPositiveButton("Rechercher",null).create();
        dialog.setOnShowListener(d->dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{
            if(value(input).isEmpty()){input.setError("Saisissez votre recherche");return;}
            dialog.dismiss();showMeterSearch(value(input));
        }));dialog.show();
    }
    void searchNavigate(Runnable action){
        if(active!=null&&dirty)new AlertDialog.Builder(this).setTitle("Saisie non enregistrée")
            .setMessage("Abandonner les modifications pour changer de compteur ?")
            .setNegativeButton("Annuler",null).setPositiveButton("Abandonner",(d,w)->action.run()).show();
        else action.run();
    }
    void showMeterSearch(String term){
        List<Store.Record> matches=searchMeterMatches(term);
        if(matches.isEmpty()){
            searchResultsDialog=new AlertDialog.Builder(this).setTitle("Aucun compteur trouvé")
                .setMessage("Aucun compteur ne correspond à votre recherche. Voulez-vous créer un nouveau compteur hors liste ?")
                .setNegativeButton("Annuler",null)
                .setPositiveButton("Nouveau compteur hors liste",(d,w)->searchNavigate(()->newMeter())).show();
            return;
        }
        String[] labels=new String[matches.size()];
        for(int i=0;i<matches.size();i++){
            Store.Record record=matches.get(i);
            labels[i]=record.a[4]+" • "+record.a[14]+" • "+record.a[21]+"\n"+record.a[1]+" • "+record.a[2];
        }
        searchResultsDialog=new AlertDialog.Builder(this).setTitle(matches.size()+" compteur(s) trouvé(s)")
            .setItems(labels,(d,i)->searchNavigate(()->{
                stopGps();routeIds.clear();for(Store.Record record:matches)routeIds.add(record.id);
                form(matches.get(i));
            })).setNegativeButton("Annuler",null).show();
    }

    void driveConfiguration(){
        if(!admin){alert("Configuration réservée à l’administrateur. Ouvrez Administration pour vous authentifier.");return;}
        shell("Configuration envoi Drive");
        body.addView(button("‹ Retour",()->administration()));
        EditText endpoint=field("URL Apps Script HTTPS /exec",DriveUpload.prefs(this).getString("endpoint",""));
        EditText owner=field("Identifiant du compte à autoriser",user);
        EditText token=field("Clé de transfert propre au compte (32 caractères minimum)","",129,false);
        token.setSaveEnabled(false);token.setImportantForAutofill(android.view.View.IMPORTANT_FOR_AUTOFILL_NO);
        body.addView(text("Configurer le même identifiant et la même clé dans les propriétés Apps Script. Aucun mot de passe Google. La clé est chiffrée sur ce téléphone. L’envoi concerne les données du compte connecté, pas les photos.",14,NAVY));
        body.addView(button("Enregistrer la configuration",()->{
            try{
                if(db.loginRole(value(owner))==null)throw new IOException("Compte local introuvable.");
                DriveUpload.configure(this,value(endpoint),value(owner),token.getText().toString());
                token.setText("");alert("Configuration enregistrée pour "+value(owner)+".");
            }catch(Exception e){alert(e.getMessage()==null?"Configuration impossible.":e.getMessage());}
        }));
    }
    void sendDirectDrive(){
        if(user.isEmpty())return;
        final String owner=user;
        new AlertDialog.Builder(this).setTitle("Envoyer l’Excel directement vers Drive")
            .setMessage("Envoyer les compteurs de ce compte, avec codes et libellés des anomalies ? Aucune copie Excel ne sera enregistrée dans Téléchargements. Les photos ne sont pas envoyées. Les relevés restent dans l’application.")
            .setNegativeButton("Annuler",null).setPositiveButton("Envoyer",(d,w)->async(()->{
                java.io.ByteArrayOutputStream bytes=new java.io.ByteArrayOutputStream();
                List<String[]> rows=db.export(owner,false);
                if(rows.size()<2)throw new IOException("Aucun compteur à envoyer.");
                TableFile.writeXlsx(bytes,rows);
                return DriveUpload.send(this,owner,bytes.toByteArray());
            },message->alert(message),message->alert("Envoi non confirmé. Données locales conservées.\n"+message))).show();
    }
    AlertDialog purgeDialog;
    EditText purgePassword,purgeWord;
    boolean purgeAuthorized(String password,String confirmation)throws Exception{
        return !user.isEmpty()&&"PURGER".equals(confirmation)&&db.login(user,password)!=null;
    }
    void purgeScreen(){
        if(user.isEmpty()||busy)return;
        LinearLayout fields=new LinearLayout(this);fields.setOrientation(1);fields.setPadding(dp(16),0,dp(16),0);
        purgePassword=new EditText(this);purgePassword.setHint("Mot de passe du compte connecté");purgePassword.setInputType(129);purgePassword.setSaveEnabled(false);purgePassword.setImportantForAutofill(android.view.View.IMPORTANT_FOR_AUTOFILL_NO);fields.addView(purgePassword);
        purgeWord=new EditText(this);purgeWord.setHint("Écrire PURGER");purgeWord.setSingleLine(true);fields.addView(purgeWord);
        purgeDialog=new AlertDialog.Builder(this).setTitle("Purger toutes les données du téléphone ?")
            .setMessage("Suppression définitive de TOUS les comptes, tournées, relevés, photos, sauvegardes locales et configurations de cette application, y compris celles des autres releveurs. Les fichiers déjà exportés hors de l’application et ceux de Drive restent présents. Après la purge, recréez l’administrateur. Exportez vos données avant de continuer.")
            .setView(fields).setNegativeButton("Annuler",null).setPositiveButton("Tout effacer",null).create();
        purgeDialog.setOnShowListener(d->purgeDialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{
            try{
                if(!purgeAuthorized(purgePassword.getText().toString(),value(purgeWord))){purgePassword.setText("");purgeWord.setError("Mot de passe valide et mot PURGER requis.");return;}
                stopGps();
                android.app.ActivityManager manager=(android.app.ActivityManager)getSystemService(ACTIVITY_SERVICE);
                if(!manager.clearApplicationUserData())alert("Purge refusée par Android. Aucune purge confirmée.");
            }catch(Exception e){alert("Purge non effectuée.");}
        }));purgeDialog.show();
    }

    void home() {
        stopGps();
        this.active = null;
        this.dirty = false;
        this.fix = null;
        this.capture = "";
        if (this.user.isEmpty()) {
            loginScreen();
            return;
        }
        shell(this.user + " • " + (this.admin ? "Administrateur" : "Releveur") + " • " + campaign());
        this.stats = text("", 16, NAVY);
        this.body.addView(this.stats);
        this.search = field("Recherche : contrat, compteur, UR, identifiant, nom ou adresse", this.query);
        this.search.addTextChangedListener(watcher(new Runnable() { // from class: ma.releve.terrain.v320.MainActivity$$ExternalSyntheticLambda39
            @Override // java.lang.Runnable
            public final void run() {
                MainActivity.this.m36lambda$home$6$mareleveterrainMainActivity();
            }
        }));
        this.body.addView(button("Rechercher un compteur",()->{if(value(search).isEmpty())searchMeterDialog();else showMeterSearch(value(search));}));
        this.chosenCampaign = campaign();
        ArrayList arrayList = new ArrayList();
        arrayList.add("Toutes les campagnes");
        arrayList.add(campaign());
        for (String str : this.db.distinct("campagne", this.user, this.admin)) {
            if (!arrayList.contains(str)) {
                arrayList.add(str);
            }
        }
        selector("Campagne", arrayList, new Selection() { // from class: ma.releve.terrain.v320.MainActivity$$ExternalSyntheticLambda40
            @Override // ma.releve.terrain.v320.MainActivity.Selection
            public final void choose(String str2) {
                MainActivity.this.m37lambda$home$7$mareleveterrainMainActivity(str2);
            }
        }).setSelection(1);
        final ArrayList arrayList2 = new ArrayList();
        arrayList2.add("Toutes les UR");
        arrayList2.addAll(this.db.distinct("ur", this.user, this.admin));
        this.chosenUr = null;
        final Spinner[] spinnerArr = {null};
        final LinearLayout linearLayout = new LinearLayout(this);
        linearLayout.setOrientation(1);
        linearLayout.setVisibility(8);
        selector("Affichage des données", Arrays.asList("Tous", "Par UR"), new Selection() { // from class: ma.releve.terrain.v320.MainActivity$$ExternalSyntheticLambda41
            @Override // ma.releve.terrain.v320.MainActivity.Selection
            public final void choose(String str2) {
                MainActivity.this.m38lambda$home$8$mareleveterrainMainActivity(linearLayout, spinnerArr, arrayList2, str2);
            }
        });
        linearLayout.addView(text("Choisir l’UR", 13, GRAY));
        Spinner spinner = new Spinner(this);
        outline(spinner);
        spinnerArr[0] = spinner;
        spinner.setAdapter((SpinnerAdapter) new ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, arrayList2));
        linearLayout.addView(spinner);
        this.body.addView(linearLayout);
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() { // from class: ma.releve.terrain.v320.MainActivity.2
            @Override // android.widget.AdapterView.OnItemSelectedListener
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long j) {
                MainActivity.this.chosenUr = (linearLayout.getVisibility() != 0 || i <= 0) ? null : (String) arrayList2.get(i);
                MainActivity.this.refresh();
            }

            @Override // android.widget.AdapterView.OnItemSelectedListener
            public void onNothingSelected(AdapterView<?> adapterView) {
            }
        });
        ArrayList arrayList3 = new ArrayList();
        arrayList3.add("Toutes les tournées");
        arrayList3.addAll(this.db.distinct("tournee", this.user, this.admin));
        this.chosenTour = null;
        selector("Tournée", arrayList3, new Selection() { // from class: ma.releve.terrain.v320.MainActivity$$ExternalSyntheticLambda29
            @Override // ma.releve.terrain.v320.MainActivity.Selection
            public final void choose(String str2) {
                MainActivity.this.m39lambda$home$9$mareleveterrainMainActivity(str2);
            }
        });
        this.status = null;
        selector("Liste des contrats", Arrays.asList("Tous", "Relevés", "Non relevés"), new Selection() { // from class: ma.releve.terrain.v320.MainActivity$$ExternalSyntheticLambda30
            @Override // ma.releve.terrain.v320.MainActivity.Selection
            public final void choose(String str2) {
                MainActivity.this.m33lambda$home$10$mareleveterrainMainActivity(str2);
            }
        });
        this.body.addView(button("Contrats pour deuxième passage", new Runnable() { // from class: ma.releve.terrain.v320.MainActivity$$ExternalSyntheticLambda31
            @Override // java.lang.Runnable
            public final void run() {
                MainActivity.this.m34lambda$home$11$mareleveterrainMainActivity();
            }
        }));
        this.cards = new LinearLayout(this);
        this.cards.setOrientation(1);
        this.body.addView(this.cards);
        this.body.addView(button("Se déconnecter", new Runnable() { // from class: ma.releve.terrain.v320.MainActivity$$ExternalSyntheticLambda32
            @Override // java.lang.Runnable
            public final void run() {
                MainActivity.this.loginScreen();
            }
        }));
        refresh();
    }

    /* renamed from: lambda$home$5$ma-releve-terrain-MainActivity, reason: not valid java name */
    /* synthetic */ void m35lambda$home$5$mareleveterrainMainActivity() {
        if (this.active != null || this.cards == null) {
            return;
        }
        refresh();
    }

    /* renamed from: lambda$home$6$ma-releve-terrain-MainActivity, reason: not valid java name */
    /* synthetic */ void m36lambda$home$6$mareleveterrainMainActivity() {
        this.query = value(this.search);
        this.handler.postDelayed(new Runnable() { // from class: ma.releve.terrain.v320.MainActivity$$ExternalSyntheticLambda17
            @Override // java.lang.Runnable
            public final void run() {
                MainActivity.this.m35lambda$home$5$mareleveterrainMainActivity();
            }
        }, 150L);
    }

    /* renamed from: lambda$home$10$ma-releve-terrain-MainActivity, reason: not valid java name */
    /* synthetic */ void m33lambda$home$10$mareleveterrainMainActivity(String str) {
        this.status = str.equals("Relevés") ? "_RELEVES" : str.equals("Non relevés") ? "_NON_RELEVES" : null;
        refresh();
    }

    /* renamed from: lambda$home$11$ma-releve-terrain-MainActivity, reason: not valid java name */
    /* synthetic */ void m34lambda$home$11$mareleveterrainMainActivity() {
        this.status = "A_REPASSER";
        refresh();
        toast("Filtre : deuxième passage");
    }

    /* renamed from: lambda$home$7$ma-releve-terrain-MainActivity, reason: not valid java name */
    /* synthetic */ void m37lambda$home$7$mareleveterrainMainActivity(String str) {
        if (str.equals("Toutes les campagnes")) {
            str = null;
        }
        this.chosenCampaign = str;
        refresh();
    }

    /* renamed from: lambda$home$8$ma-releve-terrain-MainActivity, reason: not valid java name */
    /* synthetic */ void m38lambda$home$8$mareleveterrainMainActivity(LinearLayout linearLayout, Spinner[] spinnerArr, List list, String str) {
        String str2 = null;
        linearLayout.setVisibility(str.equals("Par UR") ? 0 : 8);
        if (!str.equals("Tous")) {
            str2 = (spinnerArr[0] != null && spinnerArr[0].getSelectedItemPosition() > 0) ? (String) list.get(spinnerArr[0].getSelectedItemPosition()) : null;
            refresh();
        }
        this.chosenUr = str2;
        refresh();
    }

    /* renamed from: lambda$home$9$ma-releve-terrain-MainActivity, reason: not valid java name */
    /* synthetic */ void m39lambda$home$9$mareleveterrainMainActivity(String str) {
        if (str.equals("Toutes les tournées")) {
            str = null;
        }
        this.chosenTour = str;
        refresh();
    }

    String campaign() {
        return getPreferences(0).getString("campaign_" + this.user, getPreferences(0).getString("campaign", LocalDate.now().toString().substring(0, 7)));
    }

    List<Store.Record> records(String str, String str2, String str3, String str4, int i) {
        return this.db.list(this.user, this.admin, str, str2, str3, str4, i, this.chosenCampaign);
    }

    /* renamed from: lambda$refresh$12$ma-releve-terrain-MainActivity, reason: not valid java name */
    /* synthetic */ void m61lambda$refresh$12$mareleveterrainMainActivity(Store.Record record, View view) {
        if (this.busy) {
            return;
        }
        openRoute(record.id);
    }

    void refresh() {
        int i;
        if (this.active != null || this.cards == null || this.user.isEmpty()) {
            return;
        }
        List<Store.Record> listRecords = records(this.query, this.chosenUr, this.chosenTour, this.status, 0);
        Iterator<Store.Record> it = listRecords.iterator();
        int i2 = 0;
        int i3 = 0;
        int i4 = 0;
        int i5 = 0;
        while (true) {
            i = 10;
            if (!it.hasNext()) {
                break;
            }
            Store.Record next = it.next();
            if (!next.a[7].isEmpty()) {
                i3++;
            }
            if (!next.a[10].isEmpty()) {
                i4++;
            }
            if (!next.a[10].isEmpty()) {
                i5++;
            }
        }
        this.stats.setText(i3 + " index / " + listRecords.size() + " compteurs • " + i4 + " visites\n" + i5 + " relevés enregistrés localement" + ("A_REPASSER".equals(this.status) ? "\nFiltre actif : deuxième passage" : ""));
        this.cards.removeAllViews();
        List<Store.Record> listRecords2 = records(this.query, this.chosenUr, this.chosenTour, this.status, 151);
        if (listRecords2.isEmpty()) {
            this.cards.addView(text("Pas de compteurs chargés", 15, GRAY));
        }
        int i6 = 0;
        while (i6 < Math.min(150, listRecords2.size())) {
            final Store.Record record = listRecords2.get(i6);
            LinearLayout linearLayout = new LinearLayout(this);
            linearLayout.setOrientation(1);
            linearLayout.setPadding(dp(14), dp(i), dp(14), dp(i));
            GradientDrawable gradientDrawableShape = shape(-1, 12);
            gradientDrawableShape.setStroke(dp(1), -6567969);
            linearLayout.setBackground(gradientDrawableShape);
            LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -2);
            layoutParams.setMargins(i2, dp(8), i2, i2);
            linearLayout.setLayoutParams(layoutParams);
            linearLayout.addView(text((record.a[i2].isEmpty() ? "Hors liste" : record.a[i2]) + " • " + record.a[1], 17, NAVY));
            TextView textViewText = text(record.a[14] + " • Compteur " + record.a[4], 16, -1);
            textViewText.setPadding(dp(8), dp(6), dp(8), dp(6));
            textViewText.setBackground(shape(record.a[14].equals("BT") ? -4575173 : -14915148, 6));
            LinearLayout heading = new LinearLayout(this);
        Button menu = button("⋮", () -> mainMenu());
        menu.setContentDescription("Menu principal");
        heading.addView(menu, new LinearLayout.LayoutParams(dp(52),dp(52)));
        heading.addView(textViewText, new LinearLayout.LayoutParams(0,-2,1));
        linearLayout.addView(heading);
            linearLayout.addView(text("UR " + record.a[3] + " • Tournée " + record.a[15] + " • Ordre " + record.a[22], 12, GRAY));
            linearLayout.addView(text(record.a[2], 13, GRAY));
            linearLayout.addView(text(record.a[28] + " • " + record.a[23], 13, GREEN));
            linearLayout.setOnClickListener(new View.OnClickListener() { // from class: ma.releve.terrain.v320.MainActivity$$ExternalSyntheticLambda87
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    MainActivity.this.m61lambda$refresh$12$mareleveterrainMainActivity(record, view);
                }
            });
            this.cards.addView(linearLayout);
            i6++;
            i2 = 0;
            i = 10;
        }
        if (listRecords2.size() > 150) {
            this.cards.addView(text("150 résultats affichés. Précisez la recherche.", 13, GRAY));
        }
    }

    TextWatcher watcher(final Runnable runnable) {
        return new TextWatcher() { // from class: ma.releve.terrain.v320.MainActivity.3
            @Override // android.text.TextWatcher
            public void afterTextChanged(Editable editable) {
            }

            @Override // android.text.TextWatcher
            public void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) {
            }

            @Override // android.text.TextWatcher
            public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
                runnable.run();
            }
        };
    }

    void newMeter() {
        this.routeIds.clear();
        String[] strArrBlank = Model.blank();
        strArrBlank[23] = this.user;
        strArrBlank[Model.NET] = "BT";
        strArrBlank[36] = campaign();
        strArrBlank[18] = "OUI";
        strArrBlank[16] = "Hors liste";
        strArrBlank[28] = "NOUVEAU_COMPTEUR";
        form(new Store.Record(strArrBlank));
    }

    void openRoute(long j) {
        this.routeIds.clear();
        Iterator<Store.Record> it = records(this.query, this.chosenUr, this.chosenTour, this.status, 0).iterator();
        while (it.hasNext()) {
            this.routeIds.add(Long.valueOf(it.next().id));
        }
        form(this.db.get(j));
    }

    /* renamed from: lambda$navigate$13$ma-releve-terrain-MainActivity, reason: not valid java name */
    /* synthetic */ void m53lambda$navigate$13$mareleveterrainMainActivity(int i) {
        form(this.db.get(this.routeIds.get(i).longValue()));
    }

    void navigate(int i) {
        if (this.active == null || this.active.id == 0 || this.busy) {
            return;
        }
        final int iIndexOf = this.routeIds.indexOf(Long.valueOf(this.active.id)) + i;
        if (iIndexOf < 0 || iIndexOf >= this.routeIds.size()) {
            toast(i < 0 ? "Premier compteur" : "Dernier compteur");
            return;
        }
        final Runnable runnable = new Runnable() { // from class: ma.releve.terrain.v320.MainActivity$$ExternalSyntheticLambda64
            @Override // java.lang.Runnable
            public final void run() {
                MainActivity.this.m53lambda$navigate$13$mareleveterrainMainActivity(iIndexOf);
            }
        };
        if (this.dirty) {
            new AlertDialog.Builder(this).setTitle("Saisie non enregistrée").setMessage("Abandonner les modifications pour afficher le compteur " + (i < 0 ? "précédent" : "suivant") + " ?").setNegativeButton("Continuer la saisie", (DialogInterface.OnClickListener) null).setPositiveButton("Abandonner", new DialogInterface.OnClickListener() { // from class: ma.releve.terrain.v320.MainActivity$$ExternalSyntheticLambda65
                @Override // android.content.DialogInterface.OnClickListener
                public final void onClick(DialogInterface dialogInterface, int i2) {
                    runnable.run();
                }
            }).show();
        } else {
            runnable.run();
        }
    }

    @Override // android.app.Activity, android.view.Window.Callback
    public boolean dispatchTouchEvent(MotionEvent motionEvent) {
        if (motionEvent.getActionMasked() == 0) {
            this.downX = motionEvent.getX();
            this.downY = motionEvent.getY();
            this.swipeAllowed = (this.active == null || this.active.id == 0) ? false : true;
            EditText[] editTextArr = {this.newIndex, this.confirm, this.comment, this.phone, this.local, this.netEdit, this.urEdit, this.serEdit};
            for (int i = 0; i < 8; i++) {
                EditText editText = editTextArr[i];
                if (editText != null) {
                    Rect rect = new Rect();
                    editText.getGlobalVisibleRect(rect);
                    if (rect.contains((int) motionEvent.getRawX(), (int) motionEvent.getRawY())) {
                        this.swipeAllowed = false;
                    }
                }
            }
        }
        if (motionEvent.getActionMasked() == 1 && this.swipeAllowed && !this.busy && this.active != null) {
            float x = motionEvent.getX() - this.downX;
            float y = motionEvent.getY() - this.downY;
            if (Math.abs(x) > dp(90) && Math.abs(x) > Math.abs(y) * 1.8f) {
                MotionEvent motionEventObtain = MotionEvent.obtain(motionEvent);
                motionEventObtain.setAction(3);
                super.dispatchTouchEvent(motionEventObtain);
                motionEventObtain.recycle();
                navigate(x < 0.0f ? 1 : -1);
                return true;
            }
        }
        return super.dispatchTouchEvent(motionEvent);
    }

    void compactShell(String title) {
        shell(title);
        root.removeAllViews();
        root.setBackgroundColor(0xFFF0FAF3);
        LinearLayout header = new LinearLayout(this);
        Button menu = compactIcon(R.drawable.ic_menu_compact, "Menu principal", () -> mainMenu());
        header.addView(menu, new LinearLayout.LayoutParams(dp(40), -1));
        LinearLayout titles = new LinearLayout(this); titles.setOrientation(1);
        TextView appTitle = text("SmartMobility Terrain", 15, NAVY); appTitle.setTypeface(null,1); appTitle.setPadding(dp(6),0,0,0);
        titles.addView(appTitle);
        TextView heading = text(title, 12, NAVY);formRouteHeading=heading; heading.setMaxLines(1); heading.setPadding(dp(6),0,0,0);
        titles.addView(heading);
        TextView progress = text(filteredProgress(),12,NAVY); progress.setMaxLines(1);progress.setPadding(dp(6),0,0,0);
        progress.setEllipsize(android.text.TextUtils.TruncateAt.END); progress.setContentDescription("Progression de la tournée filtrée");
        titles.addView(progress);
        header.addView(titles,new LinearLayout.LayoutParams(0,-1,1));
        root.addView(header,new LinearLayout.LayoutParams(-1,dp(58)));
        body = new LinearLayout(this); body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(dp(8), 0, dp(8), dp(4));
        root.addView(body, new LinearLayout.LayoutParams(-1, 0, 1));
    }

    Button compactButton(String title, Runnable action) {
        Button button = button(title, action);
        button.setMinHeight(0); button.setMinimumHeight(0);
        button.setMinWidth(0); button.setMinimumWidth(0);
        button.setPadding(dp(4), 0, dp(4), 0); button.setTextSize(14); button.setTypeface(null,android.graphics.Typeface.BOLD);
        button.setBackground(shape(0xFF289B42, 8));
        return button;
    }

    Button compactIcon(int icon, String description, Runnable action) {
        Button button=compactButton("",action);
        android.graphics.drawable.Drawable drawable=getDrawable(icon);
        drawable.setBounds(0,0,dp(24),dp(24));
        button.setCompoundDrawables(null,drawable,null,null);
        button.setGravity(android.view.Gravity.CENTER);
        button.setContentDescription(description);
        return button;
    }

    static int dayCountColor(long days){return days>=29&&days<=31?0xFF228B22:days==28||days==32?0xFFEF8C00:0xFFD32F2F;}

    String oldReadingDate(String value) {
        try {return Model.date(value).format(java.time.format.DateTimeFormatter.ofPattern("dd/MM/uuuu"));}
        catch(Exception ignored){return value;}
    }

    String filteredProgress() {
        List<Store.Record> filtered=records(query,chosenUr,chosenTour,status,0);
        int count=0;
        for(Store.Record row:filtered)if(!row.a[Model.DATE].isEmpty())count++;
        return db.displayName(user)+" • "+count+" / "+filtered.size()+" relevés";
    }

    EditText compactInput(String hint, String value, int type) {
        EditText input = new EditText(this); input.setInputType(type); input.setSingleLine(true);
        input.setText(value); input.setHint(hint); input.setContentDescription(hint);
        input.setTextSize(14); input.setTypeface(null,android.graphics.Typeface.BOLD); input.setPadding(dp(6), 0, dp(6), 0);
        input.setMinHeight(0); input.setMinimumHeight(0); input.setMinimumWidth(0);
        input.setTextColor(NAVY); input.setHintTextColor(GRAY); input.setBackground(inputShape());
        return input;
    }

    void compactRow(View view, float weight) {
        LinearLayout.LayoutParams params=new LinearLayout.LayoutParams(-1,0,weight);
        params.topMargin=dp(4);
        body.addView(view,params);
    }

    void form(final Store.Record record) {
        if (record == null) { home(); return; }
        if (!admin && !record.a[23].equals(user)) { alert("Cette tournée n’est pas affectée à votre profil."); return; }
        stopGps(); indexConfirmation.reset(); active=record; fix=null; capture=""; photoFor=record.a[7];
        if(record.id==0&&!record.a[14].equals("EA")&&!record.a[14].equals("BT"))record.a[14]="BT";
        if(record.id==0)record.a[3]=record.a[3].toUpperCase(Locale.ROOT);
        compactShell("UR " + record.a[3] + " • Tournée " + record.a[15]);
        if (record.id != 0 && !routeIds.contains(record.id)) {
            routeIds.clear();
            for (Store.Record item : db.list(user,admin,"",null,null,null,0)) routeIds.add(item.id);
        }
        LinearLayout summary=new LinearLayout(this);summary.setOrientation(1);
        TextView client=text(record.id==0?"Nouveau compteur hors liste":record.a[1]+" • "+record.a[2],14,NAVY);
        client.setTypeface(null,android.graphics.Typeface.BOLD);client.setPadding(0,0,0,0);client.setSingleLine(true);client.setEllipsize(android.text.TextUtils.TruncateAt.END);
        summary.addView(client,new LinearLayout.LayoutParams(-1,0,1));
        formIdentifierText=null;
        boolean hasIdentifier=!record.a[21].trim().isEmpty();
        if(hasIdentifier){
            formIdentifierText=text(record.a[21],28,NAVY);
            formIdentifierText.setTypeface(null,android.graphics.Typeface.BOLD);
            formIdentifierText.setPadding(0,0,0,0);formIdentifierText.setSingleLine(true);
            formIdentifierText.setEllipsize(android.text.TextUtils.TruncateAt.END);
            formIdentifierText.setContentDescription("Identifiant "+record.a[21]);
            summary.addView(formIdentifierText,new LinearLayout.LayoutParams(-1,0,1.5f));
        }
        String meter="Compteur "+record.a[4]+" • "+record.a[14];
        android.text.SpannableString info=new android.text.SpannableString(meter);
        info.setSpan(new android.text.style.ForegroundColorSpan(record.a[14].equals("BT")?0xFFD32F2F:0xFF087CC1),0,meter.length(),android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        int numberStart="Compteur ".length();
        info.setSpan(new android.text.style.AbsoluteSizeSpan(32,true),numberStart,numberStart+record.a[4].length(),android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        TextView meterText=text("",14,NAVY);formMeterText=meterText;meterText.setText(info);meterText.setTypeface(null,android.graphics.Typeface.BOLD);
        meterText.setPadding(0,0,0,0);meterText.setSingleLine(true);meterText.setEllipsize(android.text.TextUtils.TruncateAt.END);
        summary.addView(meterText,new LinearLayout.LayoutParams(-1,0,1.8f));
        LinearLayout previousRow=new LinearLayout(this);
        TextView previous=text(record.id==0?"Ancien index non renseigné":"Ancien index : "+record.a[6]+" • "+oldReadingDate(record.a[17]),14,NAVY);
        previous.setTypeface(null,android.graphics.Typeface.BOLD);previous.setPadding(0,0,0,0);previous.setSingleLine(true);previous.setEllipsize(android.text.TextUtils.TruncateAt.END);
        previousRow.addView(previous,new LinearLayout.LayoutParams(0,-1,1));
        if(!record.a[17].isEmpty()){
            try{
                long days=java.time.temporal.ChronoUnit.DAYS.between(Model.date(record.a[17]),LocalDate.now());
                TextView dayCount=text(days+"",40,dayCountColor(days));
                dayCount.setTypeface(null,android.graphics.Typeface.BOLD);dayCount.setPadding(dp(4),0,dp(4),0);
                dayCount.setContentDescription(days+" jours depuis l’ancienne relève");
                previousRow.addView(dayCount,new LinearLayout.LayoutParams(-2,-1));
            }catch(RuntimeException ignored){}
        }
        android.widget.ImageView networkIcon=new android.widget.ImageView(this);meterNetworkIcon=networkIcon;
        networkIcon.setImageResource(record.a[14].equals("BT")?R.drawable.ic_electricity:R.drawable.ic_water);
        networkIcon.setContentDescription(record.a[14].equals("BT")?"Compteur électrique":"Compteur d’eau");
        LinearLayout.LayoutParams iconParams=new LinearLayout.LayoutParams(dp(20),-1);iconParams.rightMargin=dp(60);
        previousRow.addView(networkIcon,iconParams);summary.addView(previousRow,new LinearLayout.LayoutParams(-1,0,1.9f));
        summary.setOnClickListener(v -> alert(record.a[1]+"\n"+record.a[2]+"\nCompteur "+record.a[4]+" • "+record.a[14]+"\nUR "+record.a[3]+" • Tournée "+record.a[15]+"\nIdentifiant "+record.a[21]+" • Ancien index "+record.a[6]+"\nAncienne relève "+record.a[17]+"\nTéléphone importé : "+record.a[5]+"\nType local importé : "+record.a[13]));
        compactRow(summary,hasIdentifier?4.1f:(record.id==0?2.6f:2.3f));
        if(record.id==0){
            LinearLayout identification=new LinearLayout(this);
            netEdit=compactInput("Réseau",record.a[14],1); // backing value for restored drafts
            netSelector=new Spinner(this);netSelector.setContentDescription("Réseau du compteur");
            netSelector.setAdapter(compactAdapter(Arrays.asList("BT","EA")));
            netSelector.setSelection(record.a[14].equals("EA")?1:0);
            identification.addView(netSelector,new LinearLayout.LayoutParams(0,-1,1));
            urEdit=compactInput("UR",record.a[3].toUpperCase(Locale.ROOT),android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS);
            urEdit.setFilters(new android.text.InputFilter[]{new android.text.InputFilter.AllCaps()});
            serEdit=compactInput("Compteur",record.a[4],1);
            for(EditText input:new EditText[]{urEdit,serEdit})identification.addView(input,new LinearLayout.LayoutParams(0,-1,1));
            compactRow(identification,1);
            netEdit.addTextChangedListener(watcher(() -> m26lambda$form$17$mareleveterrainMainActivity(record)));
            netSelector.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){
                public void onItemSelected(AdapterView<?> parent,View view,int position,long id){if(active==record)netEdit.setText(position==0?"BT":"EA");}
                public void onNothingSelected(AdapterView<?> parent){}
            });
            urEdit.addTextChangedListener(watcher(()->{record.a[3]=value(urEdit).toUpperCase(Locale.ROOT);formRouteHeading.setText("UR "+record.a[3]+" • Tournée "+record.a[15]);dirty=true;}));
            serEdit.addTextChangedListener(watcher(()->{record.a[4]=value(serEdit);updateMeterDisplay();dirty=true;}));
        }else{netEdit=null;netSelector=null;urEdit=null;serEdit=null;}
        newIndex=compactInput("Index",record.a[7],8194);
        newIndex.setTextSize(28);
        newIndex.setImeOptions(android.view.inputmethod.EditorInfo.IME_ACTION_DONE);
        calculation=text("",14,NAVY); confirm=new EditText(this);
        LinearLayout indexRow=new LinearLayout(this);
        indexRow.addView(newIndex,new LinearLayout.LayoutParams(0,-1,1));
        Button camera=compactIcon(R.drawable.ic_camera_compact,"Prendre une photo",() -> takePhoto());camera.setContentDescription("Prendre une photo");
        Button view=compactIcon(R.drawable.ic_gallery_compact,"Consulter la photo",() -> viewPhoto());view.setContentDescription("Consulter la photo");
        LinearLayout.LayoutParams cameraParams=new LinearLayout.LayoutParams(dp(44),-1);cameraParams.leftMargin=dp(4);
        LinearLayout.LayoutParams viewParams=new LinearLayout.LayoutParams(dp(44),-1);viewParams.leftMargin=dp(4);
        indexRow.addView(camera,cameraParams);indexRow.addView(view,viewParams);
        compactRow(indexRow,1.25f);
        anomaly=new Spinner(this);outline(anomaly);compactRow(anomaly,1);
        comment=compactInput("Commentaire",record.a[9],131073);compactRow(comment,1);
        phone=compactInput("Téléphone",record.a[38].isEmpty()?record.a[5]:record.a[38],3);
        local=new EditText(this);local.setText(record.a[39].isEmpty()?record.a[13]:record.a[39]);
        LinearLayout contact=new LinearLayout(this);
        contact.addView(phone,new LinearLayout.LayoutParams(0,-1,1));
        Button editPhone=compactIcon(R.drawable.ic_pen_compact,"Modifier le téléphone",() -> {phone.requestFocus();phone.selectAll();});editPhone.setContentDescription("Modifier le téléphone");
        editPhone.setBackgroundColor(android.graphics.Color.TRANSPARENT);
        contact.addView(editPhone,new LinearLayout.LayoutParams(dp(32),-1));
        List<String> typeValues=new ArrayList<>(),typeLabels=new ArrayList<>();
        typeValues.add(value(local));typeLabels.add(value(local).isEmpty()?"Type local":value(local));
        List<String[]> catalog=db.typeRows();
        for(String[] type:catalog.subList(1,catalog.size()))if(!typeValues.contains(type[0])){typeValues.add(type[0]);typeLabels.add(type[0]+" — "+type[1]);}
        typeSelector=new Spinner(this);typeSelector.setContentDescription("Type local");
        typeSelector.setAdapter(compactAdapter(typeLabels));typeSelector.setTag(typeValues);
        contact.addView(typeSelector,new LinearLayout.LayoutParams(0,-1,1));compactRow(contact,1);
        typeSelector.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){
            public void onItemSelected(AdapterView<?> parent,View view,int position,long id){if(!value(local).equals(typeValues.get(position)))local.setText(typeValues.get(position));}
            public void onNothingSelected(AdapterView<?> parent){}
        });
        repeat=new CheckBox(this);repeat.setChecked(record.a[28].equals("A_REPASSER"));
        photoText=text("",13,GRAY);gpsText=text("",13,GRAY);
        compactRow(compactButton("Valider la relève",() -> attemptSave()),1);
        dirty=false;
        newIndex.addTextChangedListener(watcher(() -> m28lambda$form$19$mareleveterrainMainActivity()));
        for(EditText input:new EditText[]{confirm,comment,phone,local})input.addTextChangedListener(watcher(() -> m29lambda$form$20$mareleveterrainMainActivity()));
        repeat.setOnCheckedChangeListener((button,checked) -> dirty=true);
        newIndex.setOnEditorActionListener((v,action,event) -> {
            if(action==android.view.inputmethod.EditorInfo.IME_ACTION_DONE){
                if(ensureIndexConfirmed() && requiredPhoto(result()) && (active.a[27].isEmpty() || !photoFor.equals(value(newIndex))))takePhoto();
                return true;
            }
            return false;
        });
        updateRules();chooseCode(record.a[8]);
    }

    ArrayAdapter<String> compactAdapter(List<String> values) {
        return new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,values){
            @Override public View getView(int position,View view,android.view.ViewGroup parent){
                TextView label=(TextView)super.getView(position,view,parent);
                label.setTextSize(14);label.setTypeface(null,android.graphics.Typeface.BOLD);label.setSingleLine(true);label.setEllipsize(android.text.TextUtils.TruncateAt.END);
                label.setPadding(dp(6),0,dp(6),0);label.setMinHeight(0);label.setMinimumHeight(0);
                return label;
            }
        };
    }

    /* renamed from: lambda$form$15$ma-releve-terrain-MainActivity, reason: not valid java name */
    /* synthetic */ void m24lambda$form$15$mareleveterrainMainActivity() {
        navigate(-1);
    }

    /* renamed from: lambda$form$16$ma-releve-terrain-MainActivity, reason: not valid java name */
    /* synthetic */ void m25lambda$form$16$mareleveterrainMainActivity() {
        navigate(1);
    }

    /* renamed from: lambda$form$17$ma-releve-terrain-MainActivity, reason: not valid java name */
    /* synthetic */ void m26lambda$form$17$mareleveterrainMainActivity(Store.Record record) {
        record.a[14] = value(this.netEdit).toUpperCase(Locale.ROOT);
        updateRules();
    }

    /* renamed from: lambda$form$18$ma-releve-terrain-MainActivity, reason: not valid java name */
    /* synthetic */ void m27lambda$form$18$mareleveterrainMainActivity() {
        acquire(false);
    }

    /* renamed from: lambda$form$19$ma-releve-terrain-MainActivity, reason: not valid java name */
    /* synthetic */ void m28lambda$form$19$mareleveterrainMainActivity() {
        this.dirty = true;
        if (!this.internalIndexChange) {
            this.indexConfirmation.edited(value(this.newIndex));
            this.confirm.setText(this.indexConfirmation.confirmed ? this.indexConfirmation.first : "");
            this.photoFor = "";
        }
        updateRules();
    }

    /* renamed from: lambda$form$20$ma-releve-terrain-MainActivity, reason: not valid java name */
    /* synthetic */ void m29lambda$form$20$mareleveterrainMainActivity() {
        this.dirty = true;
    }

    /* renamed from: lambda$form$21$ma-releve-terrain-MainActivity, reason: not valid java name */
    /* synthetic */ void m30lambda$form$21$mareleveterrainMainActivity(CompoundButton compoundButton, boolean z) {
        this.dirty = true;
    }

    Store.Anomaly selected() {
        int selectedItemPosition = this.anomaly == null ? -1 : this.anomaly.getSelectedItemPosition() - 1;
        if (this.anomaly != null && this.anomaly.getSelectedItemPosition() - 1 >= 0 && selectedItemPosition < this.choices.size()) {
            return this.choices.get(selectedItemPosition);
        }
        return null;
    }

    void chooseCode(String str) {
        for (int i = 0; i < this.choices.size(); i++) {
            if (this.choices.get(i).code.equals(str)) {
                this.anomaly.setSelection(i + 1);
                return;
            }
        }
    }

    Model.Result result() {
        return Model.assess(this.active.a, this.indexConfirmation.pending() && value(this.newIndex).isEmpty() ? this.indexConfirmation.first : value(this.newIndex), LocalDate.now());
    }

    boolean usesOutsideCatalog() {
        return active!=null&&(active.id==0||"Hors liste".equals(active.a[16]));
    }

    void updateMeterDisplay() {
        if(active==null||formMeterText==null||meterNetworkIcon==null)return;
        String text="Compteur "+active.a[4]+" • "+active.a[14];
        android.text.SpannableString styled=new android.text.SpannableString(text);
        styled.setSpan(new android.text.style.ForegroundColorSpan(active.a[14].equals("BT")?0xFFD32F2F:0xFF087CC1),0,text.length(),android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        if(!active.a[4].isEmpty())styled.setSpan(new android.text.style.AbsoluteSizeSpan(32,true),9,9+active.a[4].length(),android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        formMeterText.setText(styled);
        meterNetworkIcon.setImageResource(active.a[14].equals("BT")?R.drawable.ic_electricity:R.drawable.ic_water);
        meterNetworkIcon.setContentDescription(active.a[14].equals("BT")?"Compteur électrique":"Compteur d’eau");
    }

    void updateRules() {
        updateMeterDisplay();
        String str;
        if (this.active == null || this.anomaly == null || this.newIndex == null || this.calculation == null) {
            return;
        }
        String str2 = selected() == null ? "" : selected().code;
        Model.Result result = result();
        TextView textView = this.calculation;
        if (result.error.isEmpty()) {
            str = "Cas : " + result.cas + (result.cons == null ? "" : " • Consommation : " + Model.decimal(result.cons)) + (result.cmj == null ? "" : "\n" + result.days + " jours • CMJ : " + Model.decimal(result.cmj)) + (result.abnormal ? "\n⚠ " + result.reason + " Double saisie puis photo obligatoires." : "");
        } else {
            str = result.error;
        }
        textView.setText(str);
        textView.setTextColor(!result.error.isEmpty()?0xFFD9534F:result.abnormal?0xFFE6A23C:NAVY);
        this.confirm.setVisibility(View.GONE);
        this.choices = this.db.anomalies(this.active.a[14], usesOutsideCatalog() ? null : result.cas);
        ArrayList arrayList = new ArrayList();
        arrayList.add("Choisir une anomalie / aucune");
        Iterator<Store.Anomaly> it = this.choices.iterator();
        while (it.hasNext()) {
            arrayList.add(it.next().toString());
        }
        this.anomaly.setAdapter((SpinnerAdapter) compactAdapter(arrayList));
        chooseCode(str2);
        this.anomaly.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() { // from class: ma.releve.terrain.v320.MainActivity.4
            boolean initial = true;

            @Override // android.widget.AdapterView.OnItemSelectedListener
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long j) {
                if (this.initial) {
                    this.initial = false;
                    return;
                }
                Store.Anomaly anomalySelected = MainActivity.this.selected();
                if (anomalySelected != null && anomalySelected.repeat) {
                    MainActivity.this.repeat.setChecked(true);
                }
                MainActivity.this.dirty = true;
            }

            @Override // android.widget.AdapterView.OnItemSelectedListener
            public void onNothingSelected(AdapterView<?> adapterView) {
            }
        });
    }

    boolean confirmation(Model.Result result) {
        return !result.abnormal || (Model.numeric(value(this.confirm)) && Model.num(value(this.confirm)).compareTo(Model.num(value(this.newIndex))) == 0);
    }

    boolean requiredPhoto(Model.Result result) {
        Store.Anomaly anomalySelected = selected();
        return result.photo || (anomalySelected != null && anomalySelected.photo);
    }

    void takePhoto() {
        if (this.active != null && !ensureIndexConfirmed()) return;
        String str;
        if (this.active == null) {
            return;
        }
        Model.Result result = result();
        if (!result.error.isEmpty()) {
            str = result.error;
        } else if (!confirmation(result)) {
            str = "Ressaisissez d’abord le même index anormal, puis prenez la photo.";
        } else {
            if (this.active.id != 0 || !value(this.serEdit).isEmpty()) {
                this.capture = Exchange.safe(this.active.a[0].isEmpty() ? "COMPTEUR_" + value(this.serEdit) : this.active.a[0]) + "_" + new SimpleDateFormat("ddMMyyyyHHmmss", Locale.US).format(new Date()) + "_" + UUID.randomUUID().toString().substring(0, 6) + ".jpg";
                Uri uri = Uri.parse("content://ma.releve.terrain.v320.photos/" + this.capture);
                Intent intent = new Intent("android.media.action.IMAGE_CAPTURE");
                intent.putExtra("output", uri);
                intent.setClipData(ClipData.newRawUri("photo", uri));
                intent.addFlags(3);
                this.photoFor = value(this.newIndex);
                try {
                    startActivityForResult(intent, 40);
                    return;
                } catch (ActivityNotFoundException e) {
                    this.capture = "";
                    alert("Application appareil photo absente.");
                    return;
                }
            }
            str = "Renseignez le numéro compteur.";
        }
        alert(str);
    }

    void viewPhoto() {
        if (this.active == null || this.active.a[27].isEmpty()) {
            alert("Aucune photo enregistrée.");
            return;
        }
        Intent intent = new Intent("android.intent.action.VIEW");
        intent.setDataAndType(Uri.parse("content://ma.releve.terrain.v320.photos/" + this.active.a[27]), "image/jpeg");
        intent.addFlags(1);
        try {
            startActivity(intent);
        } catch (Exception e) {
            alert("Aucune visionneuse photo disponible.");
        }
    }

    String validate() {
        if (this.active.id == 0) {
            String upperCase = value(this.netEdit).toUpperCase(Locale.ROOT);
            if (!upperCase.equals("EA") && !upperCase.equals("BT")) {
                return "Réseau EA ou BT obligatoire.";
            }
            if (value(this.urEdit).isEmpty() || value(this.serEdit).isEmpty()) {
                return "UR et numéro compteur obligatoires.";
            }
            this.active.a[14] = upperCase;
            this.active.a[3] = value(this.urEdit).toUpperCase(Locale.ROOT);
            this.active.a[4] = value(this.serEdit);
        }
        if (!this.active.a[14].equals("EA") && !this.active.a[14].equals("BT")) {
            return "Réseau absent : l’administrateur doit compléter les données importées.";
        }
        Model.Result result = result();
        if (!result.error.isEmpty()) {
            return result.error;
        }
        Store.Anomaly anomalySelected = selected();
        if ((result.cas.equals("SANS_INDEX") || result.cas.equals("NEGATIF") || usesOutsideCatalog()) && anomalySelected == null) {
            return "Sélectionnez une anomalie dans la liste " + result.cas + ".";
        }
        if (anomalySelected != null && (!Model.contains(anomalySelected.nets, this.active.a[14]) || (!usesOutsideCatalog() && !Model.contains(anomalySelected.cases, result.cas)))) {
            return "Anomalie incompatible avec le réseau ou la consommation.";
        }
        if (result.abnormal && !confirmation(result)) {
            return "La deuxième saisie doit être identique au nouvel index.";
        }
        if (result.cas.equals("NEGATIF") && value(this.comment).isEmpty()) {
            return "Commentaire justificatif obligatoire pour un index inférieur.";
        }
        if (!requiredPhoto(result)) {
            return null;
        }
        if (this.active.a[27].isEmpty()) {
            return "Photo du compteur obligatoire.";
        }
        try {
            if (!Exchange.photo(this, this.active.a[27]).isFile()) {
                return "Photo manquante : reprendre une photo.";
            }
            if (this.photoFor.equals(value(this.newIndex))) {
                return null;
            }
            return "L’index a changé : prendre une nouvelle photo après la confirmation.";
        } catch (Exception e) {
            return "Photo invalide.";
        }
    }

    void attemptSave() {
        if (!ensureIndexConfirmed()) return;
        if (requiredPhoto(result()) && (this.active.a[27].isEmpty() || !this.photoFor.equals(value(this.newIndex)))) {
            takePhoto();
            return;
        }
        String strValidate = validate();
        if (strValidate != null) {
            alert(strValidate);
        } else {
            this.fix = null;
            acquire(true);
        }
    }

    void commit() {
        int i;
        Store.Record record;
        String strValidate = validate();
        if (strValidate != null) {
            alert(strValidate);
            return;
        }
        Model.Result result = result();
        Store.Record record2 = this.active;
        Store.Anomaly anomalySelected = selected();
        record2.a[7] = value(this.newIndex).replace(',', '.');
        record2.a[8] = anomalySelected == null ? "" : anomalySelected.code;
        record2.a[9] = value(this.comment);
        record2.a[38] = value(this.phone).equals(record2.a[5]) ? "" : value(this.phone);
        record2.a[39] = value(this.local).equals(record2.a[13]) ? "" : value(this.local);
        record2.a[10] = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss", Locale.FRANCE).format(new Date());
        record2.a[35] = OffsetDateTime.now().toString();
        record2.a[32] = "" + System.currentTimeMillis();
        record2.a[11] = this.fix == null ? "" : String.format(Locale.US, "%.7f", Double.valueOf(this.fix.getLongitude()));
        record2.a[12] = this.fix == null ? "" : String.format(Locale.US, "%.7f", Double.valueOf(this.fix.getLatitude()));
        record2.a[37] = this.fix == null ? "" : String.format(Locale.US, "%.0f", Float.valueOf(this.fix.getAccuracy()));
        record2.a[24] = result.cons == null ? "" : Model.decimal(result.cons);
        record2.a[25] = result.days <= 0 ? "" : "" + result.days;
        record2.a[26] = result.cmj == null ? "" : Model.decimal(result.cmj);
        record2.a[33] = result.abnormal ? value(this.confirm) : "";
        record2.a[40] = this.user;
        record2.a[41] = this.db.displayName(this.user);
        record2.a[28] = this.repeat.isChecked() ? "A_REPASSER" : record2.a[0].isEmpty() ? "NOUVEAU_COMPTEUR" : record2.a[7].isEmpty() ? "NON_RELEVE" : "RELEVE";
        if (!record2.a[10].isEmpty() && record2.id != 0 && (record = this.db.get(record2.id)) != null && !record.a[10].isEmpty()) {
            record2.a[34] = "" + (Integer.parseInt(record.a[34].isEmpty() ? "1" : record.a[34]) + 1);
        }
        try {
            this.db.save(record2, this.user);
            toast("Relève enregistrée localement");
            this.dirty = false;
            int iIndexOf = this.routeIds.indexOf(Long.valueOf(record2.id));
            if (iIndexOf >= 0 && (i = iIndexOf + 1) < this.routeIds.size()) {
                form(this.db.get(this.routeIds.get(i).longValue()));
            } else if (iIndexOf >= 0) {
                form(this.db.get(record2.id));
                this.dirty = false;
                alert("Dernier compteur de cette sélection. Vous pouvez revenir au précédent ou à la liste.");
            } else {
                home();
            }
            maybeAuto();
        } catch (Exception e) {
            alert("Enregistrement impossible : " + e.getMessage());
        }
    }

    void acquire(boolean z) {
        if (this.active == null) {
            return;
        }
        this.saveAfterGps = z;
        if (checkSelfPermission("android.permission.ACCESS_FINE_LOCATION") == 0 || checkSelfPermission("android.permission.ACCESS_COARSE_LOCATION") == 0) {
            startGps();
        } else {
            requestPermissions(new String[]{"android.permission.ACCESS_FINE_LOCATION", "android.permission.ACCESS_COARSE_LOCATION"}, 44);
        }
    }

    @Override // android.app.Activity
    public void onRequestPermissionsResult(int i, String[] strArr, int[] iArr) {
        super.onRequestPermissionsResult(i, strArr, iArr);
        if (i == 44) {
            if (checkSelfPermission("android.permission.ACCESS_FINE_LOCATION") == 0 || checkSelfPermission("android.permission.ACCESS_COARSE_LOCATION") == 0) {
                startGps();
            } else {
                gpsFailed("Localisation refusée.");
            }
        }
    }

    /* renamed from: lambda$startGps$22$ma-releve-terrain-MainActivity, reason: not valid java name */
    /* synthetic */ void m73lambda$startGps$22$mareleveterrainMainActivity() {
        gpsFailed("Position non obtenue. Réessayez à l’extérieur.");
    }

    void startGps() {
        boolean z = this.saveAfterGps;
        stopGps();
        this.saveAfterGps = z;
        this.fix = null;
        this.busy = true;
        this.gpsStarted = SystemClock.elapsedRealtimeNanos();
        this.gpsText.setText("Recherche GPS (20 secondes)…");
        this.listener = new LocationListener() { // from class: ma.releve.terrain.v320.MainActivity.5
            @Override // android.location.LocationListener
            public void onLocationChanged(Location location) {
                if (MainActivity.this.active == null || location.getElapsedRealtimeNanos() < MainActivity.this.gpsStarted) {
                    return;
                }
                MainActivity.this.fix = location;
                MainActivity.this.gpsText.setText(String.format(Locale.US, "X %.7f / Y %.7f • précision %.0f m", Double.valueOf(location.getLongitude()), Double.valueOf(location.getLatitude()), Float.valueOf(location.getAccuracy())));
                boolean z2 = MainActivity.this.saveAfterGps;
                MainActivity.this.stopGps();
                MainActivity.this.busy = false;
                if (z2) {
                    MainActivity.this.commit();
                }
            }

            @Override // android.location.LocationListener
            public void onProviderDisabled(String str) {
            }

            @Override // android.location.LocationListener
            public void onProviderEnabled(String str) {
            }

            @Override // android.location.LocationListener
            public void onStatusChanged(String str, int i, Bundle bundle) {
            }
        };
        String[] strArr = {"gps", "network"};
        boolean z2 = false;
        for (int i = 0; i < 2; i++) {
            String str = strArr[i];
            try {
                if (this.lm.isProviderEnabled(str)) {
                    this.lm.requestLocationUpdates(str, 0L, 0.0f, this.listener, Looper.getMainLooper());
                    z2 = true;
                }
            } catch (Exception e) {
            }
        }
        if (!z2) {
            gpsFailed("Activez le GPS et autorisez la position précise.");
        } else {
            this.gpsTimeout = new Runnable() { // from class: ma.releve.terrain.v320.MainActivity$$ExternalSyntheticLambda63
                @Override // java.lang.Runnable
                public final void run() {
                    MainActivity.this.m73lambda$startGps$22$mareleveterrainMainActivity();
                }
            };
            this.handler.postDelayed(this.gpsTimeout, 20000L);
        }
    }

    void stopGps() {
        if (this.listener != null) {
            try {
                this.lm.removeUpdates(this.listener);
            } catch (Exception e) {
            }
            this.listener = null;
        }
        if (this.gpsTimeout != null) {
            this.handler.removeCallbacks(this.gpsTimeout);
            this.gpsTimeout = null;
        }
        this.saveAfterGps = false;
    }

    void gpsFailed(String str) {
        boolean z = this.saveAfterGps;
        stopGps();
        this.busy = false;
        this.fix = null;
        if (this.gpsText != null) {
            this.gpsText.setText(str);
        }
        if (!z || this.active == null) {
            alert(str);
        } else {
            new AlertDialog.Builder(this).setTitle("GPS indisponible").setMessage(str + "\nEnregistrer sans coordonnées GPS ?").setNegativeButton("Réessayer", new DialogInterface.OnClickListener() { // from class: ma.releve.terrain.v320.MainActivity$$ExternalSyntheticLambda81
                @Override // android.content.DialogInterface.OnClickListener
                public final void onClick(DialogInterface dialogInterface, int i) {
                    MainActivity.this.m31lambda$gpsFailed$23$mareleveterrainMainActivity(dialogInterface, i);
                }
            }).setNeutralButton("Annuler", (DialogInterface.OnClickListener) null).setPositiveButton("Sans GPS", new DialogInterface.OnClickListener() { // from class: ma.releve.terrain.v320.MainActivity$$ExternalSyntheticLambda82
                @Override // android.content.DialogInterface.OnClickListener
                public final void onClick(DialogInterface dialogInterface, int i) {
                    MainActivity.this.m32lambda$gpsFailed$24$mareleveterrainMainActivity(dialogInterface, i);
                }
            }).show();
        }
    }

    /* renamed from: lambda$gpsFailed$23$ma-releve-terrain-MainActivity, reason: not valid java name */
    /* synthetic */ void m31lambda$gpsFailed$23$mareleveterrainMainActivity(DialogInterface dialogInterface, int i) {
        acquire(true);
    }

    /* renamed from: lambda$gpsFailed$24$ma-releve-terrain-MainActivity, reason: not valid java name */
    /* synthetic */ void m32lambda$gpsFailed$24$mareleveterrainMainActivity(DialogInterface dialogInterface, int i) {
        commit();
    }

    /* renamed from: lambda$leave$25$ma-releve-terrain-MainActivity, reason: not valid java name */
    /* synthetic */ void m40lambda$leave$25$mareleveterrainMainActivity(DialogInterface dialogInterface, int i) {
        home();
    }

    void leave() {
        if (this.busy) {
            return;
        }
        if (this.dirty) {
            new AlertDialog.Builder(this).setTitle("Saisie non enregistrée").setMessage("Abandonner les modifications ?").setNegativeButton("Continuer", (DialogInterface.OnClickListener) null).setPositiveButton("Abandonner", new DialogInterface.OnClickListener() { // from class: ma.releve.terrain.v320.MainActivity$$ExternalSyntheticLambda14
                @Override // android.content.DialogInterface.OnClickListener
                public final void onClick(DialogInterface dialogInterface, int i) {
                    MainActivity.this.m40lambda$leave$25$mareleveterrainMainActivity(dialogInterface, i);
                }
            }).show();
        } else {
            home();
        }
    }

    @Override // android.app.Activity
    public void onBackPressed() {
        if (this.busy) {
            return;
        }
        if (this.active != null) {
            leave();
        } else if (this.user.isEmpty()) {
            super.onBackPressed();
        } else {
            home();
        }
    }

    void async(final Job job, final Done done, final Done done2) {
        this.busy = true;
        this.worker.execute(new Runnable() { // from class: ma.releve.terrain.v320.MainActivity$$ExternalSyntheticLambda12
            @Override // java.lang.Runnable
            public final void run() {
                MainActivity.this.m11lambda$async$28$mareleveterrainMainActivity(job, done, done2);
            }
        });
    }

    /* renamed from: lambda$async$26$ma-releve-terrain-MainActivity, reason: not valid java name */
    /* synthetic */ void m9lambda$async$26$mareleveterrainMainActivity(Done done, String str) {
        if (isDestroyed()) {
            return;
        }
        this.busy = false;
        done.result(str);
    }

    /* renamed from: lambda$async$27$ma-releve-terrain-MainActivity, reason: not valid java name */
    /* synthetic */ void m10lambda$async$27$mareleveterrainMainActivity(Done done, String str) {
        if (isDestroyed()) {
            return;
        }
        this.busy = false;
        done.result(str);
    }

    /* renamed from: lambda$async$28$ma-releve-terrain-MainActivity, reason: not valid java name */
    /* synthetic */ void m11lambda$async$28$mareleveterrainMainActivity(Job job, final Done done, final Done done2) {
        try {
            final String strRun = job.run();
            runOnUiThread(new Runnable() { // from class: ma.releve.terrain.v320.MainActivity$$ExternalSyntheticLambda21
                @Override // java.lang.Runnable
                public final void run() {
                    MainActivity.this.m9lambda$async$26$mareleveterrainMainActivity(done, strRun);
                }
            });
        } catch (Exception e) {
            final String simpleName = e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage();
            runOnUiThread(new Runnable() { // from class: ma.releve.terrain.v320.MainActivity$$ExternalSyntheticLambda22
                @Override // java.lang.Runnable
                public final void run() {
                    MainActivity.this.m10lambda$async$27$mareleveterrainMainActivity(done2, simpleName);
                }
            });
        }
    }

    void async(Job job) {
        async(job, new Done() { // from class: ma.releve.terrain.v320.MainActivity$$ExternalSyntheticLambda88
            @Override // ma.releve.terrain.v320.MainActivity.Done
            public final void result(String str) {
                MainActivity.this.m12lambda$async$29$mareleveterrainMainActivity(str);
            }
        }, new MainActivity$$ExternalSyntheticLambda5(this));
    }

    /* renamed from: lambda$async$29$ma-releve-terrain-MainActivity, reason: not valid java name */
    /* synthetic */ void m12lambda$async$29$mareleveterrainMainActivity(String str) {
        home();
        alert(str);
    }

    void exportMenu() {
        new AlertDialog.Builder(this).setTitle("Format d’export").setItems(new String[]{"Excel XLSX", "CSV UTF-8", "Archive XLSX + CSV + photos"}, new DialogInterface.OnClickListener() { // from class: ma.releve.terrain.v320.MainActivity$$ExternalSyntheticLambda11
            @Override // android.content.DialogInterface.OnClickListener
            public final void onClick(DialogInterface dialogInterface, int i) {
                MainActivity.this.m23lambda$exportMenu$30$mareleveterrainMainActivity(dialogInterface, i);
            }
        }).show();
    }

    /* renamed from: lambda$exportMenu$30$ma-releve-terrain-MainActivity, reason: not valid java name */
    /* synthetic */ void m23lambda$exportMenu$30$mareleveterrainMainActivity(DialogInterface dialogInterface, int i) {
        this.exportFormat = i == 0 ? "xlsx" : i == 1 ? "csv" : "zip";
        pick(11);
    }

    String baseName() {
        List<String> listDistinct = this.db.distinct("produit", this.user, this.admin);
        return Exchange.safe(this.user) + "_" + Exchange.safe(listDistinct.size() == 1 ? listDistinct.get(0) : campaign());
    }

    void pick(int i) {
        String strBaseName;
        boolean z = i == 11 || i == 12 || i == 22 || i == 23;
        Intent intent = new Intent(z ? "android.intent.action.CREATE_DOCUMENT" : "android.intent.action.OPEN_DOCUMENT");
        intent.addCategory("android.intent.category.OPENABLE");
        String str = i == 11 ? this.exportFormat : "xlsx";
        intent.setType(z ? str.equals("xlsx") ? "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" : str.equals("csv") ? "text/csv" : "application/zip" : "*/*");
        if (z) {
            StringBuilder sb = new StringBuilder();
            if (i == 12) {
                strBaseName = "Modele_SmartMobilityTerrain_5.1.0";
            } else if (i == 22) {
                strBaseName = "Catalogue_anomalies";
            } else {
                strBaseName = i == 23 ? "Historique" : baseName();
            }
            intent.putExtra("android.intent.extra.TITLE", sb.append(strBaseName).append(".").append(str).toString());
        }
        startActivityForResult(intent, i);
    }

    @Override // android.app.Activity
    protected void onActivityResult(final int i, int i2, Intent intent) {
        super.onActivityResult(i, i2, intent);
        if (i == 40) {
            if (i2 != -1) {
                if (!this.capture.isEmpty()) {
                    try {
                        Exchange.photo(this, this.capture).delete();
                    } catch (Exception e) {
                    }
                }
                this.capture = "";
                return;
            } else if (this.active == null) {
                alert("Reconnectez-vous pour reprendre la saisie photo.");
                return;
            } else {
                processPhoto(this.capture);
                return;
            }
        }
        if(i2 == RESULT_OK && intent != null && i == 52 && intent.getClipData() != null) {
            ClipData selected=intent.getClipData();
            loadTour(() -> {
                java.util.Map<String,byte[]> entries=new java.util.LinkedHashMap<>();
                for(int item=0;item<selected.getItemCount();item++) {
                    Uri uri=selected.getItemAt(item).getUri();String name;
                    try(android.database.Cursor c=getContentResolver().query(uri,new String[]{android.provider.OpenableColumns.DISPLAY_NAME},null,null,null)) {
                        if(c==null||!c.moveToFirst())throw new IOException("Nom du fichier inaccessible");name=c.getString(0);
                    }
                    if(!Arrays.asList("Releve.csv","Anomalie.csv","type_local.csv").contains(name)||entries.containsKey(name))throw new IOException("Sélectionnez les trois CSV aux noms exacts");
                    entries.put(name,m54lambda$onActivityResult$31$mareleveterrainMainActivity(uri));
                }
                return BundleImport.zip(entries);
            },this.user);return;
        }
        if(i2 == RESULT_OK && intent != null && i == 52) {alert("Sélectionnez ensemble les trois fichiers CSV.");return;}
        if (i2 != -1 || intent == null || intent.getData() == null) {
            return;
        }
        final Uri data = intent.getData();
        if (i == 50) {
            loadTour(new BytesJob() { // from class: ma.releve.terrain.v320.MainActivity$$ExternalSyntheticLambda23
                @Override // ma.releve.terrain.v320.MainActivity.BytesJob
                public final byte[] run() throws Exception {
                    return MainActivity.this.m54lambda$onActivityResult$31$mareleveterrainMainActivity(data);
                }
            }, this.user);
            return;
        }
        if (i == 51) {
            final File file = this.selectedArchive;
            async(new Job() { // from class: ma.releve.terrain.v320.MainActivity$$ExternalSyntheticLambda24
                @Override // ma.releve.terrain.v320.MainActivity.Job
                public final String run() throws Exception {
                    return MainActivity.this.m55lambda$onActivityResult$32$mareleveterrainMainActivity(file, data);
                }
            });
        } else if (i != 30) {
            final long jRevision = this.db.revision();
            final String str = this.exportFormat;
            async(new Job() { // from class: ma.releve.terrain.v320.MainActivity$$ExternalSyntheticLambda25
                @Override // ma.releve.terrain.v320.MainActivity.Job
                public final String run() throws Exception {
                    return MainActivity.this.m56lambda$onActivityResult$33$mareleveterrainMainActivity(i, data, str, jRevision);
                }
            });
        } else {
            try {
                getContentResolver().takePersistableUriPermission(data, intent.getFlags() & 3);
                getSharedPreferences("sync", 0).edit().putString("tree", data.toString()).apply();
                alert("Dossier sélectionné. Drive est utilisable si son fournisseur propose un dossier accessible.");
            } catch (Exception e2) {
                alert("Accès au dossier impossible.");
            }
        }
    }

    /* renamed from: lambda$onActivityResult$31$ma-releve-terrain-MainActivity, reason: not valid java name */
    /* synthetic */ byte[] m54lambda$onActivityResult$31$mareleveterrainMainActivity(Uri uri) throws Exception {
        InputStream inputStreamOpenInputStream = getContentResolver().openInputStream(uri);
        try {
            if (inputStreamOpenInputStream == null) {
                throw new IOException("Fichier inaccessible.");
            }
            byte[] bArrLimited = TableFile.limited(inputStreamOpenInputStream, DirectDrive.LIMIT);
            if (inputStreamOpenInputStream != null) {
                inputStreamOpenInputStream.close();
            }
            return bArrLimited;
        } catch (Throwable th) {
            if (inputStreamOpenInputStream != null) {
                try {
                    inputStreamOpenInputStream.close();
                } catch (Throwable th2) {
                    th.addSuppressed(th2);
                }
            }
            throw th;
        }
    }

    /* renamed from: lambda$onActivityResult$32$ma-releve-terrain-MainActivity, reason: not valid java name */
    /* synthetic */ String m55lambda$onActivityResult$32$mareleveterrainMainActivity(File file, Uri uri) throws Exception {
        if (file == null) {
            throw new IOException("Sauvegarde non sélectionnée.");
        }
        FileInputStream fileInputStream = new FileInputStream(file);
        try {
            OutputStream outputStreamOpenOutputStream = getContentResolver().openOutputStream(uri, "wt");
            try {
                if (outputStreamOpenOutputStream == null) {
                    throw new IOException("Destination inaccessible.");
                }
                byte[] bArr = new byte[8192];
                while (true) {
                    int i = fileInputStream.read(bArr);
                    if (i == -1) {
                        break;
                    }
                    outputStreamOpenOutputStream.write(bArr, 0, i);
                }
                if (outputStreamOpenOutputStream != null) {
                    outputStreamOpenOutputStream.close();
                }
                fileInputStream.close();
                return "Sauvegarde exportée.";
            } finally {
            }
        } catch (Throwable th) {
            try {
                fileInputStream.close();
            } catch (Throwable th2) {
                th.addSuppressed(th2);
            }
            throw th;
        }
    }

    /* renamed from: lambda$onActivityResult$33$ma-releve-terrain-MainActivity, reason: not valid java name */
    /* synthetic */ String m56lambda$onActivityResult$33$mareleveterrainMainActivity(int i, Uri uri, String str, long j) throws Exception {
        if (i == 10 || i == 21) {
            InputStream inputStreamOpenInputStream = getContentResolver().openInputStream(uri);
            try {
                if (inputStreamOpenInputStream == null) {
                    throw new IOException("Fichier inaccessible.");
                }
                byte[] imported=TableFile.limited(inputStreamOpenInputStream,DirectDrive.LIMIT);
                BundleImport adminBundle=i==10?BundleImport.read(imported,null):null;
                List<String[]> list = i==21?TableFile.read(new java.io.ByteArrayInputStream(imported)):null;
                if (inputStreamOpenInputStream != null) {
                    inputStreamOpenInputStream.close();
                }
                if (i == 21) {
                    this.db.replaceAnomalies(Store.validateAnomalies(list), this.user);
                    return "Catalogue remplacé.";
                }
                if(!this.admin)throw new IOException("Profil administrateur requis.");
                int[] iArrAdd = this.db.addBundle(adminBundle, campaign(), this.user);
                return iArrAdd[0] + " compteurs importés, " + iArrAdd[1] + " existants conservés.";
            } catch (Throwable th) {
                if (inputStreamOpenInputStream != null) {
                    try {
                        inputStreamOpenInputStream.close();
                    } catch (Throwable th2) {
                        th.addSuppressed(th2);
                    }
                }
                throw th;
            }
        }
        List<String[]> listSingletonList = i == 12 ? Collections.singletonList(Model.headers()) : i == 22 ? this.db.anomalyRows() : i == 23 ? this.db.audit() : this.db.export(this.user, this.admin);
        OutputStream outputStreamOpenOutputStream = getContentResolver().openOutputStream(uri, "wt");
        try {
            if (outputStreamOpenOutputStream == null) {
                throw new IOException("Destination inaccessible.");
            }
            if(i==12) {
                try(InputStream template=getAssets().open("Modele_SmartMobilityTerrain_5.1.0.xlsx")) {
                    byte[] b=new byte[8192];int n;while((n=template.read(b))!=-1)outputStreamOpenOutputStream.write(b,0,n);
                }
            } else if (i == 11 && str.equals("zip")) {
                Exchange.zip(this, outputStreamOpenOutputStream, listSingletonList, baseName());
            } else if (i == 11 && str.equals("csv")) {
                TableFile.writeCsv(outputStreamOpenOutputStream, listSingletonList);
            } else {
                TableFile.writeXlsx(outputStreamOpenOutputStream, listSingletonList);
            }
            if (outputStreamOpenOutputStream != null) {
                outputStreamOpenOutputStream.close();
            }
            this.db.log(this.user, "EXPORT", i + " " + (listSingletonList.size() - 1) + " lignes");
            if (i == 11 && this.admin && str.equals("zip")) {
                getPreferences(0).edit().putLong("full_export", j).commit();
            }
            return "Export terminé : " + (listSingletonList.size() - 1) + " lignes.";
        } catch (Throwable th3) {
            if (outputStreamOpenOutputStream != null) {
                try {
                    outputStreamOpenOutputStream.close();
                } catch (Throwable th4) {
                    th3.addSuppressed(th4);
                }
            }
            throw th3;
        }
    }

    void adminGate() {
        LinearLayout linearLayout = new LinearLayout(this);
        linearLayout.setOrientation(1);
        linearLayout.setPadding(dp(20), dp(8), dp(20), dp(8));
        final EditText editText = new EditText(this);
        editText.setHint("Identifiant administrateur");
        if (this.admin) {
            editText.setText(this.user);
        }
        editText.setBackground(inputShape());
        editText.setPadding(dp(12), dp(10), dp(12), dp(10));
        linearLayout.addView(editText);
        final EditText editText2 = new EditText(this);
        editText2.setHint("Mot de passe administrateur");
        editText2.setInputType(129);
        editText2.setBackground(inputShape());
        editText2.setPadding(dp(12), dp(10), dp(12), dp(10));
        linearLayout.addView(editText2);
        new AlertDialog.Builder(this).setTitle("Accès administrateur").setView(linearLayout).setNegativeButton("Annuler", (DialogInterface.OnClickListener) null).setPositiveButton("Ouvrir", new DialogInterface.OnClickListener() { // from class: ma.releve.terrain.v320.MainActivity$$ExternalSyntheticLambda13
            @Override // android.content.DialogInterface.OnClickListener
            public final void onClick(DialogInterface dialogInterface, int i) {
                MainActivity.this.m3lambda$adminGate$37$mareleveterrainMainActivity(editText, editText2, dialogInterface, i);
            }
        }).show();
    }

    /* renamed from: lambda$adminGate$34$ma-releve-terrain-MainActivity, reason: not valid java name */
    /* synthetic */ String m0lambda$adminGate$34$mareleveterrainMainActivity(String str, String str2) throws Exception {
        if ("ADMIN".equals(this.db.login(str, str2))) {
            return str;
        }
        throw new Exception("Compte administrateur ou mot de passe incorrect.");
    }

    /* renamed from: lambda$adminGate$35$ma-releve-terrain-MainActivity, reason: not valid java name */
    /* synthetic */ void m1lambda$adminGate$35$mareleveterrainMainActivity(String str) throws SQLException {
        this.errors = 0;
        this.user = str;
        this.admin = true;
        this.db.log(this.user, "ACCES_ADMIN", "Mot de passe vérifié");
        administration();
    }

    /* renamed from: lambda$adminGate$36$ma-releve-terrain-MainActivity, reason: not valid java name */
    /* synthetic */ void m2lambda$adminGate$36$mareleveterrainMainActivity(String str) {
        this.errors++;
        if (this.errors >= 5) {
            this.blockedUntil = SystemClock.elapsedRealtime() + 30000;
            this.errors = 0;
        }
        alert(str);
    }

    /* renamed from: lambda$adminGate$37$ma-releve-terrain-MainActivity, reason: not valid java name */
    /* synthetic */ void m3lambda$adminGate$37$mareleveterrainMainActivity(EditText editText, EditText editText2, DialogInterface dialogInterface, int i) {
        if (SystemClock.elapsedRealtime() < this.blockedUntil) {
            alert("Réessayez dans 30 secondes.");
            return;
        }
        final String strValue = value(editText);
        final String strValue2 = value(editText2);
        async(new Job() { // from class: ma.releve.terrain.v320.MainActivity$$ExternalSyntheticLambda74
            @Override // ma.releve.terrain.v320.MainActivity.Job
            public final String run() throws Exception {
                return MainActivity.this.m0lambda$adminGate$34$mareleveterrainMainActivity(strValue, strValue2);
            }
        }, new Done() { // from class: ma.releve.terrain.v320.MainActivity$$ExternalSyntheticLambda75
            @Override // ma.releve.terrain.v320.MainActivity.Done
            public final void result(String str) throws SQLException {
                MainActivity.this.m1lambda$adminGate$35$mareleveterrainMainActivity(str);
            }
        }, new Done() { // from class: ma.releve.terrain.v320.MainActivity$$ExternalSyntheticLambda76
            @Override // ma.releve.terrain.v320.MainActivity.Done
            public final void result(String str) {
                MainActivity.this.m2lambda$adminGate$36$mareleveterrainMainActivity(str);
            }
        });
    }

    /* renamed from: lambda$readerNames$38$ma-releve-terrain-MainActivity, reason: not valid java name */
    /* synthetic */ void m59lambda$readerNames$38$mareleveterrainMainActivity(String[] strArr, EditText editText, String str) {
        strArr[0] = str;
        editText.setText(this.db.displayName(str));
    }

    /* renamed from: lambda$readerNames$39$ma-releve-terrain-MainActivity, reason: not valid java name */
    /* synthetic */ void m60lambda$readerNames$39$mareleveterrainMainActivity(String[] strArr, EditText editText) {
        try {
            this.db.rename(strArr[0], value(editText), this.user);
            alert("Nom enregistré. Les prochaines relèves utiliseront ce nom ; les anciennes gardent le nom enregistré à leur date.");
        } catch (Exception e) {
            alert(e.getMessage());
        }
    }

    void readerNames() {
        shell("Noms des releveurs");
        this.body.addView(button("‹ Administration", new MainActivity$$ExternalSyntheticLambda0(this)));
        final String[] strArr = {""};
        final EditText editTextField = field("Nom complet", "");
        selector("Compte", this.db.users(), new Selection() { // from class: ma.releve.terrain.v320.MainActivity$$ExternalSyntheticLambda1
            @Override // ma.releve.terrain.v320.MainActivity.Selection
            public final void choose(String str) {
                MainActivity.this.m59lambda$readerNames$38$mareleveterrainMainActivity(strArr, editTextField, str);
            }
        });
        this.body.addView(button("Enregistrer le nom", new Runnable() { // from class: ma.releve.terrain.v320.MainActivity$$ExternalSyntheticLambda2
            @Override // java.lang.Runnable
            public final void run() {
                MainActivity.this.m60lambda$readerNames$39$mareleveterrainMainActivity(strArr, editTextField);
            }
        }));
    }

    /* renamed from: lambda$processPhoto$40$ma-releve-terrain-MainActivity, reason: not valid java name */
    /* synthetic */ String m57lambda$processPhoto$40$mareleveterrainMainActivity(String str) throws Exception {
        File filePhoto = Exchange.photo(this, str);
        if (!filePhoto.isFile() || filePhoto.length() > 31457280) {
            throw new IOException("Photo absente ou trop volumineuse.");
        }
        BitmapFactory.Options options = new BitmapFactory.Options();
        int i = 1;
        options.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(filePhoto.getAbsolutePath(), options);
        if (options.outWidth <= 0) {
            throw new IOException("Photo non valide.");
        }
        options.inJustDecodeBounds = false;
        while (true) {
            options.inSampleSize = i;
            if (Math.max(options.outWidth, options.outHeight) / options.inSampleSize <= 1600) {
                break;
            }
            i = options.inSampleSize * 2;
        }
        Bitmap bitmapDecodeFile = BitmapFactory.decodeFile(filePhoto.getAbsolutePath(), options);
        if (bitmapDecodeFile == null) {
            throw new IOException("Photo illisible.");
        }
        File file = new File(filePhoto.getParentFile(), str + ".tmp");
        try {
            FileOutputStream fileOutputStream = new FileOutputStream(file);
            try {
                if (!bitmapDecodeFile.compress(Bitmap.CompressFormat.JPEG, 85, fileOutputStream)) {
                    throw new IOException("Compression impossible.");
                }
                fileOutputStream.close();
                bitmapDecodeFile.recycle();
                if (file.renameTo(filePhoto)) {
                    return str;
                }
                throw new IOException("Écriture photo impossible.");
            } finally {
            }
        } catch (Throwable th) {
            bitmapDecodeFile.recycle();
            throw th;
        }
    }

    /* renamed from: lambda$processPhoto$41$ma-releve-terrain-MainActivity, reason: not valid java name */
    /* synthetic */ void m58lambda$processPhoto$41$mareleveterrainMainActivity(String str) {
        this.active.a[27] = str;
        this.photoText.setText("✓ Photo : " + str);
        this.capture = "";
        this.dirty = true;
    }

    void processPhoto(final String str) {
        async(new Job() { // from class: ma.releve.terrain.v320.MainActivity$$ExternalSyntheticLambda69
            @Override // ma.releve.terrain.v320.MainActivity.Job
            public final String run() throws Exception {
                return MainActivity.this.m57lambda$processPhoto$40$mareleveterrainMainActivity(str);
            }
        }, new Done() { // from class: ma.releve.terrain.v320.MainActivity$$ExternalSyntheticLambda70
            @Override // ma.releve.terrain.v320.MainActivity.Done
            public final void result(String str2) {
                MainActivity.this.m58lambda$processPhoto$41$mareleveterrainMainActivity(str2);
            }
        }, new MainActivity$$ExternalSyntheticLambda5(this));
    }

    void administration() {
        if (!this.admin) {
            alert("Profil administrateur requis.");
            return;
        }
        shell("Administration locale • " + this.user);
        this.body.addView(button("Configurer l’envoi Drive",()->driveConfiguration()));
        this.body.addView(button("Purger la base de données",()->purgeScreen()));
        this.body.addView(button("‹ Retour", new MainActivity$$ExternalSyntheticLambda6(this)));
        this.body.addView(button("Modifier mon mot de passe", () -> changePasswordScreen()));
        this.body.addView(button("Importer les compteurs (ajout sans effacer)", new Runnable() { // from class: ma.releve.terrain.v320.MainActivity$$ExternalSyntheticLambda90
            @Override // java.lang.Runnable
            public final void run() {
                MainActivity.this.m4lambda$administration$42$mareleveterrainMainActivity();
            }
        }));
        this.body.addView(button("Modèle d’import", new Runnable() { // from class: ma.releve.terrain.v320.MainActivity$$ExternalSyntheticLambda91
            @Override // java.lang.Runnable
            public final void run() {
                MainActivity.this.m5lambda$administration$43$mareleveterrainMainActivity();
            }
        }));
        this.body.addView(button("Créer un compte releveur", new Runnable() { // from class: ma.releve.terrain.v320.MainActivity$$ExternalSyntheticLambda92
            @Override // java.lang.Runnable
            public final void run() {
                MainActivity.this.createUser();
            }
        }));
        this.body.addView(button("Nommer les releveurs", new Runnable() { // from class: ma.releve.terrain.v320.MainActivity$$ExternalSyntheticLambda93
            @Override // java.lang.Runnable
            public final void run() {
                MainActivity.this.readerNames();
            }
        }));
        this.body.addView(button("Affecter une tournée", new Runnable() { // from class: ma.releve.terrain.v320.MainActivity$$ExternalSyntheticLambda94
            @Override // java.lang.Runnable
            public final void run() {
                MainActivity.this.assignment();
            }
        }));
        this.body.addView(button("Catalogue et contrôles", new Runnable() { // from class: ma.releve.terrain.v320.MainActivity$$ExternalSyntheticLambda95
            @Override // java.lang.Runnable
            public final void run() {
                MainActivity.this.catalogue();
            }
        }));
        this.body.addView(button("Configurer les échanges", new Runnable() { // from class: ma.releve.terrain.v320.MainActivity$$ExternalSyntheticLambda96
            @Override // java.lang.Runnable
            public final void run() {
                MainActivity.this.settings();
            }
        }));
        this.body.addView(button("Exporter l’historique", new Runnable() { // from class: ma.releve.terrain.v320.MainActivity$$ExternalSyntheticLambda97
            @Override // java.lang.Runnable
            public final void run() {
                MainActivity.this.m6lambda$administration$44$mareleveterrainMainActivity();
            }
        }));
        final EditText editTextField = field("Campagne d’import (ex. 2026-10)", campaign());
        this.body.addView(button("Définir la campagne", new Runnable() { // from class: ma.releve.terrain.v320.MainActivity$$ExternalSyntheticLambda98
            @Override // java.lang.Runnable
            public final void run() throws SQLException {
                MainActivity.this.m7lambda$administration$45$mareleveterrainMainActivity(editTextField);
            }
        }));
        this.body.addView(text("L’import administrateur ajoute les contrats absents et conserve les lignes existantes. Pour remplacer votre tournée personnelle, utilisez Ma tournée / Synchroniser avec confirmation explicite.", 13, GRAY));
    }

    /* renamed from: lambda$administration$42$ma-releve-terrain-MainActivity, reason: not valid java name */
    /* synthetic */ void m4lambda$administration$42$mareleveterrainMainActivity() {
        pick(10);
    }

    /* renamed from: lambda$administration$43$ma-releve-terrain-MainActivity, reason: not valid java name */
    /* synthetic */ void m5lambda$administration$43$mareleveterrainMainActivity() {
        pick(12);
    }

    /* renamed from: lambda$administration$44$ma-releve-terrain-MainActivity, reason: not valid java name */
    /* synthetic */ void m6lambda$administration$44$mareleveterrainMainActivity() {
        pick(23);
    }

    /* renamed from: lambda$administration$45$ma-releve-terrain-MainActivity, reason: not valid java name */
    /* synthetic */ void m7lambda$administration$45$mareleveterrainMainActivity(EditText editText) throws SQLException {
        if (value(editText).isEmpty()) {
            alert("Campagne obligatoire.");
            return;
        }
        getPreferences(0).edit().putString("campaign", value(editText)).apply();
        this.db.log(this.user, "CAMPAGNE", value(editText));
        home();
    }

    static /* synthetic */ void lambda$createUser$46(String[] strArr, String str) {
        strArr[0] = str;
    }

    void createUser() {
        shell("Création de compte");
        this.body.addView(button("‹ Administration", new MainActivity$$ExternalSyntheticLambda0(this)));
        final EditText editTextField = field("Identifiant", "");
        final EditText editTextField2 = field("Nom complet du releveur", "");
        final EditText editTextField3 = field("Mot de passe", "", 129, false);
        final String[] strArr = {"RELEVEUR"};
        selector("Profil", Arrays.asList("RELEVEUR", "ADMIN"), new Selection() { // from class: ma.releve.terrain.v320.MainActivity$$ExternalSyntheticLambda47
            @Override // ma.releve.terrain.v320.MainActivity.Selection
            public final void choose(String str) {
                MainActivity.lambda$createUser$46(strArr, str);
            }
        });
        this.body.addView(button("Créer", new Runnable() { // from class: ma.releve.terrain.v320.MainActivity$$ExternalSyntheticLambda48
            @Override // java.lang.Runnable
            public final void run() {
                MainActivity.this.m22lambda$createUser$48$mareleveterrainMainActivity(editTextField, editTextField3, editTextField2, strArr);
            }
        }));
    }

    /* renamed from: lambda$createUser$47$ma-releve-terrain-MainActivity, reason: not valid java name */
    /* synthetic */ String m21lambda$createUser$47$mareleveterrainMainActivity(String str, String str2, String str3, String str4, String str5) throws Exception {
        this.db.user(str, str2, str3, str4, str5);
        return "Compte créé.";
    }

    /* renamed from: lambda$createUser$48$ma-releve-terrain-MainActivity, reason: not valid java name */
    /* synthetic */ void m22lambda$createUser$48$mareleveterrainMainActivity(EditText editText, EditText editText2, EditText editText3, String[] strArr) {
        final String strValue = value(editText);
        final String strValue2 = value(editText2);
        final String strValue3 = value(editText3);
        final String str = strArr[0];
        final String str2 = this.user;
        async(new Job() { // from class: ma.releve.terrain.v320.MainActivity$$ExternalSyntheticLambda86
            @Override // ma.releve.terrain.v320.MainActivity.Job
            public final String run() throws Exception {
                return MainActivity.this.m21lambda$createUser$47$mareleveterrainMainActivity(strValue, strValue2, str, strValue3, str2);
            }
        });
    }

    static /* synthetic */ void lambda$assignment$49(String[] strArr, String str) {
        strArr[0] = str;
    }

    void assignment() {
        shell("Affectation de tournée");
        this.body.addView(button("‹ Administration", new MainActivity$$ExternalSyntheticLambda0(this)));
        final EditText editTextField = field("Campagne", campaign());
        final EditText editTextField2 = field("Réseau EA ou BT", "");
        final EditText editTextField3 = field("UR", "");
        final EditText editTextField4 = field("Tournée", "");
        final String[] strArr = {""};
        selector("Releveur", this.db.users(), new Selection() { // from class: ma.releve.terrain.v320.MainActivity$$ExternalSyntheticLambda77
            @Override // ma.releve.terrain.v320.MainActivity.Selection
            public final void choose(String str) {
                MainActivity.lambda$assignment$49(strArr, str);
            }
        });
        this.body.addView(button("Affecter les contrats encore sans visite", new Runnable() { // from class: ma.releve.terrain.v320.MainActivity$$ExternalSyntheticLambda78
            @Override // java.lang.Runnable
            public final void run() throws SQLException {
                MainActivity.this.m8lambda$assignment$50$mareleveterrainMainActivity(strArr, editTextField, editTextField2, editTextField3, editTextField4);
            }
        }));
    }

    /* renamed from: lambda$assignment$50$ma-releve-terrain-MainActivity, reason: not valid java name */
    /* synthetic */ void m8lambda$assignment$50$mareleveterrainMainActivity(String[] strArr, EditText editText, EditText editText2, EditText editText3, EditText editText4) throws SQLException {
        String str;
        if (strArr[0].isEmpty()) {
            str = "Choisir un releveur.";
        } else {
            this.db.assign(value(editText), value(editText2).toUpperCase(Locale.ROOT), value(editText3), value(editText4), strArr[0], this.user);
            this.db.log(this.user, "AFFECTATION_TOURNEE", value(editText) + " " + value(editText2) + " " + value(editText3) + " " + value(editText4) + " " + strArr[0]);
            str = "Affectation appliquée aux contrats sans visite de cette sélection.";
        }
        alert(str);
    }

    void catalogue() {
        shell("Anomalies et contrôles");
        this.body.addView(button("‹ Administration", new MainActivity$$ExternalSyntheticLambda0(this)));
        this.body.addView(text("Les codes DEMO_ sont des exemples. Exportez ce catalogue, remplacez les codes et paramètres par ceux de votre SI, puis réimportez-le.", 14, NAVY));
        this.body.addView(button("Exporter le catalogue modifiable", new Runnable() { // from class: ma.releve.terrain.v320.MainActivity$$ExternalSyntheticLambda18
            @Override // java.lang.Runnable
            public final void run() {
                MainActivity.this.m17lambda$catalogue$51$mareleveterrainMainActivity();
            }
        }));
        this.body.addView(button("Importer le catalogue (remplacement)", new Runnable() { // from class: ma.releve.terrain.v320.MainActivity$$ExternalSyntheticLambda19
            @Override // java.lang.Runnable
            public final void run() {
                MainActivity.this.m19lambda$catalogue$53$mareleveterrainMainActivity();
            }
        }));
        for (Store.Anomaly anomaly : this.db.anomalies(null, null)) {
            this.body.addView(text(anomaly.toString() + "\n" + anomaly.nets + " • " + anomaly.cases + " • Deuxième passage " + (anomaly.repeat ? "OUI" : "NON"), 13, GRAY));
        }
        final EditText editTextField = field("Régularité EA minimum jours", getPreferences(0).getString("eaMin", "20"));
        final EditText editTextField2 = field("Régularité EA maximum jours", getPreferences(0).getString("eaMax", "30"));
        final EditText editTextField3 = field("Régularité BT minimum jours", getPreferences(0).getString("btMin", "28"));
        final EditText editTextField4 = field("Régularité BT maximum jours", getPreferences(0).getString("btMax", "32"));
        this.body.addView(button("Enregistrer les plages KPI", new Runnable() { // from class: ma.releve.terrain.v320.MainActivity$$ExternalSyntheticLambda20
            @Override // java.lang.Runnable
            public final void run() {
                MainActivity.this.m20lambda$catalogue$54$mareleveterrainMainActivity(editTextField, editTextField2, editTextField3, editTextField4);
            }
        }));
    }

    /* renamed from: lambda$catalogue$51$ma-releve-terrain-MainActivity, reason: not valid java name */
    /* synthetic */ void m17lambda$catalogue$51$mareleveterrainMainActivity() {
        pick(22);
    }

    /* renamed from: lambda$catalogue$52$ma-releve-terrain-MainActivity, reason: not valid java name */
    /* synthetic */ void m18lambda$catalogue$52$mareleveterrainMainActivity(DialogInterface dialogInterface, int i) {
        pick(21);
    }

    /* renamed from: lambda$catalogue$53$ma-releve-terrain-MainActivity, reason: not valid java name */
    /* synthetic */ void m19lambda$catalogue$53$mareleveterrainMainActivity() {
        new AlertDialog.Builder(this).setTitle("Remplacer le catalogue ?").setMessage("Les anciennes saisies et l’historique sont conservés. Les nouvelles listes utiliseront les nouveaux codes.").setNegativeButton("Annuler", (DialogInterface.OnClickListener) null).setPositiveButton("Choisir le fichier", new DialogInterface.OnClickListener() { // from class: ma.releve.terrain.v320.MainActivity$$ExternalSyntheticLambda83
            @Override // android.content.DialogInterface.OnClickListener
            public final void onClick(DialogInterface dialogInterface, int i) {
                MainActivity.this.m18lambda$catalogue$52$mareleveterrainMainActivity(dialogInterface, i);
            }
        }).show();
    }

    /* renamed from: lambda$catalogue$54$ma-releve-terrain-MainActivity, reason: not valid java name */
    /* synthetic */ void m20lambda$catalogue$54$mareleveterrainMainActivity(EditText editText, EditText editText2, EditText editText3, EditText editText4) {
        try {
            int i = Integer.parseInt(value(editText));
            int i2 = Integer.parseInt(value(editText2));
            int i3 = Integer.parseInt(value(editText3));
            int i4 = Integer.parseInt(value(editText4));
            if (i < 1 || i3 < 1 || i2 < i || i4 < i3) {
                throw new Exception();
            }
            getPreferences(0).edit().putString("eaMin", "" + i).putString("eaMax", "" + i2).putString("btMin", "" + i3).putString("btMax", "" + i4).apply();
            this.db.log(this.user, "PLAGES_KPI", i + "-" + i2 + " / " + i3 + "-" + i4);
            alert("Plages enregistrées.");
        } catch (Exception e) {
            alert("Plages de jours invalides.");
        }
    }

    static /* synthetic */ void lambda$settings$55(String[] strArr, EditText editText, SharedPreferences sharedPreferences, String str) {
        strArr[0] = str;
        editText.setText(sharedPreferences.getString("url_" + str, ""));
    }

    /* renamed from: lambda$settings$56$ma-releve-terrain-MainActivity, reason: not valid java name */
    /* synthetic */ void m70lambda$settings$56$mareleveterrainMainActivity(EditText editText, SharedPreferences sharedPreferences, String[] strArr) {
        try {
            if (!value(editText).isEmpty()) {
                DirectDrive.url(value(editText));
            }
            sharedPreferences.edit().putString("url_" + strArr[0], value(editText)).apply();
            alert("Lien enregistré pour " + strArr[0] + ".");
        } catch (Exception e) {
            alert(e.getMessage());
        }
    }

    void settings() {
        shell("Liens Google Drive des releveurs");
        this.body.addView(button("‹ Administration", new MainActivity$$ExternalSyntheticLambda0(this)));
        final String[] strArr = {this.user};
        final SharedPreferences sharedPreferences = getSharedPreferences("drive", 0);
        final EditText editTextField = field("URL du fichier XLSX / CSV", sharedPreferences.getString("url_" + this.user, ""));
        selector("Releveur", this.db.users(), new Selection() { // from class: ma.releve.terrain.v320.MainActivity$$ExternalSyntheticLambda42
            @Override // ma.releve.terrain.v320.MainActivity.Selection
            public final void choose(String str) {
                MainActivity.lambda$settings$55(strArr, editTextField, sharedPreferences, str);
            }
        });
        this.body.addView(button("Enregistrer le lien", new Runnable() { // from class: ma.releve.terrain.v320.MainActivity$$ExternalSyntheticLambda43
            @Override // java.lang.Runnable
            public final void run() {
                MainActivity.this.m70lambda$settings$56$mareleveterrainMainActivity(editTextField, sharedPreferences, strArr);
            }
        }));
        this.body.addView(text("Utiliser le lien du fichier personnel, pas celui d’un dossier. Aucun serveur à installer. Le releveur peut importer un fichier enregistré sur son téléphone ou sélectionner Drive avec son compte Google.", 14, NAVY));
    }

    /* renamed from: lambda$myDrive$58$ma-releve-terrain-MainActivity, reason: not valid java name */
    /* synthetic */ void m51lambda$myDrive$58$mareleveterrainMainActivity(EditText editText, SharedPreferences sharedPreferences) {
        final String strValue = value(editText);
        String str = this.user;
        try {
            DirectDrive.url(strValue);
            sharedPreferences.edit().putString("url_" + str, strValue).apply();
            loadTour(new BytesJob() { // from class: ma.releve.terrain.v320.MainActivity$$ExternalSyntheticLambda10
                @Override // ma.releve.terrain.v320.MainActivity.BytesJob
                public final byte[] run() throws Exception {
                    return DirectDrive.download(strValue);
                }
            }, str);
        } catch (Exception e) {
            alert(e.getMessage());
        }
    }

    /* renamed from: lambda$myDrive$59$ma-releve-terrain-MainActivity, reason: not valid java name */
    /* synthetic */ void m52lambda$myDrive$59$mareleveterrainMainActivity() {
        Intent intent = new Intent("android.intent.action.OPEN_DOCUMENT");
        intent.addCategory("android.intent.category.OPENABLE");
        intent.setType("*/*");
        intent.putExtra("android.intent.extra.MIME_TYPES", new String[]{"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "text/csv", "application/csv", "text/comma-separated-values"});
        startActivityForResult(intent, 50);
    }

    void myDrive() {
        shell("Ma tournée • " + this.db.displayName(this.user));
        this.body.addView(button("‹ Retour", new MainActivity$$ExternalSyntheticLambda6(this)));
        final SharedPreferences sharedPreferences = getSharedPreferences("drive", 0);
        final EditText editTextField = field("URL du fichier Google Drive", sharedPreferences.getString("url_" + this.user, ""));
        this.body.addView(button("Synchroniser ma tournée", new Runnable() { // from class: ma.releve.terrain.v320.MainActivity$$ExternalSyntheticLambda15
            @Override // java.lang.Runnable
            public final void run() {
                MainActivity.this.m51lambda$myDrive$58$mareleveterrainMainActivity(editTextField, sharedPreferences);
            }
        }));
        this.body.addView(button("Importer le fichier depuis votre téléphone", new Runnable() { // from class: ma.releve.terrain.v320.MainActivity$$ExternalSyntheticLambda16
            @Override // java.lang.Runnable
            public final void run() {
                MainActivity.this.m52lambda$myDrive$59$mareleveterrainMainActivity();
            }
        }));
        this.body.addView(button("Importer les trois CSV ensemble", () -> {
            Intent pick=new Intent(Intent.ACTION_OPEN_DOCUMENT);pick.setType("*/*");pick.addCategory(Intent.CATEGORY_OPENABLE);pick.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true);startActivityForResult(pick,52);
        }));
        this.body.addView(text("Importer un classeur XLSX à trois feuilles ou un ZIP contenant Releve.csv, Anomalie.csv et type_local.csv. Sauvegarder et envoyer ne remplacent rien. Seule la confirmation explicite remplace la liste et les catalogues.", 14, NAVY));
        this.body.addView(text("Un lien accessible sans connexion permet le téléchargement direct. Vous pouvez aussi importer un fichier XLSX/CSV enregistré sur votre téléphone. Le sélecteur permet également de choisir un fichier dans Drive. Les relèves restent utilisables hors connexion.", 13, GRAY));
    }

    /* renamed from: lambda$loadTour$60$ma-releve-terrain-MainActivity, reason: not valid java name */
    /* synthetic */ String m41lambda$loadTour$60$mareleveterrainMainActivity(byte[][] bArr, BytesJob bytesJob, List list, String str, long[] jArr) throws Exception {
        bArr[0] = bytesJob.run();
        list.add(LocalTransfer.validate(bArr[0], str));
        jArr[0] = this.db.revision();
        return "";
    }

    /* renamed from: lambda$loadTour$61$ma-releve-terrain-MainActivity, reason: not valid java name */
    /* synthetic */ void m42lambda$loadTour$61$mareleveterrainMainActivity(String str, List list, byte[][] bArr, long[] jArr, DialogInterface dialogInterface, int i) {
        replaceTour(str, (List) list.get(0), bArr[0], true, jArr[0], false);
    }

    /* renamed from: lambda$loadTour$62$ma-releve-terrain-MainActivity, reason: not valid java name */
    /* synthetic */ void m43lambda$loadTour$62$mareleveterrainMainActivity(String str, List list, byte[][] bArr, long[] jArr, DialogInterface dialogInterface, int i) {
        replaceTour(str, (List) list.get(0), bArr[0], false, jArr[0], false);
    }

    /* renamed from: lambda$loadTour$63$ma-releve-terrain-MainActivity, reason: not valid java name */
    void m44lambda$loadTour$63$mareleveterrainMainActivity(final String owner, final List list, final byte[][] bytes, final long[] revision, String ignored) {
        if(this.user.equals(owner)) confirmationDialog(owner,(List<String[]>)list.get(0),bytes[0],revision[0]);
    }
    AlertDialog confirmationDialog(String owner,List<String[]> rows,byte[] bytes,long revision) {
        if(!this.user.equals(owner))return null;
        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.VERTICAL);
        actions.setPadding(dp(16), dp(8), dp(16), dp(8));
        AlertDialog dialog = new AlertDialog.Builder(this).setTitle("Remplacer la liste Releve ?")
            .setMessage(rows.size()+" compteurs et les deux catalogues ont été validés. Appuyez sur Remplacer pour importer cette tournée à la place de votre liste actuelle.")
            .setView(actions)
            .setPositiveButton("Remplacer", (d,w) -> replaceTour(owner,rows,bytes,false,revision,false))
            .setNegativeButton("Annuler",null).create();
        actions.addView(button("Sauvegarder / Exporter", () -> {
            dialog.dismiss();
            async(() -> {
                File backup=LocalTransfer.backup(this,owner,this.db.ownRows(owner),LocalTransfer.source(this,this.db,owner));
                this.db.registerBackup(owner,backup.getName(),this.db.ownRows(owner).size());
                return "Sauvegarde créée : "+backup.getName();
            }, message -> {alert(message); confirmationDialog(owner,rows,bytes,revision);}, message -> {alert(message);confirmationDialog(owner,rows,bytes,revision);});
        }));
        actions.addView(button("Envoyer les relèves", () -> {dialog.dismiss();shareResults();confirmationDialog(owner,rows,bytes,revision);}));
        dialog.show();
        return dialog;
    }

    /* renamed from: lambda$loadTour$64$ma-releve-terrain-MainActivity, reason: not valid java name */
    /* synthetic */ void m45lambda$loadTour$64$mareleveterrainMainActivity(DialogInterface dialogInterface, int i) {
        Intent intent = new Intent("android.intent.action.OPEN_DOCUMENT");
        intent.setType("*/*");
        intent.addCategory("android.intent.category.OPENABLE");
        startActivityForResult(intent, 50);
    }

    /* renamed from: lambda$loadTour$65$ma-releve-terrain-MainActivity, reason: not valid java name */
    /* synthetic */ void m46lambda$loadTour$65$mareleveterrainMainActivity(String str) {
        new AlertDialog.Builder(this).setTitle("Téléchargement impossible").setMessage(str + "\nAucune donnée existante n’a été supprimée.").setNegativeButton("Fermer", (DialogInterface.OnClickListener) null).setPositiveButton("Importer un fichier", new DialogInterface.OnClickListener() { // from class: ma.releve.terrain.v320.MainActivity$$ExternalSyntheticLambda44
            @Override // android.content.DialogInterface.OnClickListener
            public final void onClick(DialogInterface dialogInterface, int i) {
                MainActivity.this.m45lambda$loadTour$64$mareleveterrainMainActivity(dialogInterface, i);
            }
        }).show();
    }

    void loadTour(final BytesJob bytesJob, final String str) {
        final byte[][] bArr = {null};
        final ArrayList arrayList = new ArrayList();
        final long[] jArr = {0};
        async(new Job() { // from class: ma.releve.terrain.v320.MainActivity$$ExternalSyntheticLambda7
            @Override // ma.releve.terrain.v320.MainActivity.Job
            public final String run() throws Exception {
                return MainActivity.this.m41lambda$loadTour$60$mareleveterrainMainActivity(bArr, bytesJob, arrayList, str, jArr);
            }
        }, new Done() { // from class: ma.releve.terrain.v320.MainActivity$$ExternalSyntheticLambda8
            @Override // ma.releve.terrain.v320.MainActivity.Done
            public final void result(String str2) {
                MainActivity.this.m44lambda$loadTour$63$mareleveterrainMainActivity(str, arrayList, bArr, jArr, str2);
            }
        }, new Done() { // from class: ma.releve.terrain.v320.MainActivity$$ExternalSyntheticLambda9
            @Override // ma.releve.terrain.v320.MainActivity.Done
            public final void result(String str2) {
                MainActivity.this.m46lambda$loadTour$65$mareleveterrainMainActivity(str2);
            }
        });
    }

    /* renamed from: lambda$replaceTour$66$ma-releve-terrain-MainActivity, reason: not valid java name */
    /* synthetic */ String m62lambda$replaceTour$66$mareleveterrainMainActivity(String str, List list, byte[] bArr, boolean z, long j, boolean z2) throws Exception {
        return LocalTransfer.replace(this, this.db, str, list, bArr, z, j, z2);
    }

    /* renamed from: lambda$replaceTour$67$ma-releve-terrain-MainActivity, reason: not valid java name */
    /* synthetic */ void m63lambda$replaceTour$67$mareleveterrainMainActivity(List list, String str, String str2) {
        this.chosenCampaign = null;
        this.chosenUr = null;
        this.chosenTour = null;
        this.status = null;
        this.query = "";
        if (!list.isEmpty()) {
            getPreferences(0).edit().putString("campaign_" + str, ((String[]) list.get(0))[36]).apply();
        }
        home();
        alert(str2);
    }

    /* renamed from: lambda$replaceTour$68$ma-releve-terrain-MainActivity, reason: not valid java name */
    /* synthetic */ void m64lambda$replaceTour$68$mareleveterrainMainActivity(String str) {
        alert(str + "\nLe remplacement n’a pas été effectué.");
    }

    void replaceTour(final String str, final List<String[]> list, final byte[] bArr, final boolean z, final long j, final boolean z2) {
        async(new Job() { // from class: ma.releve.terrain.v320.MainActivity$$ExternalSyntheticLambda49
            @Override // ma.releve.terrain.v320.MainActivity.Job
            public final String run() throws Exception {
                return MainActivity.this.m62lambda$replaceTour$66$mareleveterrainMainActivity(str, list, bArr, z, j, z2);
            }
        }, new Done() { // from class: ma.releve.terrain.v320.MainActivity$$ExternalSyntheticLambda50
            @Override // ma.releve.terrain.v320.MainActivity.Done
            public final void result(String str2) {
                MainActivity.this.m63lambda$replaceTour$67$mareleveterrainMainActivity(list, str, str2);
            }
        }, new Done() { // from class: ma.releve.terrain.v320.MainActivity$$ExternalSyntheticLambda51
            @Override // ma.releve.terrain.v320.MainActivity.Done
            public final void result(String str2) {
                MainActivity.this.m64lambda$replaceTour$68$mareleveterrainMainActivity(str2);
            }
        });
    }

    void backups() {
        shell("Mes sauvegardes • " + this.user);
        this.body.addView(button("‹ Retour", new MainActivity$$ExternalSyntheticLambda6(this)));
        List<String[]> listBackups = this.db.backups(this.user);
        if (listBackups.isEmpty()) {
            this.body.addView(text("Aucune sauvegarde. Avant un remplacement, choisissez Sauvegarder / Exporter pour conserver votre tournée.", 14, NAVY));
        }
        for (final String[] strArr : listBackups) {
            this.body.addView(text(strArr[1] + " • " + strArr[2] + " compteurs", 15, NAVY));
            this.body.addView(button("Exporter la sauvegarde", new Runnable() { // from class: ma.releve.terrain.v320.MainActivity$$ExternalSyntheticLambda66
                @Override // java.lang.Runnable
                public final void run() {
                    MainActivity.this.m13lambda$backups$69$mareleveterrainMainActivity(strArr);
                }
            }));
            this.body.addView(button("Envoyer cette sauvegarde vers Drive", new Runnable() { // from class: ma.releve.terrain.v320.MainActivity$$ExternalSyntheticLambda67
                @Override // java.lang.Runnable
                public final void run() {
                    MainActivity.this.m14lambda$backups$70$mareleveterrainMainActivity(strArr);
                }
            }));
            this.body.addView(button("Restaurer cette tournée", new Runnable() { // from class: ma.releve.terrain.v320.MainActivity$$ExternalSyntheticLambda68
                @Override // java.lang.Runnable
                public final void run() {
                    MainActivity.this.m15lambda$backups$71$mareleveterrainMainActivity(strArr);
                }
            }));
        }
        this.body.addView(text("Exportez les sauvegardes vers Drive pour les conserver en cas de perte du téléphone ou de désinstallation. Les fichiers restent sous votre contrôle.", 13, GRAY));
    }

    /* renamed from: lambda$backups$69$ma-releve-terrain-MainActivity, reason: not valid java name */
    /* synthetic */ void m13lambda$backups$69$mareleveterrainMainActivity(String[] strArr) {
        this.selectedArchive = new File(new File(getFilesDir(), "exports"), strArr[0]);
        Intent intent = new Intent("android.intent.action.CREATE_DOCUMENT");
        intent.addCategory("android.intent.category.OPENABLE");
        intent.setType("application/zip");
        intent.putExtra("android.intent.extra.TITLE", strArr[0]);
        startActivityForResult(intent, 51);
    }

    /* renamed from: lambda$backups$70$ma-releve-terrain-MainActivity, reason: not valid java name */
    /* synthetic */ void m14lambda$backups$70$mareleveterrainMainActivity(String[] strArr) {
        shareFile(new File(new File(getFilesDir(), "exports"), strArr[0]));
    }

    /* renamed from: lambda$backups$71$ma-releve-terrain-MainActivity, reason: not valid java name */
    /* synthetic */ void m15lambda$backups$71$mareleveterrainMainActivity(String[] strArr) {
        restoreArchive(strArr[0]);
    }

    /* renamed from: lambda$restoreArchive$72$ma-releve-terrain-MainActivity, reason: not valid java name */
    /* synthetic */ String m65lambda$restoreArchive$72$mareleveterrainMainActivity(String str, BackupPack.Snapshot[] snapshotArr, String str2) throws Exception {
        FileInputStream fileInputStream = new FileInputStream(new File(new File(getFilesDir(), "exports"), str));
        try {
            snapshotArr[0] = BackupPack.read(fileInputStream, str2);
            fileInputStream.close();
            return "";
        } catch (Throwable th) {
            try {
                fileInputStream.close();
            } catch (Throwable th2) {
                th.addSuppressed(th2);
            }
            throw th;
        }
    }

    /* renamed from: lambda$restoreArchive$73$ma-releve-terrain-MainActivity, reason: not valid java name */
    /* synthetic */ String m66lambda$restoreArchive$73$mareleveterrainMainActivity(BackupPack.Snapshot[] snapshotArr, String str, long j) throws Exception {
        LocalTransfer.restorePhotos(this, snapshotArr[0]);
        return LocalTransfer.replace(this, this.db, str, snapshotArr[0].rows, snapshotArr[0].source, true, j, true, snapshotArr[0].anomalies == null ? null : new BundleImport(snapshotArr[0].rows,snapshotArr[0].anomalies,snapshotArr[0].types));
    }

    /* renamed from: lambda$restoreArchive$74$ma-releve-terrain-MainActivity, reason: not valid java name */
    /* synthetic */ void m67lambda$restoreArchive$74$mareleveterrainMainActivity(BackupPack.Snapshot[] snapshotArr, String str, String str2) {
        this.chosenCampaign = null;
        if (!snapshotArr[0].rows.isEmpty()) {
            getPreferences(0).edit().putString("campaign_" + str, snapshotArr[0].rows.get(0)[36]).apply();
        }
        home();
        alert(str2);
    }

    /* renamed from: lambda$restoreArchive$75$ma-releve-terrain-MainActivity, reason: not valid java name */
    /* synthetic */ void m68lambda$restoreArchive$75$mareleveterrainMainActivity(final BackupPack.Snapshot[] snapshotArr, final String str, final long j, DialogInterface dialogInterface, int i) {
        async(new Job() { // from class: ma.releve.terrain.v320.MainActivity$$ExternalSyntheticLambda3
            @Override // ma.releve.terrain.v320.MainActivity.Job
            public final String run() throws Exception {
                return MainActivity.this.m66lambda$restoreArchive$73$mareleveterrainMainActivity(snapshotArr, str, j);
            }
        }, new Done() { // from class: ma.releve.terrain.v320.MainActivity$$ExternalSyntheticLambda4
            @Override // ma.releve.terrain.v320.MainActivity.Done
            public final void result(String str2) {
                MainActivity.this.m67lambda$restoreArchive$74$mareleveterrainMainActivity(snapshotArr, str, str2);
            }
        }, new MainActivity$$ExternalSyntheticLambda5(this));
    }

    /* renamed from: lambda$restoreArchive$76$ma-releve-terrain-MainActivity, reason: not valid java name */
    /* synthetic */ void m69lambda$restoreArchive$76$mareleveterrainMainActivity(final BackupPack.Snapshot[] snapshotArr, final String str, final long j, String str2) {
        new AlertDialog.Builder(this).setTitle("Restaurer cette tournée ?").setMessage("La tournée actuelle sera sauvegardée avant restauration des " + snapshotArr[0].rows.size() + " compteurs et de leurs saisies.").setNegativeButton("Annuler", (DialogInterface.OnClickListener) null).setPositiveButton("Restaurer", new DialogInterface.OnClickListener() { // from class: ma.releve.terrain.v320.MainActivity$$ExternalSyntheticLambda89
            @Override // android.content.DialogInterface.OnClickListener
            public final void onClick(DialogInterface dialogInterface, int i) {
                MainActivity.this.m68lambda$restoreArchive$75$mareleveterrainMainActivity(snapshotArr, str, j, dialogInterface, i);
            }
        }).show();
    }

    void restoreArchive(final String str) {
        final String str2 = this.user;
        final long jRevision = this.db.revision();
        final BackupPack.Snapshot[] snapshotArr = {null};
        async(new Job() { // from class: ma.releve.terrain.v320.MainActivity$$ExternalSyntheticLambda45
            @Override // ma.releve.terrain.v320.MainActivity.Job
            public final String run() throws Exception {
                return MainActivity.this.m65lambda$restoreArchive$72$mareleveterrainMainActivity(str, snapshotArr, str2);
            }
        }, new Done() { // from class: ma.releve.terrain.v320.MainActivity$$ExternalSyntheticLambda46
            @Override // ma.releve.terrain.v320.MainActivity.Done
            public final void result(String str3) {
                MainActivity.this.m69lambda$restoreArchive$76$mareleveterrainMainActivity(snapshotArr, str2, jRevision, str3);
            }
        }, new MainActivity$$ExternalSyntheticLambda5(this));
    }

    void shareFile(File file) {
        if (!file.isFile()) {
            alert("Fichier introuvable.");
            return;
        }
        Uri uri = Uri.parse("content://ma.releve.terrain.v320.exports/" + file.getName());
        Intent intent = new Intent("android.intent.action.SEND");
        intent.setType("application/zip");
        intent.putExtra("android.intent.extra.STREAM", uri);
        intent.setClipData(ClipData.newRawUri("SmartMobility", uri));
        intent.addFlags(1);
        try {
            startActivity(Intent.createChooser(intent, "Enregistrer dans Drive"));
        } catch (Exception e) {
            alert("Installez Drive ou utilisez Exporter pour enregistrer le fichier.");
        }
    }

    /* renamed from: lambda$shareResults$77$ma-releve-terrain-MainActivity, reason: not valid java name */
    /* synthetic */ String m71lambda$shareResults$77$mareleveterrainMainActivity(File[] fileArr, String str) throws Exception {
        fileArr[0] = LocalTransfer.backup(this, str, this.db.ownRows(str), LocalTransfer.source(this, this.db, str));
        return "";
    }

    /* renamed from: lambda$shareResults$78$ma-releve-terrain-MainActivity, reason: not valid java name */
    /* synthetic */ void m72lambda$shareResults$78$mareleveterrainMainActivity(File[] fileArr, String str) {
        shareFile(fileArr[0]);
    }

    void shareResults() {
        final String str = this.user;
        final File[] fileArr = {null};
        async(new Job() { // from class: ma.releve.terrain.v320.MainActivity$$ExternalSyntheticLambda79
            @Override // ma.releve.terrain.v320.MainActivity.Job
            public final String run() throws Exception {
                return MainActivity.this.m71lambda$shareResults$77$mareleveterrainMainActivity(fileArr, str);
            }
        }, new Done() { // from class: ma.releve.terrain.v320.MainActivity$$ExternalSyntheticLambda80
            @Override // ma.releve.terrain.v320.MainActivity.Done
            public final void result(String str2) {
                MainActivity.this.m72lambda$shareResults$78$mareleveterrainMainActivity(fileArr, str2);
            }
        }, new MainActivity$$ExternalSyntheticLambda5(this));
    }

    void maybeAuto() {
    }

    void dashboard() throws NumberFormatException {
        int i;
        char c;
        char c2;
        shell("KPI • Objectifs relève 99 %, régularité 99 %, anomalies ≤ 1 %");
        this.body.addView(button("‹ Retour", new MainActivity$$ExternalSyntheticLambda6(this)));
        List<Store.Record> list = this.db.list(this.user, this.admin, "", null, null, null, 0);
        LinkedHashMap<String,int[]> linkedHashMap = new LinkedHashMap<>();
        Iterator<Store.Record> it = list.iterator();
        while (true) {
            i = 15;
            c = 0;
            c2 = 1;
            if (!it.hasNext()) {
                break;
            }
            Store.Record next = it.next();
            if (!next.a[0].isEmpty()) {
                String str = next.a[36] + " • " + next.a[23] + " • " + next.a[3] + " • T " + next.a[15] + " • " + next.a[14];
                int[] iArr = (int[]) linkedHashMap.get(str);
                if (iArr == null) {
                    iArr = new int[7];
                    linkedHashMap.put(str, iArr);
                }
                iArr[0] = iArr[0] + 1;
                if (!next.a[7].isEmpty()) {
                    iArr[1] = iArr[1] + 1;
                }
                if (!next.a[8].isEmpty()) {
                    iArr[2] = iArr[2] + 1;
                }
                if (next.a[28].equals("A_REPASSER")) {
                    iArr[3] = iArr[3] + 1;
                }
                if (next.a[29].equals("SYNCHRONISE")) {
                    iArr[4] = iArr[4] + 1;
                }
                if (!next.a[25].isEmpty() && !next.a[7].isEmpty()) {
                    iArr[5] = iArr[5] + 1;
                    int i2 = Integer.parseInt(next.a[25]);
                    boolean zEquals = next.a[14].equals("EA");
                    int i3 = Integer.parseInt(getPreferences(0).getString(zEquals ? "eaMin" : "btMin", zEquals ? "20" : "28"));
                    int i4 = Integer.parseInt(getPreferences(0).getString(zEquals ? "eaMax" : "btMax", zEquals ? "30" : "32"));
                    if (i2 >= i3 && i2 <= i4) {
                        iArr[6] = iArr[6] + 1;
                    }
                }
            }
        }
        for (Map.Entry entry : linkedHashMap.entrySet()) {
            int[] iArr2 = (int[]) entry.getValue();
            this.body.addView(text((String) entry.getKey(), i, NAVY));
            this.body.addView(text(String.format(Locale.FRANCE, "Relève : %.2f %% (%d/%d)\nNon relevés : %d • Deuxième passage : %d\nAnomalies : %.2f %%\nRégularité : %s", Double.valueOf((iArr2[c2] * 100.0d) / iArr2[c]), Integer.valueOf(iArr2[c2]), Integer.valueOf(iArr2[c]), Integer.valueOf(iArr2[c] - iArr2[c2]), Integer.valueOf(iArr2[3]), Double.valueOf((iArr2[2] * 100.0d) / iArr2[c]), iArr2[5] == 0 ? "Non calculable" : String.format(Locale.FRANCE, "%.2f %% (%d/%d)", Double.valueOf((iArr2[6] * 100.0d) / iArr2[5]), Integer.valueOf(iArr2[6]), Integer.valueOf(iArr2[5]))), 14, GRAY));
            i = 15;
            c = 0;
            c2 = 1;
        }
        this.body.addView(text("Taux de relève = compteurs avec index / contrats importés. Anomalies = contrats annotés / contrats importés. Régularité = relevés dans la plage / relevés avec intervalle calculable. Les compteurs hors liste sont exclus. Tableau local au téléphone. Exportez les relevés pour les transmettre.", 12, GRAY));
    }

    void alert(String str) {
        if (isDestroyed()) {
            return;
        }
        new AlertDialog.Builder(this).setTitle("SmartMobility Terrain").setMessage(str).setPositiveButton("OK", (DialogInterface.OnClickListener) null).show();
    }

    void toast(String str) {
        Toast.makeText(this, str, 1).show();
    }

    @Override // android.app.Activity
    protected void onDestroy() {
        stopGps();
        if (this.autoTick != null) {
            this.handler.removeCallbacks(this.autoTick);
        }
        if (this.network != null) {
            try {
                this.connectivity.unregisterNetworkCallback(this.network);
            } catch (Exception e) {
            }
        }
        this.worker.shutdown();
        super.onDestroy();
    }
}
