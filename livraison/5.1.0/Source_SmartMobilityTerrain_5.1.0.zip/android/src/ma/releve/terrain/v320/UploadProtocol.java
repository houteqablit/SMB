package ma.releve.terrain.v320;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
final class UploadProtocol {
 static final int MAX_BYTES=6*1024*1024;
 static String endpoint(String value){
  URI uri=URI.create(value.trim());
  if(!"https".equals(uri.getScheme())||!"script.google.com".equals(uri.getHost())||uri.getPort()!=-1||uri.getUserInfo()!=null||uri.getQuery()!=null||uri.getFragment()!=null||!uri.getPath().matches("/macros/s/[A-Za-z0-9_-]+/exec"))throw new IllegalArgumentException("Lien Apps Script HTTPS /exec requis.");
  return uri.toString();
 }
 static String hex(byte[] bytes){StringBuilder out=new StringBuilder();for(byte b:bytes)out.append(String.format(java.util.Locale.ROOT,"%02x",b&255));return out.toString();}
 static String sha(byte[] bytes)throws Exception{return hex(MessageDigest.getInstance("SHA-256").digest(bytes));}
 static String canonical(String owner,String sha,String id,long time){
  if(owner.isEmpty()||owner.length()>128||owner.indexOf('\n')>=0||owner.indexOf('\r')>=0)throw new IllegalArgumentException("Identifiant de compte invalide.");
  return owner+"\n"+sha+"\n"+id+"\n"+time;
 }
 static String signature(String secret,String canonical)throws Exception{
  Mac mac=Mac.getInstance("HmacSHA256");mac.init(new SecretKeySpec(secret.getBytes(StandardCharsets.UTF_8),"HmacSHA256"));return hex(mac.doFinal(canonical.getBytes(StandardCharsets.UTF_8)));
 }
}
