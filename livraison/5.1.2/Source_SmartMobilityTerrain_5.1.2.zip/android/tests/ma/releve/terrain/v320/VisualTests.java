package ma.releve.terrain.v320;
import android.app.*;import android.content.*;import android.os.*;import android.view.*;import android.view.inputmethod.*;import java.io.*;
public class VisualTests extends Instrumentation {
 public void onCreate(Bundle args){super.onCreate(args);start();}
 public void onStart(){Bundle result=new Bundle();try{
 Context ctx=new ContextWrapper(getTargetContext()){
  public android.database.sqlite.SQLiteDatabase openOrCreateDatabase(String name,int mode,android.database.sqlite.SQLiteDatabase.CursorFactory factory){return getBaseContext().openOrCreateDatabase("instrumentation_"+name,mode,factory);}
  public android.database.sqlite.SQLiteDatabase openOrCreateDatabase(String name,int mode,android.database.sqlite.SQLiteDatabase.CursorFactory factory,android.database.DatabaseErrorHandler error){return getBaseContext().openOrCreateDatabase("instrumentation_"+name,mode,factory,error);}
  public File getDatabasePath(String name){return getBaseContext().getDatabasePath("instrumentation_"+name);}
 };
 MainActivity activity=(MainActivity)startActivitySync(new Intent(getTargetContext(),MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
 runOnMainSync(()->{activity.db.close();activity.db=new Store(ctx);activity.user="releveur01";activity.admin=false;activity.getPreferences(0).edit().putString("campaign_releveur01","test").commit();activity.home();activity.chosenCampaign=null;activity.form(activity.db.list("releveur01",false,"",null,null,null,0).get(0));activity.newIndex.setText("1255");activity.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_SECURE);});
 waitForIdleSync();
 for(int i=0;i<10;i++){runOnMainSync(()->{activity.newIndex.requestFocus();((InputMethodManager)activity.getSystemService(Context.INPUT_METHOD_SERVICE)).showSoftInput(activity.newIndex,InputMethodManager.SHOW_IMPLICIT);});SystemClock.sleep(500);}
 android.graphics.Bitmap bitmap=getUiAutomation().takeScreenshot();
 try(FileOutputStream out=new FileOutputStream(new File(activity.getFilesDir(),"visual-test.png"))){bitmap.compress(android.graphics.Bitmap.CompressFormat.PNG,100,out);}bitmap.recycle();
 runOnMainSync(()->{activity.newIndex.setText("1");activity.ensureIndexConfirmed();});
 waitForIdleSync();SystemClock.sleep(1000);
 android.graphics.Bitmap warning=getUiAutomation().takeScreenshot();
 try(FileOutputStream out=new FileOutputStream(new File(activity.getFilesDir(),"visual-warning.png"))){warning.compress(android.graphics.Bitmap.CompressFormat.PNG,100,out);}warning.recycle();
 runOnMainSync(()->{if(activity.indexPrompt!=null)activity.indexPrompt.dismiss();activity.newMeter();activity.urEdit.setText("ur03");activity.serEdit.setText("000444");activity.newIndex.setText("1255");});
 waitForIdleSync();
 for(int i=0;i<10;i++){runOnMainSync(()->{activity.newIndex.requestFocus();((InputMethodManager)activity.getSystemService(Context.INPUT_METHOD_SERVICE)).showSoftInput(activity.newIndex,InputMethodManager.SHOW_IMPLICIT);});SystemClock.sleep(500);}
 final Throwable[] geometryError={null};
 runOnMainSync(()->{try{
  android.graphics.Rect frame=new android.graphics.Rect();activity.root.getWindowVisibleDisplayFrame(frame);
  for(View input:new View[]{activity.netSelector,activity.urEdit,activity.serEdit,activity.newIndex,activity.anomaly,activity.comment,activity.phone,activity.typeSelector,activity.body.getChildAt(activity.body.getChildCount()-1)}){
   android.graphics.Rect bounds=new android.graphics.Rect();if(input.getHeight()==0||!input.getGlobalVisibleRect(bounds)||bounds.height()!=input.getHeight()||bounds.bottom>frame.bottom)throw new AssertionError("outside meter fields fully visible with keyboard");
  }
 }catch(Throwable error){geometryError[0]=error;}});
 if(geometryError[0]!=null)throw geometryError[0];
 android.graphics.Bitmap outside=getUiAutomation().takeScreenshot();
 try(FileOutputStream out=new FileOutputStream(new File(activity.getFilesDir(),"outside-bt.png"))){outside.compress(android.graphics.Bitmap.CompressFormat.PNG,100,out);}outside.recycle();
 runOnMainSync(()->activity.netSelector.setSelection(1));waitForIdleSync();SystemClock.sleep(1000);
 android.graphics.Bitmap water=getUiAutomation().takeScreenshot();
 try(FileOutputStream out=new FileOutputStream(new File(activity.getFilesDir(),"outside-ea.png"))){water.compress(android.graphics.Bitmap.CompressFormat.PNG,100,out);}water.recycle();
 runOnMainSync(()->{((InputMethodManager)activity.getSystemService(Context.INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(activity.root.getWindowToken(),0);activity.admin=true;activity.readerOptions();});
 waitForIdleSync();SystemClock.sleep(1000);
 android.graphics.Bitmap options=getUiAutomation().takeScreenshot();
 try(FileOutputStream out=new FileOutputStream(new File(activity.getFilesDir(),"options-512.png"))){options.compress(android.graphics.Bitmap.CompressFormat.PNG,100,out);}options.recycle();
 runOnMainSync(()->activity.finish());result.putString("stream","PASS 1 Android checks\n");finish(Activity.RESULT_OK,result);
 }catch(Throwable failure){StringWriter out=new StringWriter();failure.printStackTrace(new PrintWriter(out));result.putString("stream",out.toString());finish(Activity.RESULT_CANCELED,result);}}
}
