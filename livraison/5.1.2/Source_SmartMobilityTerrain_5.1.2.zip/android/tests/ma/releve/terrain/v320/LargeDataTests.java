package ma.releve.terrain.v320;
import android.app.*;
import android.content.*;
import android.database.sqlite.*;
import android.os.*;
import java.io.*;
import java.util.*;
public class LargeDataTests extends Instrumentation {
 int checks;void check(boolean ok,String name){checks++;if(!ok)throw new AssertionError(name);}
 @Override public void onCreate(Bundle b){super.onCreate(b);start();}
 @Override public void onStart(){Bundle result=new Bundle();Store store=null;MainActivity activity=null;
  try{
   Context ctx=new ContextWrapper(getTargetContext()){
    String name(String n){return "large_test_"+n;}
    public SQLiteDatabase openOrCreateDatabase(String n,int m,SQLiteDatabase.CursorFactory f){return getBaseContext().openOrCreateDatabase(name(n),m,f);}
    public SQLiteDatabase openOrCreateDatabase(String n,int m,SQLiteDatabase.CursorFactory f,android.database.DatabaseErrorHandler e){return getBaseContext().openOrCreateDatabase(name(n),m,f,e);}
    public File getDatabasePath(String n){return getBaseContext().getDatabasePath(name(n));}
    public boolean deleteDatabase(String n){return getBaseContext().deleteDatabase(name(n));}
   };
   ctx.deleteDatabase("releve.db");store=new Store(ctx);SQLiteDatabase sql=store.getWritableDatabase();
   store.user("large_test","Synthetic123!","RELEVEUR","Nom Test","setup");
   long start=SystemClock.elapsedRealtime();
   sql.beginTransaction();try(SQLiteStatement insert=sql.compileStatement("INSERT INTO compteurs(contrat,serie,releveur,campagne,produit,reseau,ordre,date,ur,tournee) VALUES(?,?,?,?,?,?,?,?,?,?)")){
    for(int i=0;i<25000;i++){insert.clearBindings();String[] vals={"TEST_"+i,"SERIE_"+i,"large_test","large_test","202610",i%2==0?"EA":"BT",String.valueOf(25000-i),i%3==0?"18/10/2026 10:00:00":"","UR"+(i%10),"T01"};for(int c=0;c<vals.length;c++)insert.bindString(c+1,vals[c]);insert.executeInsert();}sql.setTransactionSuccessful();
   }finally{sql.endTransaction();}
   long inserted=SystemClock.elapsedRealtime()-start;
   start=SystemClock.elapsedRealtime();long[] counts=store.counts("large_test",false,"",null,null,null,"large_test");long countMs=SystemClock.elapsedRealtime()-start;
   check(counts[0]==25000&&counts[2]==8334,"SQL counts all records without loading full rows");
   start=SystemClock.elapsedRealtime();List<Store.Record> page=store.page("large_test",false,"",null,null,null,51,0,"large_test");long pageMs=SystemClock.elapsedRealtime()-start;
   check(page.size()==51&&page.get(0).a[0].equals("TEST_24999"),"bounded page and numeric route order");
   check(store.page("large_test",false,"",null,null,null,51,24950,"large_test").size()==50,"last page no records lost");
   start=SystemClock.elapsedRealtime();List<Long> ids=store.ids("large_test",false,"",null,null,null,"large_test");long idsMs=SystemClock.elapsedRealtime()-start;
   check(ids.size()==25000&&ids.get(0)==page.get(0).id,"light route IDs");
   check(store.counts("large_test",false,"","UR1",null,null,"large_test")[0]==2500,"indexed UR filter");
   List<String[]> visited=store.exportVisited("large_test");check(visited.size()==8335,"export visits only");visited=null;page=null;ids=null;
   Intent launch=new Intent(getTargetContext(),MainActivity.class);launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);activity=(MainActivity)startActivitySync(launch);
   final MainActivity screen=activity;final Store data=store;
   runOnMainSync(()->{screen.db=data;screen.user="large_test";screen.admin=false;screen.getPreferences(0).edit().putString("campaign_large_test","large_test").commit();screen.home();});
   long deadline=SystemClock.elapsedRealtime()+20000;
   final boolean[] ready={false};long maxHeartbeat=0;
   do{start=SystemClock.elapsedRealtime();runOnMainSync(()->ready[0]=screen.cards!=null&&screen.cards.getChildCount()>0);maxHeartbeat=Math.max(maxHeartbeat,SystemClock.elapsedRealtime()-start);if(!ready[0])Thread.sleep(100);}while(!ready[0]&&SystemClock.elapsedRealtime()<deadline);
   check(ready[0],"async home renders with 25000 records");
   runOnMainSync(()->{check(screen.cards.getChildCount()<=52,"UI bounded to 50 cards plus pagination");screen.onTrimMemory(android.content.ComponentCallbacks2.TRIM_MEMORY_COMPLETE);screen.onLowMemory();});
   check(store.counts("large_test",false,"",null,null,null,"large_test")[0]==25000,"memory reclaim never deletes data");
   String report="Synthetic Android API26 / 25000 records\nInsert ms: "+inserted+"\nSQL count ms: "+countMs+"\nFirst page (51 rows) ms: "+pageMs+"\nRoute IDs ms: "+idsMs+"\nMax UI heartbeat wait ms: "+maxHeartbeat+"\n";
   result.putString("stream",report+"PASS "+checks+" Android checks\n");runOnMainSync(()->screen.finish());store.close();ctx.deleteDatabase("releve.db");finish(Activity.RESULT_OK,result);
  }catch(Throwable e){result.putString("stream","FAIL "+android.util.Log.getStackTraceString(e));finish(Activity.RESULT_CANCELED,result);}
 }
}
