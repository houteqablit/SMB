package ma.releve.terrain.v320;
import java.io.*;
import java.nio.file.*;
import java.time.*;
import java.util.*;

public final class CoreTests {
    static int checks;
    interface Checked {void run()throws Exception;}
    static void check(boolean b,String name){checks++;if(!b)throw new AssertionError(name);}
    static void rejects(Checked f,String name)throws Exception{try{f.run();}catch(Exception e){checks++;return;}throw new AssertionError(name);}
    public static void main(String[] args)throws Exception {
        Path materials=Paths.get(args[0]);
        byte[] xlsx=Files.readAllBytes(materials.resolve("SmartMobilityTerrain_Modele_3_feuilles_COMPATIBLE.xlsx"));
        BundleImport b=BundleImport.read(xlsx,"releveur01");
        check(b.meters.size()==2,"two XLSX meters");check(b.anomalies.size()==3,"anomalies");check(b.types.size()==3,"local types");
        check(b.meters.get(0)[Model.SER].equals("00012345"),"leading zero serial");
        check(b.meters.get(0)[Model.TEL].equals("0612345678"),"leading zero phone");
        rejects(()->BundleImport.read(xlsx,"other"),"owner isolation");
        check(BundleImport.read(xlsx,null).meters.get(0)[Model.READER].equals("releveur01"),"admin import preserves source assignment");
        Map<String,byte[]> csv=new LinkedHashMap<>();
        for(String name:Arrays.asList("Releve","Anomalie","type_local"))csv.put(name+".csv",Files.readAllBytes(materials.resolve(name+".csv")));
        BundleImport c=BundleImport.read(BundleImport.zip(csv),"releveur01");check(c.meters.size()==2,"three CSV import");
        Map<String,byte[]> bad=new LinkedHashMap<>(csv);bad.remove("type_local.csv");rejects(()->BundleImport.read(BundleImport.zip(bad),"releveur01"),"missing catalog");
        Map<String,byte[]> empty=new LinkedHashMap<>(csv);empty.put("Anomalie.csv","Code anomalie;Libelle anomalie;Reseau;Cas consommation;Photo obligatoire;Deuxieme passage\n".getBytes("UTF-8"));rejects(()->BundleImport.read(BundleImport.zip(empty),"releveur01"),"empty catalog");
        rejects(()->BundleImport.read(Arrays.copyOf(xlsx,xlsx.length/2),"releveur01"),"truncated ZIP");
        Map<String,byte[]> extra=BundleImport.unzip(xlsx);extra.put("xl/workbook.xml",new String(extra.get("xl/workbook.xml"),"UTF-8").replace("</x:sheets>","<x:sheet name=\"Extra\" sheetId=\"4\" xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\" r:id=\"rId4\"/></x:sheets>").getBytes("UTF-8"));rejects(()->BundleImport.read(BundleImport.zip(extra),"releveur01"),"extra sheet");
        Map<String,byte[]> formula=BundleImport.unzip(xlsx);String sheet=new String(formula.get("xl/worksheets/sheet1.xml"),"UTF-8");sheet=sheet.replaceFirst("<c ","<c ").replaceFirst("</x:c>","<x:f>1+1</x:f></x:c>");formula.put("xl/worksheets/sheet1.xml",sheet.getBytes("UTF-8"));rejects(()->BundleImport.read(BundleImport.zip(formula),"releveur01"),"formula refused");
        List<String[]> invalidRows=new ArrayList<>();invalidRows.add(Model.headers());
        String[] invalid=TableFile.read(new ByteArrayInputStream(csv.get("Releve.csv"))).get(1).clone();invalid[14]="";invalidRows.add(invalid);
        check(TableFile.validateImport(invalidRows).get(0)[Model.THRESH].equals("0"),"missing threshold defaults to zero with populated mean");
        List<String[]> excelPrecision=TableFile.read(new ByteArrayInputStream(csv.get("Releve.csv")));
        int meanColumn=Arrays.asList(excelPrecision.get(0)).indexOf("Moyenne journaliere");
        excelPrecision.get(1)[meanColumn]="16.600000000000001";
        check(TableFile.validateImport(excelPrecision).get(0)[Model.MEAN].equals("16.6"),"Excel hidden precision normalized to two decimal places");
        excelPrecision.get(1)[meanColumn]="7.0000000000000007E-2";
        check(TableFile.validateImport(excelPrecision).get(0)[Model.MEAN].equals("0.07"),"Excel scientific positive value normalized");
        excelPrecision.get(1)[meanColumn]="-0.07";check(TableFile.validateImport(excelPrecision).get(0)[Model.MEAN].equals("0"),"negative mean defaults to zero");
        excelPrecision.get(1)[meanColumn]="1E9999";check(TableFile.validateImport(excelPrecision).get(0)[Model.MEAN].equals("0"),"excessive numeric exponent safely defaults to zero");
        check(TableFile.normalizeImportNumber("12,345").equals("12.35"),"HALF_UP two decimal rounding");
        check(TableFile.normalizeImportNumber("#VALEURMULTI").equals("0"),"Excel text error defaults to zero");
        check(TableFile.normalizeImportNumber("").equals("0"),"empty numeric field defaults to zero");
        List<String[]> badOld=TableFile.read(new ByteArrayInputStream(csv.get("Releve.csv")));
        badOld.get(1)[Arrays.asList(badOld.get(0)).indexOf("Ancien index")]="#VALEURMULTI";
        check(TableFile.validateImport(badOld).get(0)[Model.OLD].equals("0"),"invalid old index converted at import");
        check(Model.date("46290.9583").equals(Model.date("46290")),"Excel historical date time fraction preserves calendar day");
        List<String[]> duplicated=TableFile.read(new ByteArrayInputStream(csv.get("Releve.csv")));duplicated.add(duplicated.get(1));rejects(()->TableFile.validateImport(duplicated),"duplicate meter");
        List<String[]> badDate=TableFile.read(new ByteArrayInputStream(csv.get("Releve.csv")));badDate.get(1)[9]="2026-02-30";rejects(()->TableFile.validateImport(badDate),"invalid calendar date");
        Map<String,byte[]> wrongWidth=new LinkedHashMap<>(csv);wrongWidth.put("type_local.csv","Code type local;Libelle type local\nMAISON;Maison;extra\n".getBytes("UTF-8"));rejects(()->BundleImport.read(BundleImport.zip(wrongWidth),"releveur01"),"CSV inconsistent width");
        String[] row=Model.blank();row[Model.C]="00001";row[Model.OLD]="100";row[Model.PREV]="2026-09-01";row[Model.MEAN]="10";row[Model.THRESH]="30";
        LocalDate today=LocalDate.of(2026,9,11);
        check(!Model.assess(row,"170",today).abnormal,"exact lower bound");check(!Model.assess(row,"230",today).abnormal,"exact upper bound");
        check(Model.assess(row,"169",today).abnormal,"below bound");check(Model.assess(row,"231",today).abnormal,"above bound");
        check(Model.assess(row,"99",today).cas.equals("NEGATIF"),"negative case");check(Model.assess(row,"",today).cas.equals("SANS_INDEX"),"no index case");
        check(!Model.assess(row,"110",LocalDate.of(2026,9,1)).error.isEmpty(),"same date refused");check(!Model.assess(row,"110",LocalDate.of(2026,8,31)).error.isEmpty(),"earlier date refused");
        row[Model.MEAN]="0";check(Model.assess(row,"101",today).abnormal,"zero reference mean");
        row[Model.STATUS]="OUI";check(Model.assess(row,"",today).photo,"import photo requirement");
        row[Model.OLD]="";check(Model.assess(row,"1",today).cas.equals("SANS_REFERENCE"),"unlisted case");
        IndexConfirmation ic=new IndexConfirmation();
        check(!ic.accept("1250",true)&&ic.pending(),"first entry held");
        check(!ic.accept("1205",true)&&ic.first.equals("1205"),"mismatch becomes latest entry");
        check(!ic.accept("1250",true),"nonconsecutive identical value rejected");
        check(!ic.accept("1255",true),"new candidate needs repetition");
        check(ic.accept("1255",true),"consecutive identical entries accepted");
        ic.edited("1256");check(!ic.confirmed&&ic.first.isEmpty(),"edit resets");check(ic.accept("150",false),"normal index");

        check(DirectDrive.url("https://drive.google.com/file/d/ABCDEFGHIJKL/view").contains("id=ABCDEFGHIJKL"),"Drive link parsing");
        check(DirectDrive.url("https://docs.google.com/spreadsheets/d/ABCDEFGHIJKL/edit").contains("export?format=xlsx"),"Sheets link parsing");
        rejects(()->DirectDrive.url("https://drive.google.com.evil.test/file/d/ABCDEFGHIJKL/view"),"spoof host");rejects(()->DirectDrive.url("https://drive.google.com/drive/folders/ABCDEFGHIJKL"),"folder link");
        rejects(()->DirectDrive.checkContent("<html>Login</html>".getBytes("UTF-8")),"HTML refused");
        Path photos=Files.createTempDirectory("smb-core-photos");
        List<String[]> data=new ArrayList<>();String[] record=b.meters.get(0).clone();record[Model.NEW]="1300";record[Model.NEWTEL]="0700000000";record[Model.NEWLOCAL]="COMMERCE";record[Model.NEWLOCAL_LABEL]="Commerce";record[Model.NEWUR]="UR02";record[Model.PHOTO]="demo.jpg";data.add(record);
        Files.write(photos.resolve("demo.jpg"),new byte[]{1,2,3,4});Path source=photos.resolve("source.bin");Files.write(source,xlsx);
        ByteArrayOutputStream out=new ByteArrayOutputStream();
        List<String[]> ar=new ArrayList<>();ar.add(new String[]{"Code","Libelle","Reseaux","Cas consommation","Photo obligatoire","Deuxieme passage"});ar.addAll(b.anomalies);
        List<String[]> tr=new ArrayList<>();tr.add(new String[]{"Code type local","Libelle type local"});tr.addAll(b.types);
        BackupPack.write(out,"releveur01",data,photos.toFile(),source.toFile(),ar,tr);
        BackupPack.Snapshot snap=BackupPack.read(new ByteArrayInputStream(out.toByteArray()),"releveur01");
        check(Arrays.equals(snap.rows.get(0),record),"all current backup fields");check(Arrays.equals(snap.source,xlsx),"backup source");check(snap.photos.size()==1,"backup photos");check(snap.anomalies.size()==3&&snap.types.size()==3,"backup catalogs");
        Map<String,byte[]> legacyParts=BundleImport.unzip(out.toByteArray());ByteArrayOutputStream legacyData=new ByteArrayOutputStream();DataOutputStream legacy=new DataOutputStream(legacyData);
        BackupPack.string(legacy,"SmartMobilityBackup");legacy.writeInt(1);BackupPack.string(legacy,"releveur01");legacy.writeInt(42);for(int n=0;n<42;n++)BackupPack.string(legacy,Model.FIELDS[n]);legacy.writeInt(1);for(int n=0;n<42;n++)BackupPack.string(legacy,record[n]);legacy.flush();legacyParts.put("backup.dat",legacyData.toByteArray());
        BackupPack.Snapshot legacySnapshot=BackupPack.read(new ByteArrayInputStream(BundleImport.zip(legacyParts)),"releveur01");
        check(legacySnapshot.rows.get(0).length==Model.FIELDS.length&&legacySnapshot.rows.get(0)[Model.NEWUR].isEmpty()&&legacySnapshot.rows.get(0)[Model.NEWLOCAL_LABEL].isEmpty(),"legacy 42-field backup restored with empty extension fields");
        check(legacySnapshot.rows.get(0)[Model.SER].equals(record[Model.SER])&&legacySnapshot.rows.get(0)[Model.UUID_].equals(record[Model.UUID_]),"legacy backup identity preserved");
        for(int width:new int[]{44,46}){
            ByteArrayOutputStream oldBytes=new ByteArrayOutputStream();DataOutputStream oldData=new DataOutputStream(oldBytes);BackupPack.string(oldData,"SmartMobilityBackup");oldData.writeInt(1);BackupPack.string(oldData,"releveur01");oldData.writeInt(width);for(int n=0;n<width;n++)BackupPack.string(oldData,Model.FIELDS[n]);oldData.writeInt(1);for(int n=0;n<width;n++)BackupPack.string(oldData,n==Model.DOWNLOADED?"OUI":record[n]);oldData.close();legacyParts.put("backup.dat",oldBytes.toByteArray());BackupPack.Snapshot oldSnapshot=BackupPack.read(new ByteArrayInputStream(BundleImport.zip(legacyParts)),"releveur01");
            check(oldSnapshot.rows.get(0).length==49&&oldSnapshot.rows.get(0)[Model.NEWIDENT].isEmpty()&&oldSnapshot.rows.get(0)[Model.PREVX].isEmpty(),"legacy backup "+width+" fields pads new data");if(width==46)check(oldSnapshot.rows.get(0)[Model.DOWNLOADED].equals("OUI"),"6.1.0 backup keeps downloaded mask");
        }
        rejects(()->BackupPack.read(new ByteArrayInputStream(out.toByteArray()),"other"),"backup owner");
        Files.delete(photos.resolve("demo.jpg"));rejects(()->BackupPack.write(new ByteArrayOutputStream(),"releveur01",data,photos.toFile(),null),"missing backup photo refused");
        ByteArrayOutputStream exported=new ByteArrayOutputStream();List<String[]> export=new ArrayList<>();export.add(Model.LABELS);export.add(record);TableFile.writeXlsx(exported,export);
        List<String[]> reimport=TableFile.read(new ByteArrayInputStream(exported.toByteArray()));check(Arrays.equals(reimport.get(1),record),"export XLSX roundtrip originals and new values");
        rejects(()->TableFile.read(new ByteArrayInputStream("a;b\n\"unfinished".getBytes("UTF-8"))),"malformed CSV");
        rejects(()->TableFile.read(new ByteArrayInputStream(new byte[]{65,59,66,10,(byte)0xC3,40})),"invalid UTF-8 refused");
        check(GpsReference.normalize("-6,123456789","34,123456789")[0].equals("-6.123456789"),"reference GPS comma and full precision");
        for(String[] pair:new String[][]{{"",""},{"12",""},{"abc","34"},{"NaN","34"},{"181","34"},{"10","91"},{"0","0"},{"1e99999","1"}})check(GpsReference.normalize(pair[0],pair[1])[0].isEmpty(),"invalid reference pair becomes absent");
        check(!GpsReference.normalize("0","34")[0].isEmpty(),"zero longitude alone is valid");
        String[] gpsRow=Model.blank();gpsRow[Model.PREVX]="-6";gpsRow[Model.PREVY]="34";gpsRow[Model.X]="-7";gpsRow[Model.Y]="33";
        check(GpsReference.forMap(gpsRow)[0].equals("-6"),"map prefers imported reference to newer visit");gpsRow[Model.PREVY]="";check(GpsReference.forMap(gpsRow)[0].equals("-7"),"legacy visit fallback without imported reference");
        List<String[]> gpsTable=TableFile.read(new ByteArrayInputStream(xlsx));String[] gpsHeader=Arrays.copyOf(gpsTable.get(0),gpsTable.get(0).length+2);int gpsAt=gpsHeader.length-2;gpsHeader[gpsAt]="GPS X precedent";gpsHeader[gpsAt+1]="GPS Y precedent";
        String[] gpsData=Arrays.copyOf(gpsTable.get(1),gpsHeader.length);gpsData[gpsAt]="-6,123456789";gpsData[gpsAt+1]="34,123456789";List<String[]> withGps=Arrays.asList(gpsHeader,gpsData);
        String[] importedGps=TableFile.validateImport(withGps).get(0);check(importedGps[Model.PREVX].equals("-6.123456789")&&importedGps[Model.X].isEmpty(),"import previous GPS without pre-filling observed GPS");
        ByteArrayOutputStream gpsBytes=new ByteArrayOutputStream();TableFile.writeXlsx(gpsBytes,withGps);check(TableFile.validateImport(TableFile.read(new ByteArrayInputStream(gpsBytes.toByteArray()))).get(0)[Model.PREVY].equals("34.123456789"),"real Excel optional GPS headers");
        gpsData[gpsAt]="INVALIDE";check(TableFile.validateImport(withGps).get(0)[Model.PREVX].isEmpty(),"invalid GPS does not reject valid contract");
        check(IdentifierInput.format("001234500").equals("001-2345-00"),"identifier mask preserves leading zero");check(IdentifierInput.format("1234").equals("123-4"),"partial typing formats progressively");
        check(IdentifierInput.valid("001-2345-00",true)&&!IdentifierInput.valid("001234500",true)&&!IdentifierInput.valid("001-2345-0",true),"strict nine digit formatted mask");
        check(IdentifierInput.valid("084_000100/EA",false)&&!IdentifierInput.valid("084_000100/EA",true),"free format supports historical identifiers");check(!IdentifierInput.valid("abc\n123",false)&&!IdentifierInput.valid("",false),"empty and control characters refused");
        System.out.println("PASS "+checks+" host checks");
    }
}
