#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
export PATH="${SMB_JDK_HOME:-/workspace/tools/jdk17}/bin:$PATH"
SDK=${ANDROID_SDK_ROOT:-/workspace/android-sdk}
TOOLS="$SDK/build-tools/35.0.0"
ADB="$SDK/platform-tools/adb"
JAR="$SDK/platforms/android-35/android.jar"
RUNNER=${1:-DeviceTests}
case "$RUNNER" in DeviceTests|VisualTests|LargeDataTests|NewFeaturesTests|NavigationProgressTests|Release610Tests|Reference611Tests) ;; *) exit 2 ;; esac
mkdir -p build/device-classes build/device-dex
cat > build/TestManifest.xml <<XML
<manifest xmlns:android="http://schemas.android.com/apk/res/android" package="ma.releve.terrain.v320.tests"><uses-sdk android:minSdkVersion="26" android:targetSdkVersion="35"/><application android:label="SMB Tests"/><instrumentation android:name="ma.releve.terrain.v320.$RUNNER" android:targetPackage="ma.releve.terrain.v320"/></manifest>
XML
javac --release 17 -encoding UTF-8 -cp "$JAR:build/classes" -d build/device-classes "tests/ma/releve/terrain/v320/$RUNNER.java"
find build/device-classes -name '*.class' > build/device-sources.txt
"$TOOLS/d8" --lib "$JAR" --classpath build/classes --min-api 26 --output build/device-dex @build/device-sources.txt
"$TOOLS/aapt2" link -o build/device-base.apk -I "$JAR" --manifest build/TestManifest.xml
(cd build/device-dex && zip -q ../device-base.apk classes*.dex)
"$TOOLS/zipalign" -f 4 build/device-base.apk build/device-aligned.apk
"$TOOLS/apksigner" sign --ks "${SMB_SIGN_DIR:-/workspace/smb-signing}/development.jks" --ks-pass pass:changeit --out build/DeviceTests.apk build/device-aligned.apk
"$ADB" install --no-incremental -r build/SmartMobilityTerrain-6.1.1.apk
"$ADB" install --no-incremental -r build/DeviceTests.apk
"$ADB" shell pm grant ma.releve.terrain.v320 android.permission.ACCESS_COARSE_LOCATION
"$ADB" shell pm grant ma.releve.terrain.v320 android.permission.ACCESS_FINE_LOCATION
"$ADB" shell settings put secure location_mode 3
"$ADB" shell am instrument -w -r ma.releve.terrain.v320.tests/ma.releve.terrain.v320.$RUNNER | tee build/device-test-results.txt
# Android's am command can exit zero even on an instrumentation failure.
rg -q '^INSTRUMENTATION_CODE: -1' build/device-test-results.txt
rg -q 'PASS [0-9]+ Android checks' build/device-test-results.txt
