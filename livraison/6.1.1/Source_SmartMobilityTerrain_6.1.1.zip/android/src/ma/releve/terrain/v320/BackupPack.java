package ma.releve.terrain.v320;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

public final class BackupPack {

    public static final class Snapshot {
        List<String[]> anomalies,types;
        public byte[] source;
        public List<String[]> rows = new ArrayList();
        public Map<String, byte[]> photos = new HashMap();
    }

    static void string(DataOutputStream dataOutputStream, String str) throws IOException {
        byte[] bytes = str.getBytes(StandardCharsets.UTF_8);
        dataOutputStream.writeInt(bytes.length);
        dataOutputStream.write(bytes);
    }

    static String string(DataInputStream dataInputStream) throws IOException {
        int i = dataInputStream.readInt();
        if (i < 0 || i > 1048576) {
            throw new IOException("Texte sauvegardé trop long.");
        }
        byte[] bArr = new byte[i];
        dataInputStream.readFully(bArr);
        return new String(bArr, StandardCharsets.UTF_8);
    }

    public static void write(OutputStream outputStream, String str, List<String[]> list, File file, File file2) throws Exception {
        write(outputStream,str,list,file,file2,null,null);
    }
    public static void write(OutputStream outputStream, String str, List<String[]> list, File file, File file2,List<String[]> anomalies,List<String[]> types) throws Exception {
        ZipOutputStream zipOutputStream = new ZipOutputStream(outputStream);
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        DataOutputStream dataOutputStream = new DataOutputStream(byteArrayOutputStream);
        string(dataOutputStream, "SmartMobilityBackup");
        dataOutputStream.writeInt(1);
        string(dataOutputStream, str);
        dataOutputStream.writeInt(Model.FIELDS.length);
        for (String str2 : Model.FIELDS) {
            string(dataOutputStream, str2);
        }
        dataOutputStream.writeInt(list.size());
        for (String[] strArr : list) {
            if (strArr.length != Model.FIELDS.length || !strArr[23].equals(str)) {
                throw new IOException("Sauvegarde d’un autre compte refusée.");
            }
            for (String str3 : strArr) {
                string(dataOutputStream, str3);
            }
        }
        dataOutputStream.flush();
        zipOutputStream.putNextEntry(new ZipEntry("backup.dat"));
        zipOutputStream.write(byteArrayOutputStream.toByteArray());
        zipOutputStream.closeEntry();
        ArrayList arrayList = new ArrayList();
        String[] exportHeader=java.util.Arrays.copyOf(Model.LABELS,Model.LABELS.length+1);
        exportHeader[Model.LABELS.length]="Libelle anomalie";arrayList.add(exportHeader);
        java.util.Map<String,String> labels=new java.util.HashMap<>();
        if(anomalies!=null)for(int n=1;n<anomalies.size();n++)labels.put(anomalies.get(n)[0],anomalies.get(n)[1]);
        java.util.Map<String,String> typeLabels=new java.util.HashMap<>();if(types!=null)for(int n=1;n<types.size();n++)typeLabels.put(types.get(n)[0],types.get(n)[1]);
        for(String[] original:list){
            String[] exported=java.util.Arrays.copyOf(original,exportHeader.length);
            exported[Model.LABELS.length]=labels.containsKey(original[8])?labels.get(original[8]):"";
            if(exported[Model.NEWLOCAL_LABEL].isEmpty())exported[Model.NEWLOCAL_LABEL]=typeLabels.containsKey(original[Model.NEWLOCAL])?typeLabels.get(original[Model.NEWLOCAL]):"";
            arrayList.add(exported);
        }
        zipOutputStream.putNextEntry(new ZipEntry("releves.xlsx"));
        ByteArrayOutputStream byteArrayOutputStream2 = new ByteArrayOutputStream();
        TableFile.writeXlsx(byteArrayOutputStream2, arrayList);
        zipOutputStream.write(byteArrayOutputStream2.toByteArray());
        zipOutputStream.closeEntry();
        zipOutputStream.putNextEntry(new ZipEntry("releves.csv"));
        ByteArrayOutputStream byteArrayOutputStream3 = new ByteArrayOutputStream();
        TableFile.writeCsv(byteArrayOutputStream3, arrayList);
        zipOutputStream.write(byteArrayOutputStream3.toByteArray());
        zipOutputStream.closeEntry();
        HashSet hashSet = new HashSet();
        Iterator<String[]> it = list.iterator();
        while (it.hasNext()) {
            String str4 = it.next()[27];
            if (!str4.isEmpty() && hashSet.add(str4)) {
                if (!str4.matches("[A-Za-z0-9_.-]+\\.jpg")) {
                    throw new IOException("Nom photo invalide.");
                }
                File file3 = new File(file, str4);
                if (!file3.isFile()) {
                    throw new IOException("Photo manquante : " + str4);
                }
                file(zipOutputStream, "photos/" + str4, file3);
            }
        }
        if (file2 != null && file2.isFile()) {
            file(zipOutputStream, "fichier_source.bin", file2);
        }
        if(anomalies!=null && types!=null) {
            ByteArrayOutputStream a=new ByteArrayOutputStream(),t=new ByteArrayOutputStream();
            TableFile.writeCsv(a,anomalies);TableFile.writeCsv(t,types);
            zipOutputStream.putNextEntry(new ZipEntry("catalogues/Anomalie.csv"));zipOutputStream.write(a.toByteArray());zipOutputStream.closeEntry();
            zipOutputStream.putNextEntry(new ZipEntry("catalogues/type_local.csv"));zipOutputStream.write(t.toByteArray());zipOutputStream.closeEntry();
        }
        zipOutputStream.finish();
        zipOutputStream.flush();
    }

    static void file(ZipOutputStream zipOutputStream, String str, File file) throws IOException {
        zipOutputStream.putNextEntry(new ZipEntry(str));
        FileInputStream fileInputStream = new FileInputStream(file);
        try {
            byte[] bArr = new byte[8192];
            while (true) {
                int i = fileInputStream.read(bArr);
                if (i == -1) {
                    fileInputStream.close();
                    zipOutputStream.closeEntry();
                    return;
                }
                zipOutputStream.write(bArr, 0, i);
            }
        } catch (Throwable th) {
            try {
                fileInputStream.close();
            } catch (Throwable th2) {
                th.addSuppressed(th2);
            }
            throw th;
        }
    }

    public static Snapshot read(InputStream inputStream, String str) throws Exception {
        ZipInputStream zipInputStream = new ZipInputStream(inputStream);
        HashMap map = new HashMap();
        long length = 0;
        int i = 0;
        while (true) {
            ZipEntry nextEntry = zipInputStream.getNextEntry();
            if (nextEntry == null) {
                if (!map.containsKey("backup.dat")) {
                    throw new IOException("Sauvegarde SmartMobility attendue.");
                }
                DataInputStream dataInputStream = new DataInputStream(new ByteArrayInputStream((byte[]) map.get("backup.dat")));
                if (!string(dataInputStream).equals("SmartMobilityBackup") || dataInputStream.readInt() != 1 || !string(dataInputStream).equals(str)) {
                    throw new IOException("Sauvegarde incompatible ou d’un autre releveur.");
                }
                int savedFields=dataInputStream.readInt();
                if(savedFields!=42&&savedFields!=44&&savedFields!=46&&savedFields!=Model.FIELDS.length)throw new IOException("Format des champs incompatible.");
                for(int column=0;column<savedFields;column++)if(!string(dataInputStream).equals(Model.FIELDS[column]))throw new IOException("Format des champs incompatible.");
                int i2 = dataInputStream.readInt();
                if (i2 < 0 || i2 > 100000) {
                    throw new IOException("Nombre de compteurs invalide.");
                }
                Snapshot snapshot = new Snapshot();
                HashSet hashSet = new HashSet();
                HashSet hashSet2 = new HashSet();
                for (int i3 = 0; i3 < i2; i3++) {
                    int length2 = Model.FIELDS.length;
                    String[] strArr = Model.blank();
                    for (int i4 = 0; i4 < savedFields; i4++) {
                        strArr[i4] = string(dataInputStream);
                    }
                    if (!strArr[23].equals(str) || strArr[30].isEmpty() || !hashSet.add(strArr[30])) {
                        throw new IOException("Propriétaire ou identité invalide.");
                    }
                    if (!hashSet2.add(strArr[36] + "\u0000" + strArr[14] + "\u0000" + strArr[0] + "\u0000" + strArr[4] + "\u0000" + strArr[16])) {
                        throw new IOException("Compteur répété dans la sauvegarde.");
                    }
                    String str3 = strArr[27];
                    if (!str3.isEmpty()) {
                        if (!str3.matches("[A-Za-z0-9_.-]+\\.jpg") || !map.containsKey("photos/" + str3)) {
                            throw new IOException("Photo absente de la sauvegarde.");
                        }
                        snapshot.photos.put(str3, (byte[]) map.get("photos/" + str3));
                    }
                    snapshot.rows.add(strArr);
                }
                if (dataInputStream.read() != -1) {
                    throw new IOException("Sauvegarde incohérente.");
                }
                if(map.containsKey("catalogues/Anomalie.csv") && map.containsKey("catalogues/type_local.csv")) {
                    snapshot.anomalies=BundleImport.catalog(TableFile.read(new ByteArrayInputStream((byte[])map.get("catalogues/Anomalie.csv"))),true);
                    List<String[]> typeTable=TableFile.read(new ByteArrayInputStream((byte[])map.get("catalogues/type_local.csv")));
                    snapshot.types=typeTable.size()==1?new ArrayList<>():BundleImport.catalog(typeTable,false);
                }
                snapshot.source = (byte[]) map.get("fichier_source.bin");
                return snapshot;
            }
            i++;
            if (i > 100005) {
                throw new IOException("Archive trop complexe.");
            }
            String name = nextEntry.getName();
            if (map.containsKey(name)) {
                throw new IOException("Entrée répétée dans l’archive.");
            }
            byte[] bArrLimited = TableFile.limited(zipInputStream, 104857600L);
            length += bArrLimited.length;
            if (length > 314572800) {
                throw new IOException("Sauvegarde trop volumineuse pour une restauration en mémoire.");
            }
            map.put(name, bArrLimited);
        }
    }
}
