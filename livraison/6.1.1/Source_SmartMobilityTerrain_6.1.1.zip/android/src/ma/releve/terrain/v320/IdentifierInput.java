package ma.releve.terrain.v320;
/** Identifiers are text, never numbers: leading zeros must survive. */
public final class IdentifierInput {
 public static String format(String value){
  if(!value.matches("[0-9-]*"))return value;
  String digits=value.replace("-","");if(digits.length()>9)return value;
  StringBuilder b=new StringBuilder();for(int n=0;n<digits.length();n++){if(n==3||n==7)b.append('-');b.append(digits.charAt(n));}return b.toString();
 }
 public static boolean valid(String value,boolean mask){return value!=null&&!value.trim().isEmpty()&&value.length()<=128&&!value.matches("(?s).*[\\p{Cntrl}].*")&&(!mask||value.matches("[0-9]{3}-[0-9]{4}-[0-9]{2}"));}
}
