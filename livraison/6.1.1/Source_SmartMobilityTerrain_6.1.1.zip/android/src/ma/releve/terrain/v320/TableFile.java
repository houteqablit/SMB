package ma.releve.terrain.v320;

import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.text.Normalizer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;
import javax.xml.parsers.SAXParserFactory;
import org.xml.sax.Attributes;
import org.xml.sax.EntityResolver;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.DefaultHandler;

public final class TableFile {
    public static final String[] INPUT = Model.headers();
    public static final String[] OUTPUT = Model.LABELS;

    static String xml(String str) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < str.length(); i++) {
            char cCharAt = str.charAt(i);
            if (cCharAt == '\t' || cCharAt == '\n' || cCharAt == '\r' || cCharAt >= ' ') {
                sb.append(cCharAt);
            }
        }
        return sb.toString().replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;");
    }

    static void entry(ZipOutputStream zipOutputStream, String str, String str2) throws IOException {
        ZipEntry entry=new ZipEntry(str);entry.setTime(0);zipOutputStream.putNextEntry(entry);
        zipOutputStream.write(str2.getBytes(StandardCharsets.UTF_8));
        zipOutputStream.closeEntry();
    }

    static String column(int i) {
        int i2 = i + 1;
        String str = "";
        while (i2 > 0) {
            int i3 = i2 - 1;
            str = ((char) ((i3 % 26) + 65)) + str;
            i2 = i3 / 26;
        }
        return str;
    }

    public static void writeXlsx(OutputStream outputStream, List<String[]> list) throws IOException {
        ZipOutputStream zipOutputStream = new ZipOutputStream(outputStream);
        entry(zipOutputStream, "[Content_Types].xml", "<?xml version=\"1.0\" encoding=\"UTF-8\"?><Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\"><Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/><Default Extension=\"xml\" ContentType=\"application/xml\"/><Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/><Override PartName=\"/xl/worksheets/sheet1.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/><Override PartName=\"/xl/styles.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml\"/></Types>");
        entry(zipOutputStream, "_rels/.rels", "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"xl/workbook.xml\"/></Relationships>");
        entry(zipOutputStream, "xl/workbook.xml", "<workbook xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\"><sheets><sheet name=\"Releve\" sheetId=\"1\" r:id=\"rId1\"/></sheets></workbook>");
        entry(zipOutputStream, "xl/_rels/workbook.xml.rels", "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet1.xml\"/><Relationship Id=\"rId2\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles\" Target=\"styles.xml\"/></Relationships>");
        entry(zipOutputStream, "xl/styles.xml", "<styleSheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\"><fonts count=\"2\"><font><sz val=\"11\"/><name val=\"Calibri\"/></font><font><b/><color rgb=\"FFFFFFFF\"/><sz val=\"11\"/><name val=\"Calibri\"/></font></fonts><fills count=\"3\"><fill><patternFill patternType=\"none\"/></fill><fill><patternFill patternType=\"gray125\"/></fill><fill><patternFill patternType=\"solid\"><fgColor rgb=\"FF122D48\"/><bgColor indexed=\"64\"/></patternFill></fill></fills><borders count=\"1\"><border/></borders><cellStyleXfs count=\"1\"><xf/></cellStyleXfs><cellXfs count=\"2\"><xf numFmtId=\"49\" fontId=\"0\" fillId=\"0\" borderId=\"0\" xfId=\"0\" applyNumberFormat=\"1\"><alignment vertical=\"top\" wrapText=\"1\"/></xf><xf fontId=\"1\" fillId=\"2\" borderId=\"0\" xfId=\"0\" applyFont=\"1\" applyFill=\"1\"/></cellXfs><cellStyles count=\"1\"><cellStyle name=\"Normal\" xfId=\"0\" builtinId=\"0\"/></cellStyles></styleSheet>");
        ZipEntry sheet=new ZipEntry("xl/worksheets/sheet1.xml");sheet.setTime(0);zipOutputStream.putNextEntry(sheet);
        OutputStreamWriter outputStreamWriter = new OutputStreamWriter(zipOutputStream, StandardCharsets.UTF_8);
        outputStreamWriter.write("<worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\"><sheetViews><sheetView workbookViewId=\"0\"><pane ySplit=\"1\" topLeftCell=\"A2\" activePane=\"bottomLeft\" state=\"frozen\"/></sheetView></sheetViews><cols><col min=\"1\" max=\"" + list.get(0).length + "\" width=\"23\" style=\"0\" customWidth=\"1\"/><col min=\"3\" max=\"3\" width=\"42\" style=\"0\" customWidth=\"1\"/><col min=\"10\" max=\"10\" width=\"48\" style=\"0\" customWidth=\"1\"/></cols><sheetData>");
        int i = 0;
        while (i < list.size()) {
            int i2 = i + 1;
            outputStreamWriter.write("<row r=\"" + i2 + "\">");
            String[] strArr = list.get(i);
            for (int i3 = 0; i3 < strArr.length; i3++) {
                outputStreamWriter.write("<c r=\"" + column(i3) + i2 + "\" t=\"inlineStr\" s=\"" + (i == 0 ? 1 : 0) + "\"><is><t xml:space=\"preserve\">" + xml(strArr[i3] == null ? "" : strArr[i3]) + "</t></is></c>");
            }
            outputStreamWriter.write("</row>");
            i = i2;
        }
        outputStreamWriter.write("</sheetData><autoFilter ref=\"A1:" + column(list.get(0).length - 1) + list.size() + "\"/></worksheet>");
        outputStreamWriter.flush();
        zipOutputStream.closeEntry();
        zipOutputStream.finish();
        zipOutputStream.flush();
    }

    public static List<String[]> read(InputStream inputStream) throws Exception {
        BufferedInputStream bufferedInputStream = new BufferedInputStream(inputStream);
        bufferedInputStream.mark(4);
        int i = bufferedInputStream.read();
        int i2 = bufferedInputStream.read();
        bufferedInputStream.reset();
        return (i == 80 && i2 == 75) ? readXlsx(bufferedInputStream) : readCsv(bufferedInputStream);
    }

    static byte[] limited(InputStream inputStream, long j) throws IOException {
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        byte[] bArr = new byte[8192];
        while (true) {
            int i = inputStream.read(bArr);
            if (i == -1) {
                return byteArrayOutputStream.toByteArray();
            }
            if (byteArrayOutputStream.size() + i > j) {
                throw new IOException("Fichier trop volumineux.");
            }
            byteArrayOutputStream.write(bArr, 0, i);
        }
    }

    static void parse(byte[] bArr, DefaultHandler defaultHandler) throws Exception {
        for (byte b : bArr) {
            if (b == 0) {
                throw new IOException("XML UTF-8 attendu.");
            }
        }
        String str = new String(bArr, StandardCharsets.UTF_8);
        if (str.toUpperCase(Locale.ROOT).contains("<!DOCTYPE") || str.toUpperCase(Locale.ROOT).contains("<!ENTITY")) {
            throw new IOException("XML non autorisé.");
        }
        SAXParserFactory sAXParserFactoryNewInstance = SAXParserFactory.newInstance();
        sAXParserFactoryNewInstance.setNamespaceAware(true);
        try {
            sAXParserFactoryNewInstance.setFeature("http://xml.org/sax/features/external-general-entities", false);
            sAXParserFactoryNewInstance.setFeature("http://xml.org/sax/features/external-parameter-entities", false);
        } catch (Exception e) {
        }
        XMLReader xMLReader = sAXParserFactoryNewInstance.newSAXParser().getXMLReader();
        xMLReader.setEntityResolver(new EntityResolver() { // from class: ma.releve.terrain.v320.TableFile$$ExternalSyntheticLambda0
            @Override // org.xml.sax.EntityResolver
            public final InputSource resolveEntity(String str2, String str3) throws SAXException, IOException {
                return TableFile.lambda$parse$0(str2, str3);
            }
        });
        xMLReader.setContentHandler(defaultHandler);
        xMLReader.parse(new InputSource(new ByteArrayInputStream(bArr)));
    }

    static /* synthetic */ InputSource lambda$parse$0(String str, String str2) throws SAXException, IOException {
        throw new SAXException("Entité externe interdite.");
    }

    static List<String[]> readXlsx(InputStream inputStream) throws Exception {
        HashMap map = new HashMap();
        ZipInputStream zipInputStream = new ZipInputStream(inputStream);
        long length = 0;
        int i = 0;
        while (true) {
            ZipEntry nextEntry = zipInputStream.getNextEntry();
            if (nextEntry == null) {
                final ArrayList arrayList = new ArrayList();
                if (map.containsKey("xl/sharedStrings.xml")) {
                    parse((byte[]) map.get("xl/sharedStrings.xml"), new DefaultHandler() { // from class: ma.releve.terrain.v320.TableFile.1
                        boolean t;
                        StringBuilder value;

                        @Override // org.xml.sax.helpers.DefaultHandler, org.xml.sax.ContentHandler
                        public void characters(char[] cArr, int i2, int i3) {
                            if (!this.t || this.value == null) {
                                return;
                            }
                            this.value.append(cArr, i2, i3);
                        }

                        @Override // org.xml.sax.helpers.DefaultHandler, org.xml.sax.ContentHandler
                        public void endElement(String str, String str2, String str3) {
                            if (str2.equals("t")) {
                                this.t = false;
                            }
                            if (str2.equals("si")) {
                                arrayList.add(this.value.toString());
                            }
                        }

                        @Override // org.xml.sax.helpers.DefaultHandler, org.xml.sax.ContentHandler
                        public void startElement(String str, String str2, String str3, Attributes attributes) {
                            if (str2.equals("si")) {
                                this.value = new StringBuilder();
                            }
                            if (str2.equals("t")) {
                                this.t = true;
                            }
                        }
                    });
                }
                final String[] strArr = {null};
                final String[] strArr2 = {null};
                if (!map.containsKey("xl/workbook.xml") || !map.containsKey("xl/_rels/workbook.xml.rels")) {
                    throw new IOException("Classeur XLSX invalide.");
                }
                parse((byte[]) map.get("xl/workbook.xml"), new DefaultHandler() { // from class: ma.releve.terrain.v320.TableFile.2
                    @Override // org.xml.sax.helpers.DefaultHandler, org.xml.sax.ContentHandler
                    public void startElement(String str, String str2, String str3, Attributes attributes) {
                        if (str2.equals("sheet") && strArr[0] == null) {
                            strArr[0] = attributes.getValue("http://schemas.openxmlformats.org/officeDocument/2006/relationships", "id");
                            if (strArr[0] == null) {
                                strArr[0] = attributes.getValue("r:id");
                            }
                        }
                    }
                });
                parse((byte[]) map.get("xl/_rels/workbook.xml.rels"), new DefaultHandler() { // from class: ma.releve.terrain.v320.TableFile.3
                    @Override // org.xml.sax.helpers.DefaultHandler, org.xml.sax.ContentHandler
                    public void startElement(String str, String str2, String str3, Attributes attributes) {
                        if (str2.equals("Relationship") && Objects.equals(attributes.getValue("Id"), strArr[0])) {
                            strArr2[0] = attributes.getValue("Target");
                        }
                    }
                });
                if (strArr2[0] == null) {
                    throw new IOException("Première feuille introuvable.");
                }
                String strSubstring = strArr2[0].startsWith("/") ? strArr2[0].substring(1) : "xl/" + strArr2[0];
                while (strSubstring.contains("/./")) {
                    strSubstring = strSubstring.replace("/./", "/");
                }
                if (!map.containsKey(strSubstring)) {
                    throw new IOException("Feuille non prise en charge.");
                }
                final ArrayList arrayList2 = new ArrayList();
                parse((byte[]) map.get(strSubstring), new DefaultHandler() { // from class: ma.releve.terrain.v320.TableFile.4
                    int col;
                    boolean collect;
                    boolean formula;
                    int max;
                    Map<Integer, String> row;
                    String type;
                    StringBuilder value;

                    @Override // org.xml.sax.helpers.DefaultHandler, org.xml.sax.ContentHandler
                    public void startElement(String str, String str2, String str3, Attributes attributes) throws SAXException {
                        if (str2.equals("row")) {
                            if (arrayList2.size() > 50000) {
                                throw new SAXException("Maximum 50 000 lignes.");
                            }
                            this.row = new HashMap();
                            this.max = 0;
                        }
                        if (str2.equals("c")) {
                            String value = attributes.getValue("r");
                            this.col = 0;
                            if (value == null) {
                                throw new SAXException("Référence de cellule absente.");
                            }
                            for (char c : value.toCharArray()) {
                                if (c < 'A' || c > 'Z') {
                                    break;
                                }
                                this.col = (((this.col * 26) + c) - 65) + 1;
                            }
                            this.col--;
                            if (this.col < 0 || this.col > 100) {
                                throw new SAXException("Maximum 101 colonnes.");
                            }
                            this.max = Math.max(this.max, this.col);
                            this.type = attributes.getValue("t");
                            this.value = new StringBuilder();
                            this.formula = false;
                        }
                        if (str2.equals("f")) {
                            this.formula = true;
                        }
                        if (str2.equals("v") || str2.equals("t")) {
                            this.collect = true;
                        }
                    }

                    @Override // org.xml.sax.helpers.DefaultHandler, org.xml.sax.ContentHandler
                    public void characters(char[] cArr, int i2, int i3) {
                        if (!this.collect || this.value == null) {
                            return;
                        }
                        this.value.append(cArr, i2, i3);
                    }

                    @Override // org.xml.sax.helpers.DefaultHandler, org.xml.sax.ContentHandler
                    public void endElement(String str, String str2, String str3) throws SAXException {
                        if (str2.equals("v") || str2.equals("t")) {
                            this.collect = false;
                        }
                        if (str2.equals("c")) {
                            if (this.formula) {
                                throw new SAXException("Remplacez les formules Excel par leurs valeurs avant l’import.");
                            }
                            String string = this.value.toString();
                            if ("s".equals(this.type)) {
                                try {
                                    string = (String) arrayList.get(Integer.parseInt(string));
                                } catch (Exception e) {
                                    throw new SAXException("Texte Excel invalide.");
                                }
                            }
                            this.row.put(Integer.valueOf(this.col), string);
                        }
                        if (str2.equals("row")) {
                            String[] strArr3 = new String[this.max + 1];
                            Arrays.fill(strArr3, "");
                            for (Map.Entry<Integer, String> entry : this.row.entrySet()) {
                                strArr3[entry.getKey().intValue()] = entry.getValue();
                            }
                            arrayList2.add(strArr3);
                        }
                    }
                });
                return arrayList2;
            }
            i++;
            if (i > 500) {
                throw new IOException("Classeur trop complexe.");
            }
            byte[] bArrLimited = limited(zipInputStream, 33554432L);
            length += bArrLimited.length;
            if (length > 104857600) {
                throw new IOException("Classeur trop volumineux.");
            }
            map.put(nextEntry.getName(), bArrLimited);
        }
    }

    static List<String[]> readCsv(InputStream inputStream) throws IOException {
        int i;
        int i2;
        String str;
        try {
            str = StandardCharsets.UTF_8.newDecoder().onMalformedInput(java.nio.charset.CodingErrorAction.REPORT).onUnmappableCharacter(java.nio.charset.CodingErrorAction.REPORT).decode(java.nio.ByteBuffer.wrap(limited(inputStream, DirectDrive.LIMIT))).toString();
        } catch(java.nio.charset.CharacterCodingException invalid) {
            throw new IOException("CSV invalide : encodage UTF-8 attendu.",invalid);
        }
        if (str.startsWith("\ufeff")) {
            str = str.substring(1);
        }
        char c = str.split("\\r?\\n", 2)[0].contains(";") ? ';' : ',';
        ArrayList arrayList = new ArrayList();
        ArrayList arrayList2 = new ArrayList();
        StringBuilder sb = new StringBuilder();
        int i3 = 0;
        boolean z = false;
        while (i3 < str.length()) {
            char cCharAt = str.charAt(i3);
            if (cCharAt == '\"') {
                if (z && (i2 = i3 + 1) < str.length() && str.charAt(i2) == '\"') {
                    sb.append('\"');
                    i3 = i2;
                } else {
                    z = !z;
                }
            } else if (cCharAt == c && !z) {
                arrayList2.add(sb.toString());
                sb.setLength(0);
            } else if ((cCharAt == '\n' || cCharAt == '\r') && !z) {
                if (cCharAt == '\r' && (i = i3 + 1) < str.length() && str.charAt(i) == '\n') {
                    i3 = i;
                }
                arrayList2.add(sb.toString());
                sb.setLength(0);
                arrayList.add((String[]) arrayList2.toArray(new String[0]));
                arrayList2 = new ArrayList();
                if (arrayList.size() > 50001) {
                    throw new IOException("Maximum 50 000 lignes.");
                }
            } else {
                sb.append(cCharAt);
            }
            i3++;
        }
        if (z) {
            throw new IOException("Guillemets CSV non fermés.");
        }
        if (sb.length() > 0 || !arrayList2.isEmpty()) {
            arrayList2.add(sb.toString());
            arrayList.add((String[]) arrayList2.toArray(new String[0]));
        }
        return arrayList;
    }

    static String normalize(String str) {
        return Normalizer.normalize(str, Normalizer.Form.NFD).replaceAll("\\p{M}", "").toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]", "");
    }

    public static void writeCsv(OutputStream outputStream, List<String[]> list) throws IOException {
        OutputStreamWriter outputStreamWriter = new OutputStreamWriter(outputStream, StandardCharsets.UTF_8);
        outputStreamWriter.write("\ufeff");
        for (String[] strArr : list) {
            for (int i = 0; i < strArr.length; i++) {
                if (i > 0) {
                    outputStreamWriter.write(59);
                }
                String str = strArr[i] == null ? "" : strArr[i];
                if (!str.isEmpty() && "=+-@".indexOf(str.charAt(0)) >= 0 && !str.matches("-?[0-9]+(\\.[0-9]+)?")) {
                    str = "'" + str;
                }
                outputStreamWriter.write(34);
                outputStreamWriter.write(str.replace("\"", "\"\""));
                outputStreamWriter.write(34);
            }
            outputStreamWriter.write("\r\n");
        }
        outputStreamWriter.flush();
    }

    static String alias(String str) {
        String strNormalize = normalize(str);
        if(Arrays.asList("gpsxprecedent","gpsxprecedentlongitude","xprecedent").contains(strNormalize))return "gpsxprecedentlongitude";
        if(Arrays.asList("gpsyprecedent","gpsyprecedentlatitude","yprecedent").contains(strNormalize))return "gpsyprecedentlatitude";
        return (strNormalize.equals("ncompteur") || strNormalize.equals("numerodeserie") || strNormalize.equals("numerocompteur")) ? "numerocompteur" : strNormalize.equals("statut") ? "statutphoto" : strNormalize.equals("moyenne") ? "moyennejournaliere" : strNormalize.equals("releveur") ? "identifiantreleveur" : strNormalize.equals("ordre") ? "ordredereleve" : strNormalize;
    }

    static String normalizeImportNumber(String value) {
        try {
            if(value==null||value.trim().isEmpty()||value.length()>128)return "0";
            java.math.BigDecimal number=Model.num(value);
            if(number.signum()<0 || number.compareTo(new java.math.BigDecimal("1000000000000"))>=0 || number.precision()>32 || number.scale() < -1000 || number.scale()>1000)return "0";
            return Model.decimal(number.setScale(2,java.math.RoundingMode.HALF_UP));
        } catch(NumberFormatException invalid) {return "0";}
    }

    public static List<String[]> validateImport(List<String[]> table) throws Exception {
        if(table.isEmpty())throw new IOException("Fichier vide.");
        if(table.size()>50001)throw new IOException("Maximum 50 000 compteurs.");
        int[] columns=new int[Model.FIELDS.length];Arrays.fill(columns,-1);
        for(int c=0;c<table.get(0).length;c++)for(int field=0;field<columns.length;field++) {
            if(alias(table.get(0)[c]).equals(alias(Model.LABELS[field]))) {
                if(columns[field]>=0)throw new IOException("Colonne répétée : "+table.get(0)[c]);
                columns[field]=c;
            }
        }
        for(int n=0;n<10;n++)if(columns[Model.IMPORT[n]]<0)throw new IOException("Colonne absente : "+Model.LABELS[Model.IMPORT[n]]);
        List<String[]> result=new ArrayList<>();HashSet<String> keys=new HashSet<>();
        for(int n=1;n<table.size();n++) {
            String[] raw=table.get(n),row=Model.blank();boolean nonempty=false;
            for(int field:Model.IMPORT) {
                if(columns[field]>=0&&columns[field]<raw.length)row[field]=raw[columns[field]].trim();
                if(row[field].length()>32767)throw new IOException("Texte trop long, ligne "+(n+1));
                nonempty|=!row[field].isEmpty();
            }
            if(!nonempty)continue;
            String prefix="Ligne "+(n+1)+" : ";
            row[Model.NET]=row[Model.NET].toUpperCase(Locale.ROOT);
            if(!Arrays.asList("EA","BT").contains(row[Model.NET]))throw new IOException(prefix+"réseau EA ou BT attendu.");
            for(int field:new int[]{Model.C,Model.SER,Model.UR,Model.TOUR,Model.PROD})if(row[field].isEmpty())throw new IOException(prefix+Model.LABELS[field]+" obligatoire.");
            String[] gps=GpsReference.normalize(row[Model.PREVX],row[Model.PREVY]);row[Model.PREVX]=gps[0];row[Model.PREVY]=gps[1];
            row[Model.OLD]=normalizeImportNumber(row[Model.OLD]);
            try {row[Model.PREV]=Model.date(row[Model.PREV]).toString();}catch(Exception invalid){throw new IOException(prefix+"date ancienne relève invalide (jj/mm/aaaa ou aaaa-mm-jj).",invalid);}
            if(row[Model.STATUS].isEmpty())row[Model.STATUS]="NON";
            row[Model.STATUS]=row[Model.STATUS].toUpperCase(Locale.ROOT);
            if(!Arrays.asList("OUI","NON").contains(row[Model.STATUS]))throw new IOException(prefix+"statut photo OUI ou NON attendu.");
            for(int field:new int[]{Model.MEAN,Model.THRESH})row[field]=normalizeImportNumber(row[field]);
            if(!row[Model.ORDER].isEmpty()&&!row[Model.ORDER].matches("[0-9]{1,9}"))throw new IOException(prefix+"ordre entier positif ou nul attendu.");
            String key=row[Model.NET]+"\u0000"+row[Model.C]+"\u0000"+row[Model.SER]+"\u0000"+row[Model.PROD];
            if(!keys.add(key))throw new IOException(prefix+"doublon réseau/contrat/compteur/produit.");
            result.add(row);
        }
        if(result.isEmpty())throw new IOException("Aucun compteur à importer.");
        return result;
    }
}
