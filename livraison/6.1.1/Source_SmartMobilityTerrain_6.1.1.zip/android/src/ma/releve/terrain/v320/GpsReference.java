package ma.releve.terrain.v320;
import java.math.BigDecimal;
/** Imported reference and observed GPS remain distinct. Invalid/missing pairs never become 0,0. */
public final class GpsReference {
 public static String[] normalize(String x,String y){
  try{
   if(x==null||y==null||x.trim().isEmpty()||y.trim().isEmpty()||x.length()>80||y.length()>80)return new String[]{"",""};
   BigDecimal lon=new BigDecimal(x.trim().replace(',','.')),lat=new BigDecimal(y.trim().replace(',','.'));
   if(lon.abs().compareTo(new BigDecimal("180"))>0||lat.abs().compareTo(new BigDecimal("90"))>0||(lon.signum()==0&&lat.signum()==0)||Math.abs(lon.scale())>30||Math.abs(lat.scale())>30)return new String[]{"",""};
   return new String[]{lon.stripTrailingZeros().toPlainString(),lat.stripTrailingZeros().toPlainString()};
  }catch(NumberFormatException invalid){return new String[]{"",""};}
 }
 public static boolean hasPrevious(String[] row){return !normalize(row[Model.PREVX],row[Model.PREVY])[0].isEmpty();}
 public static String[] forMap(String[] row){String[] previous=normalize(row[Model.PREVX],row[Model.PREVY]);return previous[0].isEmpty()?normalize(row[Model.X],row[Model.Y]):previous;}
}
