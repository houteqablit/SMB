# Installation

Installer `SmartMobilityTerrain-3.2.0.apk` depuis le gestionnaire de fichiers d’un téléphone Android 8 ou supérieur, en autorisant cette source si Android le demande. La version 3.1.1 peut rester installée : les packages et leurs données privées sont séparés.

Créer le compte administrateur au premier lancement, puis les releveurs. Le modèle de démonstration appartient à `releveur01` ; créer ce compte ou adapter la colonne Identifiant releveur à votre identifiant. Les téléphones, contrats et codes des modèles sont fictifs.

Import administrateur : ajouter les contrats absents pour la campagne choisie sans écraser les saisies. Ma tournée / Synchroniser : importer les trois sources et confirmer explicitement pour remplacer votre liste. Sauvegarder et Envoyer n’appliquent jamais ce remplacement.

Conserver des sauvegardes et contrôler `VALIDATION.md` avant déploiement terrain. Le partage Drive nécessite l’application/fournisseur Drive et les permissions de votre compte sur le téléphone. Une action de partage n’est pas un accusé de réception.

## Mise à jour corrigée (versionCode 8)

Installer le nouvel APK par-dessus la 3.2.0 existante, sans désinstaller l’application : les données locales sont conservées. Après validation du fichier importé, utiliser le bouton **Remplacer** à côté d’**Annuler**.

Releveur : menu ⋮ → **Modifier mon mot de passe**. Administrateur : ⋮ → **Administrateur 🔒** → **Modifier mon mot de passe**. Saisir le mot de passe actuel, le nouveau (au moins huit caractères) et sa confirmation, puis **Enregistrer le mot de passe**. Utiliser le nouveau mot de passe à la prochaine connexion.

## Formulaire compact

L’en-tête affiche UR / tournée, le nom du releveur et relevés / total selon les filtres. Le numéro de compteur EA est bleu et gras ; BT rouge et gras. La ligne suivante contient ancien index et date précédente. Les détails du client peuvent être consultés en touchant son résumé.

Pour un index anormal, saisir puis confirmer avec la touche du clavier ou l’action photo / validation. Deux saisies consécutives identiques sont nécessaires. Chaque valeur différente remplace la précédente en mémoire. Après confirmation, prendre la photo, choisir une anomalie compatible et compléter le commentaire si requis, puis valider.
