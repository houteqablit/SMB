# Installation

Installer `SmartMobilityTerrain-3.2.0.apk` depuis le gestionnaire de fichiers d’un téléphone Android 8 ou supérieur, en autorisant cette source si Android le demande. La version 3.1.1 peut rester installée : les packages et leurs données privées sont séparés.

Créer le compte administrateur au premier lancement, puis les releveurs. Le modèle de démonstration appartient à `releveur01` ; créer ce compte ou adapter la colonne Identifiant releveur à votre identifiant. Les téléphones, contrats et codes des modèles sont fictifs.

Import administrateur : ajouter les contrats absents pour la campagne choisie sans écraser les saisies. Ma tournée / Synchroniser : importer les trois sources et confirmer explicitement pour remplacer votre liste. Sauvegarder et Envoyer n’appliquent jamais ce remplacement.

Conserver des sauvegardes et contrôler `VALIDATION.md` avant déploiement terrain. Le partage Drive nécessite l’application/fournisseur Drive et les permissions de votre compte sur le téléphone. Une action de partage n’est pas un accusé de réception.
