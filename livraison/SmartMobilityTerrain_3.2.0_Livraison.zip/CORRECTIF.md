# SmartMobility Terrain 3.2.0 — compilation 8

Formulaire compact et clavier visible ; UR/tournée, nom du releveur et relevés/total filtré dans l’en-tête. Compteurs EA bleus et gras, BT rouges et gras. Ancien index et ancienne date regroupés. Suppression des éléments de formulaire demandés sans désactiver les fonctions photos/GPS ou le deuxième passage automatique.

Deux index consécutifs identiques nécessaires pour confirmer un index anormal. Exemple : 1250 → 1205 → 1250 → 1255 → 1255. La photo est demandée après confirmation. Les règles d’anomalie et de commentaire sont conservées.

Tri par Ordre de releve numérique, indépendant de l’ordre des lignes Excel. Compteur de progression calculé sur tous les résultats des filtres, y compris au-delà des 150 cartes affichées.

Installer par-dessus la 3.2.0 existante sans la désinstaller. Le package et le certificat restent identiques. Les corrections précédentes du bouton Remplacer et des mots de passe sont conservées.
