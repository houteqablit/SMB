# Correctif SmartMobility Terrain 3.2.0 — versionCode 7

- Import personnel : bouton Remplacer visible à côté d’Annuler ; sauvegarde et partage restent proposés. Seul Remplacer applique l’import.
- Releveur : menu ⋮ → Modifier mon mot de passe.
- Administrateur : menu ⋮ → Administrateur 🔒 → Modifier mon mot de passe.
- Saisir le mot de passe actuel, un nouveau mot de passe d’au moins huit caractères, puis sa confirmation. Enregistrer le mot de passe.
- Installer cet APK par-dessus la 3.2.0 précédente sans la désinstaller, pour conserver les données. La clé de signature et le package sont identiques.
- Le modèle Excel à trois feuilles reste compatible.
