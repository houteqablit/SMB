# Validation SmartMobility Terrain 3.2.0

La compilation AAPT2 / Java 17 / D8 a réussi. Alignement ZIP vérifié ; signatures APK v2 et v3 vérifiées. APK `ma.releve.terrain.v320`, versionName 3.2.0, versionCode 7, minSdk 26, targetSdk 35.

## Correctif après retour utilisateur

Bouton Remplacer visible à côté d’Annuler lors de l’import. Le message ne masque plus les actions Sauvegarder / Exporter et Envoyer les relèves. Modification du mot de passe personnel accessible dans les menus releveur et administrateur, avec contrôle du mot de passe actuel, longueur minimale et confirmation, sel renouvelé et audit sans secret.

La mise à jour de l’APK versionCode 6 vers 7 a réussi sur Android 8 ; le certificat de signature est identique. Ne pas désinstaller la 3.2.0 précédente pour conserver les données.

## Vérifications exécutées

- 47 contrôles JVM réussis : XLSX à trois feuilles, import groupé ZIP/CSV, catalogues vides/incomplets, feuilles supplémentaires, fichiers tronqués, formules, UTF-8 invalide, doublons, dates, affectations, zéros initiaux, seuils CMJ, index anormal, liens Drive et faux domaines, sauvegarde/restauration des 42 champs, photos/source/catalogues, exports XLSX.
- 61 contrôles sur Android 8 / API 26 réussis : SQLite réel, comptes PBKDF2, isolation des comptes, filtres, limites, rollback de collisions et d’erreurs de catalogue, révisions périmées, conservation des originaux et des relèves lors de l’import administrateur, export, audit, sauvegarde/restauration, démarrage de l’activité, liste vide/liste remplie, menu de types, absence de second champ d’index et confirmation, rejet d’une ancienne position GPS et coordonnées simulées, redimensionnement JPEG, exports en lecture seule. Les contrôles supplémentaires couvrent les boutons visibles, l’annulation sans mutation, le remplacement effectif par le bouton, les écrans de mot de passe, les saisies invalides, la révocation de l’ancien mot de passe, le maintien des rôles et l’isolation des comptes.
- APK 3.2.0 et APK 3.1.1 installées simultanément sur cet émulateur ; les deux packages distincts sont présents. L’activité 3.2.0 a été ouverte par les tests.
- Émulateur redémarré sans effacer ses données : les deux packages sont restés installés et l’écran réel de création de l’administrateur 3.2.0 a été vérifié via la hiérarchie UI. Une alerte de délai de System UI due au mode logiciel a été fermée avec Wait avant cette vérification.
- Archive source extraite séparément et tests JVM exécutés depuis la copie autonome. La clé privée de signature n’est pas incluse dans l’archive source.

Les traces détaillées sont jointes. Le runner Android s’exécute en mode brut pour vérifier explicitement `INSTRUMENTATION_CODE: -1` en plus du nombre de contrôles ; un statut shell nul seul ne suffit pas.

## Limites et recette restante

Le moteur Emulator 37 a rencontré des arrêts du processus système par watchdog sur API 35, avant exécution de la suite applicative. Son initialisation du disque API 26 a également échoué. API 35 n’est donc pas validée à l’exécution. Les tests API 26 utilisent Emulator 33.1.24 officiel et l’image Android 8 officielle. Le cloud ne fournit pas KVM ; l’émulation fonctionne en mode logiciel.

Aucun téléphone réel n’a été utilisé. Caméra et prise de vue réelle, précision GPS sur le terrain, ergonomie extérieure/gestes, sélecteur Drive et réception d’un partage restent à vérifier sur téléphone avant déploiement. Les tests JPEG et GPS utilisent des données synthétiques ; ils ne valident pas les capteurs matériels. Aucun téléchargement Drive réel ni connexion à un système de facturation n’a été testé.

Le code est reconstruit depuis le binaire 3.1.1 et les spécifications ; les sources et les anciens tests originaux n’étaient pas fournis. La conservation exhaustive du comportement historique nécessite la recette décrite dans `android/README.md`. Le modèle comporte des exemples fictifs affectés à `releveur01` et des anomalies DEMO_ à remplacer par le catalogue officiel. La signature 3.2.0 est une signature de développement indépendante de celle de 3.1.1.
